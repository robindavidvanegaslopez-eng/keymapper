plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.keymapper"
    compileSdk = 35

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
    defaultConfig {
        applicationId = "com.example.keymapper"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"
    }
}


dependencies {
    implementation("com.flyfishxu:kadb:1.2.1")
    // WirelessAdbBridge uses runBlocking to call Kadb.pair(), which is a suspend function.
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.9.0")
}
