package com.example.keymapper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** Receives the reply typed directly into the notification, without opening the app. */
class PairingCodeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_SUBMIT) return
        val code = RemoteInput.getResultsFromIntent(intent)?.getCharSequence(KEY_CODE)?.toString()?.trim().orEmpty()
        if (code.length != 6 || !code.all(Char::isDigit)) {
            PairingNotification.show(context, "Código inválido", "Envía los 6 dígitos que muestra Android.", allowReply = true)
            return
        }
        val serviceIntent = Intent(context, PairingCodeService::class.java).putExtra(PairingCodeService.EXTRA_CODE, code)
        try {
            context.startForegroundService(serviceIntent)
        } catch (error: Exception) {
            PairingNotification.show(context, "No se pudo iniciar la conexión", error.message ?: "Abre Key Mapper e inténtalo de nuevo.", allowReply = true)
        }
    }

    companion object {
        const val ACTION_SUBMIT = "com.example.keymapper.SUBMIT_PAIRING_CODE"
        const val KEY_CODE = "pairing_code_remote_input"
    }
}

/** Keeps Android's background limits from interrupting the mDNS/ADB pairing operation. */
class PairingCodeService : android.app.Service() {
    override fun onBind(intent: Intent?): android.os.IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getStringExtra(EXTRA_CODE).orEmpty()
        startForeground(PairingNotification.NOTIFICATION_ID,
            PairingNotification.build(this, "Conectando ADB inalámbrico…", "Buscando el servicio de emparejamiento. Mantén abierta la pantalla de Android.", allowReply = false))
        if (code.length != 6 || !code.all(Char::isDigit)) {
            PairingNotification.show(this, "Código inválido", "Envía los 6 dígitos que muestra Android.", allowReply = true)
            stopForeground(STOP_FOREGROUND_DETACH)
            stopSelf(startId)
            return START_NOT_STICKY
        }
        WirelessAdbBridge.pairAndConnect(applicationContext, code) { result ->
            result.fold(
                onSuccess = { message -> PairingNotification.show(this, "Key Mapper conectado", message, allowReply = true) },
                onFailure = { error -> PairingNotification.show(this, "No se pudo conectar", error.message ?: "Error desconocido. Inténtalo de nuevo.", allowReply = true) }
            )
            stopForeground(STOP_FOREGROUND_DETACH)
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    companion object { const val EXTRA_CODE = "pairing_code_for_service" }
}

private object PairingNotification {
    const val NOTIFICATION_ID = 4102
    private const val CHANNEL_ID = "wireless_debugging_guide"

    fun build(context: Context, title: String, message: String, allowReply: Boolean): Notification {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Guía de depuración inalámbrica", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(context, CHANNEL_ID) else {
            @Suppress("DEPRECATION")
            Notification.Builder(context)
        }
        builder.setSmallIcon(R.drawable.ic_keymapper)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(Notification.BigTextStyle().bigText(message))
            .setAutoCancel(false)
        if (allowReply) {
            val intent = Intent(context, PairingCodeReceiver::class.java).setAction(PairingCodeReceiver.ACTION_SUBMIT)
            val pendingIntent = PendingIntent.getBroadcast(context, 4103, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
            val remoteInput = RemoteInput.Builder(PairingCodeReceiver.KEY_CODE).setLabel("Código de 6 dígitos de Android").build()
            val action = Notification.Action.Builder(null, "Escribir código", pendingIntent)
                .addRemoteInput(remoteInput)
                .setAllowGeneratedReplies(false)
                .build()
            builder.addAction(action)
        }
        return builder.build()
    }

    fun show(context: Context, title: String, message: String, allowReply: Boolean) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, build(context, title, message, allowReply))
    }
}
