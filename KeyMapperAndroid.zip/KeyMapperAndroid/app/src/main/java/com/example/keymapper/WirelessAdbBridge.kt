package com.example.keymapper

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import com.flyfishxu.kadb.Kadb
import kotlinx.coroutines.runBlocking
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/** ADB client that pairs this app with the phone's own Wireless debugging service. */
object WirelessAdbBridge {
    private const val PREFS = "wireless_pairing"
    private const val KEY_HOST = "adb_host"
    private const val KEY_PORT = "adb_connect_port"
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var client: Kadb? = null
    @Volatile private var connected = false

    data class Endpoint(val host: String, val port: Int)

    fun isConnected(): Boolean = connected

    fun restore(context: Context) {
        val appContext = context.applicationContext
        worker.execute {
            var restored: Kadb? = null
            val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val savedHost = prefs.getString(KEY_HOST, null)
            val savedPort = prefs.getInt(KEY_PORT, -1)

            // First try the last known endpoint. Android may assign a new port after Wi-Fi
            // debugging is toggled, so fall back to mDNS discovery without asking for an IP.
            if (!savedHost.isNullOrBlank() && savedPort in 1..65535) {
                restored = runCatching {
                    Kadb.create(savedHost, savedPort, connectTimeout = 3500, socketTimeout = 3500).also { candidate ->
                        val response = candidate.shell("echo KEYMAPPER_READY")
                        check(response.exitCode == 0 && response.allOutput.contains("KEYMAPPER_READY"))
                    }
                }.getOrNull()
            }
            if (restored == null) {
                restored = runCatching {
                    val endpoint = discoverEndpoint(appContext, "_adb-tls-connect._tcp.", 12)
                    Kadb.create(endpoint.host, endpoint.port, connectTimeout = 4500, socketTimeout = 4500).also { candidate ->
                        val response = candidate.shell("echo KEYMAPPER_READY")
                        check(response.exitCode == 0 && response.allOutput.contains("KEYMAPPER_READY"))
                        prefs.edit().putString(KEY_HOST, endpoint.host).putInt(KEY_PORT, endpoint.port).apply()
                    }
                }.getOrNull()
            }
            val activeRestored = restored
            synchronized(this) {
                if (activeRestored != null) {
                    runCatching { client?.close() }
                    client = activeRestored
                    connected = true
                } else {
                    connected = false
                    runCatching { client?.close() }
                    client = null
                }
            }
        }
    }

    fun pairAndConnect(context: Context, code: String, callback: (Result<String>) -> Unit) {
        val appContext = context.applicationContext
        worker.execute {
            val result = runCatching {
                require(code.length == 6 && code.all(Char::isDigit)) { "El código debe tener 6 dígitos." }
                val pairEndpoint = discoverEndpoint(appContext, "_adb-tls-pairing._tcp.", 25)
                runBlocking { Kadb.pair(pairEndpoint.host, pairEndpoint.port, code) }

                // The pairing port and the command connection port are different. Discover the latter automatically.
                val connectEndpoint = discoverEndpoint(appContext, "_adb-tls-connect._tcp.", 30)
                val candidate = Kadb.create(connectEndpoint.host, connectEndpoint.port, connectTimeout = 5000, socketTimeout = 5000)
                val check = candidate.shell("echo KEYMAPPER_READY")
                check(check.exitCode == 0 && check.allOutput.contains("KEYMAPPER_READY")) {
                    "El emparejamiento terminó, pero no se pudo comprobar la conexión ADB."
                }
                client?.close()
                client = candidate
                connected = true
                appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString(KEY_HOST, connectEndpoint.host)
                    .putInt(KEY_PORT, connectEndpoint.port)
                    .remove("pairing_code")
                    .apply()
                "¡ADB conectado! Los clics asignados intentarán tocar sus coordenadas guardadas."
            }.onFailure { error ->
                connected = false
                runCatching { client?.close() }
                client = null
            }
            main.post { callback(result) }
        }
    }

    /** Returns true when ADB accepted the request for asynchronous execution. */
    fun tap(x: Int, y: Int, onFailure: (() -> Unit)? = null): Boolean {
        if (!connected || client == null) return false
        val targetX = x.coerceAtLeast(1)
        val targetY = y.coerceAtLeast(1)
        worker.execute {
            val result = runCatching {
                val active = client ?: throw IOException("ADB desconectado")
                val response = active.shell("input tap $targetX $targetY")
                check(response.exitCode == 0) { response.allOutput.ifBlank { "ADB no pudo ejecutar el toque." } }
            }
            result.onFailure {
                connected = false
                runCatching { client?.close() }
                client = null
                main.post { onFailure?.invoke() }
            }
        }
        return true
    }

    private fun discoverEndpoint(context: Context, serviceType: String, timeoutSeconds: Long): Endpoint {
        val manager = context.getSystemService(Context.NSD_SERVICE) as NsdManager
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val multicastLock = runCatching {
            wifi?.createMulticastLock("KeyMapper-ADB-mDNS")?.apply {
                setReferenceCounted(false)
                acquire()
            }
        }.getOrNull()
        val latch = CountDownLatch(1)
        val found = AtomicReference<Endpoint?>(null)
        val failure = AtomicReference<String?>(null)
        val resolving = AtomicBoolean(false)
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {}
            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                val typeMatches = serviceInfo.serviceType.orEmpty().contains(serviceType.removeSuffix("."), ignoreCase = true)
                if (!typeMatches || !resolving.compareAndSet(false, true)) return
                try {
                    @Suppress("DEPRECATION")
                    manager.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                            resolving.set(false)
                        }
                        override fun onServiceResolved(info: NsdServiceInfo) {
                            val address = info.host?.hostAddress?.substringBefore('%')
                            if (!address.isNullOrBlank() && info.port in 1..65535) {
                                found.set(Endpoint(address, info.port))
                                latch.countDown()
                            } else {
                                failure.set("Android no devolvió la dirección del servicio ADB.")
                                latch.countDown()
                            }
                        }
                    })
                } catch (e: Exception) {
                    failure.set(e.message ?: "No se pudo resolver el servicio ADB.")
                    latch.countDown()
                }
            }
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                failure.set("No se pudo buscar el servicio de depuración inalámbrica (código $errorCode).")
                latch.countDown()
                runCatching { manager.stopServiceDiscovery(this) }
            }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                failure.set("No se pudo detener la búsqueda de servicios (código $errorCode).")
            }
        }
        try {
            manager.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener)
            if (!latch.await(timeoutSeconds, TimeUnit.SECONDS)) {
                throw IOException("No encontré automáticamente el puerto $serviceType. Mantén abierta la pantalla de Depuración inalámbrica y vuelve a intentarlo.")
            }
            failure.get()?.let { throw IOException(it) }
            return found.get() ?: throw IOException("No se encontró un endpoint ADB válido.")
        } finally {
            runCatching { manager.stopServiceDiscovery(listener) }
            runCatching { if (multicastLock?.isHeld == true) multicastLock.release() }
        }
    }
}
