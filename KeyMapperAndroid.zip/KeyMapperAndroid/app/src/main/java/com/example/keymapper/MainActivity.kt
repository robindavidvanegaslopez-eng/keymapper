package com.example.keymapper

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.PendingIntent
import android.app.AlertDialog
import android.app.NotificationManager
import android.os.Build
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.text.InputType
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var keyInput: EditText
    private lateinit var actionSpinner: Spinner
    private lateinit var mappingList: LinearLayout
    private val actions = listOf("Toque en pantalla", "Joystick arriba", "Joystick abajo", "Joystick izquierda", "Joystick derecha")
    private val actionCodes = listOf("TAP", "UP", "DOWN", "LEFT", "RIGHT")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("mapping", MODE_PRIVATE)
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
            setBackgroundColor(Color.rgb(246, 248, 252))
        }
        scroll.addView(root)
        root.addView(TextView(this).apply {
            text = "KEY MAPPER"
            textSize = 26f
            setTextColor(Color.rgb(35, 90, 190))
        })
        root.addView(TextView(this).apply {
            text = "Crea varios controles, arrástralos sobre el juego y asigna una acción distinta a cada tecla del teclado físico."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, 8, 0, 18)
        })
        root.addView(Button(this).apply {
            text = "1. Permitir mostrarse sobre otras apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Permiso de superposición ya concedido", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "2. Activar servicio de accesibilidad"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "3. Quitar optimización de batería"
            setOnClickListener {
                try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
                catch (_: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
            }
        })
        root.addView(Button(this).apply {
            text = "4. Guía de depuración inalámbrica (opcional)"
            setOnClickListener { showWirelessDebuggingGuide() }
        })
        root.addView(TextView(this).apply {
            text = "Añadir una asignación"
            textSize = 19f
            setTextColor(Color.rgb(35, 70, 130))
            setPadding(0, 20, 0, 8)
        })
        keyInput = EditText(this).apply {
            hint = "Tecla física (ej. E, F, SPACE, 1)"
            setSingleLine(true)
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(keyInput)
        actionSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, actions)
        }
        root.addView(actionSpinner)
        root.addView(Button(this).apply {
            text = "Añadir tecla"
            setOnClickListener { addMapping() }
        })
        root.addView(TextView(this).apply {
            text = "Tus teclas"
            textSize = 19f
            setTextColor(Color.rgb(35, 70, 130))
            setPadding(0, 20, 0, 8)
        })
        mappingList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(mappingList)
        root.addView(Button(this).apply {
            text = "Mostrar / ocultar controles flotantes"
            setOnClickListener {
                prefs.edit().putBoolean("controlsVisible", !prefs.getBoolean("controlsVisible", true)).apply()
                Toast.makeText(this@MainActivity, "Vuelve al juego; el servicio actualizará los controles", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(TextView(this).apply {
            text = "Uso: activa superposición y accesibilidad. En el juego, toca KM para añadir un Clic o un Joystick WASD. Usa el modo edición para mover o cambiar controles; en modo juego, los toques pasan al juego. La depuración inalámbrica no es necesaria para los gestos de accesibilidad y su código lo genera Android, no esta app."
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 16, 0, 0)
        })
        setContentView(scroll)
        renderMappings()
        handleSpecialIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleSpecialIntent(intent)
    }

    private fun handleSpecialIntent(source: Intent?) {
        if (source == null) return
        when {
            source.getBooleanExtra(EXTRA_SHOW_PAIR_CODE, false) -> window.decorView.post { showPairingCodeDialog() }
            source.hasExtra(EXTRA_EDIT_MAPPING_ID) -> {
                val id = source.getStringExtra(EXTRA_EDIT_MAPPING_ID) ?: return
                window.decorView.post { showMappingEditor(id) }
            }
            source.getBooleanExtra(EXTRA_CHANGE_JOYSTICK_SIZE, false) -> window.decorView.post { showJoystickSizeDialog() }
        }
        source.removeExtra(EXTRA_SHOW_PAIR_CODE)
        source.removeExtra(EXTRA_EDIT_MAPPING_ID)
        source.removeExtra(EXTRA_CHANGE_JOYSTICK_SIZE)
    }

    private fun showPairingCodeDialog() {
        val codeInput = EditText(this).apply {
            hint = "Código de 6 dígitos de Android"
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            filters = arrayOf(android.text.InputFilter.LengthFilter(6))
        }
        val savedCode = getSharedPreferences("wireless_pairing", MODE_PRIVATE).getString("pairing_code", "") ?: ""
        codeInput.setText(savedCode)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
            addView(codeInput)
            addView(TextView(this@MainActivity).apply {
                text = "Este campo solo recoge el código. El emparejamiento ADB requiere un cliente ADB compatible; introducir el código por sí solo no autoriza ni conecta la aplicación."
                textSize = 13f
                setTextColor(Color.DKGRAY)
                setPadding(0, 12, 0, 0)
            })
        }
        AlertDialog.Builder(this)
            .setTitle("Código de depuración inalámbrica")
            .setView(container)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val code = codeInput.text.toString().trim()
                        if (code.length != 6 || !code.all { it.isDigit() }) {
                            codeInput.error = "Escribe los 6 dígitos que muestra Android"
                            return@setOnClickListener
                        }
                        getSharedPreferences("wireless_pairing", MODE_PRIVATE).edit().putString("pairing_code", code).apply()
                        dialog.dismiss()
                        Toast.makeText(this, "Código guardado localmente; no se ha realizado una conexión ADB.", Toast.LENGTH_LONG).show()
                    }
                }
                dialog.show()
            }
    }


    private fun showMappingEditor(id: String) {
        val item = findMapping(id) ?: run { Toast.makeText(this, "Ese control ya no existe", Toast.LENGTH_SHORT).show(); return }
        val input = EditText(this).apply {
            setSingleLine(true)
            hint = "Ej. E, F, SPACE, 1"
            setText(item.optString("key", "?"))
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Personalizar tecla de clic")
            .setMessage("Escribe la tecla física que activará este punto de toque.")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val key = input.text.toString().trim().uppercase().let { if (it == "ESPACIO") "SPACE" else it }
                if (key.isBlank() || key == "?") {
                    Toast.makeText(this, "Escribe una tecla válida", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                item.put("key", key)
                replaceMapping(item)
                Toast.makeText(this, "Tecla $key asignada", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Eliminar") { _, _ -> removeMapping(id) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showJoystickSizeDialog() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 12, 24, 4) }
        val current = prefs.getInt("joySize", 150).coerceIn(80, 300)
        val label = TextView(this).apply { text = "Tamaño: $current px"; textSize = 16f; setTextColor(Color.DKGRAY) }
        val slider = SeekBar(this).apply { max = 220; progress = current - 80 }
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { label.text = "Tamaño: ${progress + 80} px" }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        layout.addView(label)
        layout.addView(slider)
        AlertDialog.Builder(this)
            .setTitle("Tamaño del joystick")
            .setView(layout)
            .setPositiveButton("Guardar") { _, _ -> prefs.edit().putInt("joySize", slider.progress + 80).apply() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun findMapping(id: String): JSONObject? {
        val arr = mappings()
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            if (item.optString("id") == id) return item
        }
        return null
    }

    private fun replaceMapping(updated: JSONObject) {
        val arr = mappings()
        for (i in 0 until arr.length()) {
            if (arr.optJSONObject(i)?.optString("id") == updated.optString("id")) { arr.put(i, updated); break }
        }
        prefs.edit().putString("mappings", arr.toString()).apply()
        renderMappings()
    }

    private fun removeMapping(id: String) {
        val old = mappings()
        val updated = JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (item.optString("id") != id) updated.put(item)
        }
        prefs.edit().putString("mappings", updated.toString()).apply()
        renderMappings()
    }

    private fun showWirelessDebuggingGuide() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 4102)
        } else {
            postWirelessNotification()
        }
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        } catch (_: Exception) {
            Toast.makeText(this, "Abre Ajustes y busca Opciones de desarrollador > Depuración inalámbrica", Toast.LENGTH_LONG).show()
        }
    }

    private fun postWirelessNotification() {
        val channelId = "wireless_debugging_guide"
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Guía de depuración inalámbrica", NotificationManager.IMPORTANCE_DEFAULT))
        }
        try {
            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId) else {
                @Suppress("DEPRECATION")
                Notification.Builder(this)
            }
            val codeIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(EXTRA_SHOW_PAIR_CODE, true)
            }
            val codePendingIntent = PendingIntent.getActivity(
                this, 4103, codeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Depuración inalámbrica")
                .setContentText("Pulsa Código para escribir el código que muestra Android.")
                .setStyle(Notification.BigTextStyle().bigText("En Android, abre Opciones de desarrollador > Depuración inalámbrica > Vincular dispositivo con código. Después pulsa Código aquí para escribirlo."))
                .addAction(android.app.Notification.Action.Builder(null, "Código", codePendingIntent).build())
                .setContentIntent(codePendingIntent)
                .setAutoCancel(true).build()
            manager.notify(4102, notification)
        } catch (_: SecurityException) {
            Toast.makeText(this, "No se pudieron mostrar las notificaciones; el código real lo genera Android.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 4102 && grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) postWirelessNotification()
    }

    private fun mappings(): JSONArray = try { JSONArray(prefs.getString("mappings", "[]")) } catch (_: Exception) { JSONArray() }

    private fun addMapping() {
        val key = keyInput.text.toString().trim().uppercase()
        if (key.isBlank()) {
            Toast.makeText(this, "Escribe una tecla primero", Toast.LENGTH_SHORT).show()
            return
        }
        val keyCode = when (key) {
            "SPACE", "ESPACIO" -> "SPACE"
            else -> key
        }
        val array = mappings()
        val action = actionCodes[actionSpinner.selectedItemPosition]
        val obj = JSONObject().apply {
            put("id", System.currentTimeMillis().toString())
            put("key", keyCode)
            put("action", action)
            put("x", -1)
            put("y", -1)
        }
        array.put(obj)
        prefs.edit().putString("mappings", array.toString()).apply()
        keyInput.setText("")
        renderMappings()
        Toast.makeText(this, "Asignación añadida. Puedes arrastrar su control sobre el juego.", Toast.LENGTH_SHORT).show()
    }

    private fun renderMappings() {
        if (!::mappingList.isInitialized) return
        mappingList.removeAllViews()
        val array = mappings()
        if (array.length() == 0) {
            mappingList.addView(TextView(this).apply { text = "Aún no hay teclas asignadas."; setTextColor(Color.GRAY) })
        }
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(10, 6, 4, 6)
                setBackgroundColor(Color.WHITE)
            }
            val key = item.optString("key", "?")
            val action = item.optString("action", "TAP")
            val actionName = when (action) {
                "UP" -> "Joystick ↑"
                "DOWN" -> "Joystick ↓"
                "LEFT" -> "Joystick ←"
                "RIGHT" -> "Joystick →"
                else -> "Toque"
            }
            row.addView(TextView(this).apply {
                text = "$key  →  $actionName"
                textSize = 15f
                setTextColor(Color.DKGRAY)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "Eliminar"
                setOnClickListener {
                    val old = mappings()
                    val updated = JSONArray()
                    for (j in 0 until old.length()) {
                        val candidate = old.optJSONObject(j) ?: continue
                        if (candidate.optString("id") != item.optString("id")) updated.put(candidate)
                    }
                    prefs.edit().putString("mappings", updated.toString()).apply()
                    renderMappings()
                }
            })
            mappingList.addView(row)
        }
    }

    companion object {
        private const val EXTRA_SHOW_PAIR_CODE = "show_pairing_code_dialog"
        const val EXTRA_EDIT_MAPPING_ID = "edit_mapping_id"
        const val EXTRA_CHANGE_JOYSTICK_SIZE = "change_joystick_size"
    }

}
