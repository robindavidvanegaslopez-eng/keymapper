package com.example.keymapper

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("mapping", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(247, 249, 252))
        }
        root.addView(TextView(this).apply {
            text = "KEY MAPPER"
            textSize = 25f
            setTextColor(Color.rgb(35, 90, 190))
        })
        root.addView(TextView(this).apply {
            text = "Mapeador básico para teclado físico. Las coordenadas son píxeles desde la esquina superior izquierda."
            textSize = 14f
            setTextColor(Color.DKGRAY)
        })
        fun field(title: String, key: String, default: String): EditText {
            root.addView(TextView(this).apply { text = title; textSize = 14f; setPadding(0, 12, 0, 2); setTextColor(Color.DKGRAY) })
            val edit = EditText(this).apply {
                setSingleLine(true)
                setText(prefs.getString(key, default))
                textSize = 16f
                setPadding(12, 4, 12, 4)
                setBackgroundColor(Color.WHITE)
            }
            root.addView(edit)
            return edit
        }
        val tapKey = field("Tecla que hará un toque (ej. E, F, SPACE)", "tapKey", "E")
        val tapX = field("X del toque", "tapX", "540")
        val tapY = field("Y del toque", "tapY", "1200")
        val joyX = field("Centro X del joystick WASD", "joyX", "180")
        val joyY = field("Centro Y del joystick WASD", "joyY", "1500")
        val joyRadius = field("Radio del joystick en píxeles", "joyRadius", "100")

        root.addView(Button(this).apply {
            text = "Guardar configuración"
            setOnClickListener {
                prefs.edit()
                    .putString("tapKey", tapKey.text.toString().trim().uppercase().ifBlank { "E" })
                    .putString("tapX", tapX.text.toString())
                    .putString("tapY", tapY.text.toString())
                    .putString("joyX", joyX.text.toString())
                    .putString("joyY", joyY.text.toString())
                    .putString("joyRadius", joyRadius.text.toString())
                    .apply()
                Toast.makeText(this@MainActivity, "Configuración guardada", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Activar servicio de accesibilidad"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "Abrir ajustes de superposición"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(TextView(this).apply {
            text = "Después de activar el servicio, conecta el teclado y vuelve al juego. WASD envía gestos cortos; no mantiene un joystick analógico presionado. Las coordenadas deben calibrarse para tu pantalla."
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 16, 0, 0)
        })
        setContentView(root)
    }
}
