package com.example.keymapper

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.PendingIntent
import android.app.RemoteInput
import android.app.AlertDialog
import android.app.NotificationManager
import android.os.Build
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.text.InputType
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var keyInput: EditText
    private lateinit var actionSpinner: Spinner
    private lateinit var mappingList: LinearLayout
    private val actions = listOf("Toque en pantalla")
    private val actionCodes = listOf("TAP")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("mapping", MODE_PRIVATE)
        val savedMappings = try { JSONArray(prefs.getString("mappings", "[]")) } catch (_: Exception) { JSONArray() }
        val clickOnlyMappings = JSONArray()
        for (i in 0 until savedMappings.length()) {
            val item = savedMappings.optJSONObject(i) ?: continue
            if (item.optString("action", "TAP") == "TAP") clickOnlyMappings.put(item)
        }
        prefs.edit().putString("mappings", clickOnlyMappings.toString()).apply()
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
            setBackgroundColor(Color.rgb(246, 248, 252))
        }
        scroll.addView(root)
        root.addView(TextView(this).apply {
            text = "KEY MAPPER"
            textSize = 26f
            setTextColor(Color.rgb(35, 90, 190))
        })
        root.addView(TextView(this).apply {
            text = "Crea varios controles, arrástralos sobre el juego y asigna una acción distinta a cada tecla del teclado físico."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, 8, 0, 18)
        })
        root.addView(Button(this).apply {
            text = "1. Permitir mostrarse sobre otras apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Permiso de superposición ya concedido", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "2. Activar servicio de accesibilidad"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "3. Quitar optimización de batería"
            setOnClickListener {
                try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
                catch (_: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
            }
        })
        root.addView(Button(this).apply {
            text = "4. Guía de depuración inalámbrica (opcional)"
            setOnClickListener { showWirelessDebuggingGuide() }
        })
        root.addView(TextView(this).apply {
            text = "Añadir una asignación"
            textSize = 19f
            setTextColor(Color.rgb(35, 70, 130))
            setPadding(0, 20, 0, 8)
        })
        keyInput = EditText(this).apply {
            hint = "Tecla física (ej. E, F, SPACE, 1)"
            setSingleLine(true)
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(keyInput)
        actionSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, actions)
        }
        root.addView(actionSpinner)
        root.addView(Button(this).apply {
            text = "Añadir tecla"
            setOnClickListener { addMapping() }
        })
        root.addView(TextView(this).apply {
            text = "Tus teclas"
            textSize = 19f
            setTextColor(Color.rgb(35, 70, 130))
            setPadding(0, 20, 0, 8)
        })
        mappingList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(mappingList)
        root.addView(Button(this).apply {
            fun updateLabel() { text = if (prefs.getBoolean("controlsVisible", true)) "⏻  Apagar KeyMapper" else "▶  Iniciar KeyMapper" }
            updateLabel()
            setOnClickListener {
                val start = !prefs.getBoolean("controlsVisible", true)
                prefs.edit().putBoolean("controlsVisible", start).putBoolean("editMode", false).apply()
                updateLabel()
                Toast.makeText(this@MainActivity, if (start) "KeyMapper iniciado. Tus posiciones se conservaron." else "KeyMapper apagado. Los controles y clics están desactivados; las posiciones se conservaron.", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(Button(this).apply {
            fun updateLabel() { text = if (prefs.getBoolean("paused", false)) "▶  Reanudar KeyMapper" else "Ⅱ  Pausar KeyMapper" }
            updateLabel()
            setOnClickListener {
                val paused = !prefs.getBoolean("paused", false)
                prefs.edit().putBoolean("paused", paused).putBoolean("autoPausedForTyping", false).apply()
                updateLabel()
                Toast.makeText(this@MainActivity, if (paused) "KeyMapper pausado; tus posiciones se conservaron." else "KeyMapper reanudado.", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(TextView(this).apply {
            text = "Uso: activa superposición y accesibilidad. En el juego, toca KM para añadir un Clic. Puedes pausar desde este menú o desde KM; al enfocar un campo de texto compatible, KeyMapper intentará pausarse automáticamente. La depuración inalámbrica es opcional y el código lo genera Android, no esta app."
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 16, 0, 0)
        })

        setContentView(scroll)
        renderMappings()
        handleSpecialIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleSpecialIntent(intent)
    }

    private fun handleSpecialIntent(source: Intent?) {
        if (source == null) return
        when {
            source.getBooleanExtra(EXTRA_SHOW_PAIR_CODE, false) -> window.decorView.post { showPairingCodeDialog() }
            source.hasExtra(EXTRA_EDIT_MAPPING_ID) -> {
                val id = source.getStringExtra(EXTRA_EDIT_MAPPING_ID) ?: return
                window.decorView.post { showMappingEditor(id) }
            }
        }
        source.removeExtra(EXTRA_SHOW_PAIR_CODE)
        source.removeExtra(EXTRA_EDIT_MAPPING_ID)
    }

    private fun showPairingCodeDialog() {
        val codeInput = EditText(this).apply {
            hint = "Código de 6 dígitos de Android"
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            filters = arrayOf(android.text.InputFilter.LengthFilter(6))
        }
        val status = TextView(this).apply {
            text = "Deja activa la pantalla de Depuración inalámbrica > Vincular con código. KeyMapper buscará automáticamente la IP y los puertos por la red local."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, 12, 0, 0)
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
            addView(codeInput)
            addView(status)
        }
        AlertDialog.Builder(this)
            .setTitle("Conectar ADB inalámbrico")
            .setView(container)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Vincular y conectar", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val code = codeInput.text.toString().trim()
                        if (code.length != 6 || !code.all { it.isDigit() }) {
                            codeInput.error = "Escribe los 6 dígitos que muestra Android"
                            return@setOnClickListener
                        }
                        val button = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                        button.isEnabled = false
                        status.text = "Buscando automáticamente el servicio de emparejamiento…"
                        WirelessAdbBridge.pairAndConnect(this, code) { result ->
                            if (isFinishing || isDestroyed) return@pairAndConnect
                            result.fold(
                                onSuccess = { message ->
                                    status.text = message
                                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                                    dialog.dismiss()
                                },
                                onFailure = { error ->
                                    status.text = "No se pudo conectar: ${error.message ?: "error desconocido"}"
                                    button.isEnabled = true
                                }
                            )
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun showMappingEditor(id: String) {
        val item = findMapping(id) ?: run { Toast.makeText(this, "Ese control ya no existe", Toast.LENGTH_SHORT).show(); return }
        val input = EditText(this).apply {
            setSingleLine(true)
            hint = "Ej. E, F, SPACE, 1"
            setText(item.optString("key", "?"))
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Personalizar tecla de clic")
            .setMessage("Escribe la tecla física que activará este punto de toque.")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val key = input.text.toString().trim().uppercase().let { if (it == "ESPACIO") "SPACE" else it }
                if (key.isBlank() || key == "?") {
                    Toast.makeText(this, "Escribe una tecla válida", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                item.put("key", key)
                replaceMapping(item)
                Toast.makeText(this, "Tecla $key asignada", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Eliminar") { _, _ -> removeMapping(id) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showWirelessDebuggingGuide() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 4102)
        } else {
            postWirelessNotification()
        }
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        } catch (_: Exception) {
            Toast.makeText(this, "Abre Ajustes y busca Opciones de desarrollador > Depuración inalámbrica", Toast.LENGTH_LONG).show()
        }
    }

    private fun postWirelessNotification() {
        val channelId = "wireless_debugging_guide"
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Guía de depuración inalámbrica", NotificationManager.IMPORTANCE_DEFAULT))
        }
        try {
            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId) else {
                @Suppress("DEPRECATION")
                Notification.Builder(this)
            }
            val codeIntent = Intent(this, PairingCodeReceiver::class.java).setAction(PairingCodeReceiver.ACTION_SUBMIT)
            val codePendingIntent = PendingIntent.getBroadcast(
                this, 4103, codeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            val remoteInput = RemoteInput.Builder(PairingCodeReceiver.KEY_CODE)
                .setLabel("Código de 6 dígitos de Android")
                .build()
            val action = Notification.Action.Builder(null, "Escribir código", codePendingIntent)
                .addRemoteInput(remoteInput)
                .setAllowGeneratedReplies(false)
                .build()
            val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Depuración inalámbrica")
                .setContentText("Responde a esta notificación con el código de Android, sin abrir Key Mapper.")
                .setStyle(Notification.BigTextStyle().bigText("En Android, abre Opciones de desarrollador > Depuración inalámbrica > Vincular dispositivo con código. Pulsa Responder/Escribir código en esta notificación y envía los 6 dígitos."))
                .addAction(action)
                .setAutoCancel(false).build()
            manager.notify(4102, notification)
        } catch (_: SecurityException) {
            Toast.makeText(this, "No se pudieron mostrar las notificaciones; el código real lo genera Android.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 4102 && grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) postWirelessNotification()
    }

    private fun mappings(): JSONArray = try { JSONArray(prefs.getString("mappings", "[]")) } catch (_: Exception) { JSONArray() }

    private fun addMapping() {
        val key = keyInput.text.toString().trim().uppercase()
        if (key.isBlank()) {
            Toast.makeText(this, "Escribe una tecla primero", Toast.LENGTH_SHORT).show()
            return
        }
        val keyCode = when (key) {
            "SPACE", "ESPACIO" -> "SPACE"
            else -> key
        }
        val array = mappings()
        val action = actionCodes[actionSpinner.selectedItemPosition]
        val obj = JSONObject().apply {
            put("id", System.currentTimeMillis().toString())
            put("key", keyCode)
            put("action", action)
            put("x", -1)
            put("y", -1)
        }
        array.put(obj)
        prefs.edit().putString("mappings", array.toString()).apply()
        keyInput.setText("")
        renderMappings()
        Toast.makeText(this, "Asignación añadida. Puedes arrastrar su control sobre el juego.", Toast.LENGTH_SHORT).show()
    }

    private fun renderMappings() {
        if (!::mappingList.isInitialized) return
        mappingList.removeAllViews()
        val array = mappings()
        if (array.length() == 0) {
            mappingList.addView(TextView(this).apply { text = "Aún no hay teclas asignadas."; setTextColor(Color.GRAY) })
        }
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(10, 6, 4, 6)
                setBackgroundColor(Color.WHITE)
            }
            val key = item.optString("key", "?")
            val action = item.optString("action", "TAP")
            val actionName = "Toque"
            row.addView(TextView(this).apply {
                text = "$key  →  $actionName"
                textSize = 15f
                setTextColor(Color.DKGRAY)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "Eliminar"
                setOnClickListener {
                    val old = mappings()
                    val updated = JSONArray()
                    for (j in 0 until old.length()) {
                        val candidate = old.optJSONObject(j) ?: continue
                        if (candidate.optString("id") != item.optString("id")) updated.put(candidate)
                    }
                    prefs.edit().putString("mappings", updated.toString()).apply()
                    renderMappings()
                }
            })
            mappingList.addView(row)
        }
    }

    companion object {
        const val EXTRA_SHOW_PAIR_CODE = "show_pairing_code_dialog"
        const val EXTRA_EDIT_MAPPING_ID = "edit_mapping_id"
    }

}
