package com.example.keymapper

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var keyInput: EditText
    private lateinit var actionSpinner: Spinner
    private lateinit var mappingList: LinearLayout
    private val actions = listOf("Toque en pantalla", "Joystick arriba", "Joystick abajo", "Joystick izquierda", "Joystick derecha")
    private val actionCodes = listOf("TAP", "UP", "DOWN", "LEFT", "RIGHT")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("mapping", MODE_PRIVATE)
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
            setBackgroundColor(Color.rgb(246, 248, 252))
        }
        scroll.addView(root)
        root.addView(TextView(this).apply {
            text = "KEY MAPPER"
            textSize = 26f
            setTextColor(Color.rgb(35, 90, 190))
        })
        root.addView(TextView(this).apply {
            text = "Crea varios controles, arrástralos sobre el juego y asigna una acción distinta a cada tecla del teclado físico."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, 8, 0, 18)
        })
        root.addView(Button(this).apply {
            text = "1. Permitir mostrarse sobre otras apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Permiso de superposición ya concedido", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "2. Activar servicio de accesibilidad"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(TextView(this).apply {
            text = "Añadir una asignación"
            textSize = 19f
            setTextColor(Color.rgb(35, 70, 130))
            setPadding(0, 20, 0, 8)
        })
        keyInput = EditText(this).apply {
            hint = "Tecla física (ej. E, F, SPACE, 1)"
            setSingleLine(true)
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(keyInput)
        actionSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, actions)
        }
        root.addView(actionSpinner)
        root.addView(Button(this).apply {
            text = "Añadir tecla"
            setOnClickListener { addMapping() }
        })
        root.addView(TextView(this).apply {
            text = "Tus teclas"
            textSize = 19f
            setTextColor(Color.rgb(35, 70, 130))
            setPadding(0, 20, 0, 8)
        })
        mappingList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(mappingList)
        root.addView(Button(this).apply {
            text = "Mostrar / ocultar controles flotantes"
            setOnClickListener {
                prefs.edit().putBoolean("controlsVisible", !prefs.getBoolean("controlsVisible", true)).apply()
                Toast.makeText(this@MainActivity, "Vuelve al juego; el servicio actualizará los controles", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(TextView(this).apply {
            text = "Uso: activa los dos permisos y vuelve a abrir la app. Los controles flotantes se pueden arrastrar con el dedo. La tecla asignada ejecuta su acción en la posición guardada. Para el joystick, arrastra el control JOY al centro del joystick del juego."
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 16, 0, 0)
        })
        setContentView(scroll)
        renderMappings()
    }

    private fun mappings(): JSONArray = try { JSONArray(prefs.getString("mappings", "[]")) } catch (_: Exception) { JSONArray() }

    private fun addMapping() {
        val key = keyInput.text.toString().trim().uppercase()
        if (key.isBlank()) {
            Toast.makeText(this, "Escribe una tecla primero", Toast.LENGTH_SHORT).show()
            return
        }
        val keyCode = when (key) {
            "SPACE", "ESPACIO" -> "SPACE"
            else -> key
        }
        val array = mappings()
        for (i in 0 until array.length()) {
            if (array.optJSONObject(i)?.optString("key") == keyCode) {
                Toast.makeText(this, "Esa tecla ya está asignada; elimina la anterior para cambiarla", Toast.LENGTH_SHORT).show()
                return
            }
        }
        val action = actionCodes[actionSpinner.selectedItemPosition]
        val obj = JSONObject().apply {
            put("id", System.currentTimeMillis().toString())
            put("key", keyCode)
            put("action", action)
            put("x", -1)
            put("y", -1)
        }
        array.put(obj)
        prefs.edit().putString("mappings", array.toString()).apply()
        keyInput.setText("")
        renderMappings()
        Toast.makeText(this, "Asignación añadida. Puedes arrastrar su control sobre el juego.", Toast.LENGTH_SHORT).show()
    }

    private fun renderMappings() {
        if (!::mappingList.isInitialized) return
        mappingList.removeAllViews()
        val array = mappings()
        if (array.length() == 0) {
            mappingList.addView(TextView(this).apply { text = "Aún no hay teclas asignadas."; setTextColor(Color.GRAY) })
        }
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(10, 6, 4, 6)
                setBackgroundColor(Color.WHITE)
            }
            val key = item.optString("key", "?")
            val action = item.optString("action", "TAP")
            val actionName = when (action) {
                "UP" -> "Joystick ↑"
                "DOWN" -> "Joystick ↓"
                "LEFT" -> "Joystick ←"
                "RIGHT" -> "Joystick →"
                else -> "Toque"
            }
            row.addView(TextView(this).apply {
                text = "$key  →  $actionName"
                textSize = 15f
                setTextColor(Color.DKGRAY)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "Eliminar"
                setOnClickListener {
                    val old = mappings()
                    val updated = JSONArray()
                    for (j in 0 until old.length()) {
                        val candidate = old.optJSONObject(j) ?: continue
                        if (candidate.optString("id") != item.optString("id")) updated.put(candidate)
                    }
                    prefs.edit().putString("mappings", updated.toString()).apply()
                    renderMappings()
                }
            })
            mappingList.addView(row)
        }
    }
}
