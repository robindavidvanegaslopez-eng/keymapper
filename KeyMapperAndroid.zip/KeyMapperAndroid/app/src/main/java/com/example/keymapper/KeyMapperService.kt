package com.example.keymapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ImageView
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Toast
import android.content.SharedPreferences
import android.content.Intent
import android.app.AlertDialog
import android.text.InputType
import android.widget.EditText
import android.widget.SeekBar
import android.widget.FrameLayout
import android.widget.FrameLayout.LayoutParams as FrameParams
import android.provider.Settings
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

class KeyMapperService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {
    private lateinit var prefs: SharedPreferences
    private var wm: WindowManager? = null
    private var bubble: View? = null
    private var panel: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var gestureInFlight = false
    private var lastGestureDispatchAt = 0L
    private val clickControls = mutableMapOf<String, Pair<FrameLayout, WindowManager.LayoutParams>>()
    private val controlLabelId = 41001
    private var screenWidth = 1080
    private var screenHeight = 1920
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = getSharedPreferences("mapping", MODE_PRIVATE)
        // El joystick se retiró definitivamente: elimina asignaciones direccionales antiguas.
        val oldMappings = mappings()
        val clickOnly = JSONArray()
        for (i in 0 until oldMappings.length()) {
            val item = oldMappings.optJSONObject(i) ?: continue
            if (item.optString("action", "TAP") == "TAP") clickOnly.put(item)
        }
        prefs.edit().putString("mappings", clickOnly.toString()).apply()
        WirelessAdbBridge.restore(this)
        prefs.registerOnSharedPreferenceChangeListener(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        refreshScreenSize()
        if (prefs.getBoolean("activationAuthorized", false) && prefs.getBoolean("controlsVisible", false) && Settings.canDrawOverlays(this)) ensureBubble() else removeBubble()
        rebuildControls()
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        refreshScreenSize()
        Handler(Looper.getMainLooper()).post {
            repositionBubble()
            rebuildControls(force = true)
        }
    }

    private fun refreshScreenSize() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (wm?.defaultDisplay)?.getRealMetrics(metrics)
        val fallback = resources.displayMetrics
        val width = if (metrics.widthPixels > 0) metrics.widthPixels else fallback.widthPixels
        val height = if (metrics.heightPixels > 0) metrics.heightPixels else fallback.heightPixels
        // Always use the current physical orientation; do not cache portrait dimensions.
        screenWidth = maxOf(width, 1)
        screenHeight = maxOf(height, 1)
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        if (key == "mappings" || key == "controlsVisible" || key == "activationAuthorized" || key == "editMode" || key == "paused" || key == "controlsOpacity") {
            Handler(Looper.getMainLooper()).post {
                if (prefs.getBoolean("activationAuthorized", false) && prefs.getBoolean("controlsVisible", false) && Settings.canDrawOverlays(this)) {
                    ensureBubble()
                    rebuildControls(force = key == "editMode" || key == "mappings")
                    if (key == "controlsOpacity") applyControlOpacity()
                    applyControlTouchMode()
                } else {
                    hidePanel()
                    removeControls()
                    removeBubble()
                }
            }
        }
    }

    private var autoPausedForTyping = false

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        if (!::prefs.isInitialized || event == null || !prefs.getBoolean("activationAuthorized", false) || !prefs.getBoolean("controlsVisible", false)) return
        // Si Android expone el campo editable del juego, pausamos al enfocarlo para evitar clics
        // accidentales mientras se escribe. La pausa manual sigue disponible en ambos menús.
        val source = runCatching { event.source }.getOrNull()
        val editable = runCatching { source?.isEditable == true }.getOrDefault(false) ||
            event.className?.toString()?.let { it.contains("EditText", true) || it.contains("TextField", true) } == true
        runCatching { source?.recycle() }
        if (editable && event.eventType in setOf(
                android.view.accessibility.AccessibilityEvent.TYPE_VIEW_FOCUSED,
                android.view.accessibility.AccessibilityEvent.TYPE_VIEW_CLICKED,
                android.view.accessibility.AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED,
                android.view.accessibility.AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED
            )) {
            autoPausedForTyping = true
            if (!prefs.getBoolean("paused", false)) prefs.edit().putBoolean("paused", true).putBoolean("autoPausedForTyping", true).apply()
        } else if (autoPausedForTyping && event.eventType == android.view.accessibility.AccessibilityEvent.TYPE_VIEW_FOCUSED && !editable) {
            autoPausedForTyping = false
            if (prefs.getBoolean("autoPausedForTyping", false)) prefs.edit().putBoolean("paused", false).putBoolean("autoPausedForTyping", false).apply()
        }
    }
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!::prefs.isInitialized) return false
        if (prefs.getBoolean("editMode", false) || prefs.getBoolean("paused", false) || !prefs.getBoolean("controlsVisible", false)) return false
        val name = if (event.keyCode == KeyEvent.KEYCODE_SPACE) "SPACE" else KeyEvent.keyCodeToString(event.keyCode).removePrefix("KEYCODE_")
        val array = mappings()
        val matched = (0 until array.length()).mapNotNull { array.optJSONObject(it) }
            .filter { it.optString("key").equals(name, true) && it.optString("action", "TAP") == "TAP" }
        if (matched.isEmpty()) return false
        // Consumir tanto DOWN como UP evita que una tecla asignada también active
        // accidentalmente una acción dentro del juego. Las repeticiones no generan gestos.
        if (event.action == KeyEvent.ACTION_UP) return true
        if (event.action != KeyEvent.ACTION_DOWN) return true
        if (event.repeatCount > 0) return true
        dispatchSimultaneousTaps(matched)
        return true
    }

    private fun mappings(): JSONArray = try { JSONArray(prefs.getString("mappings", "[]")) } catch (_: Exception) { JSONArray() }

    private fun tap(x: Float, y: Float) {
        val safeX = x.coerceIn(1f, (screenWidth - 2).coerceAtLeast(1).toFloat())
        val safeY = y.coerceIn(1f, (screenHeight - 2).coerceAtLeast(1).toFloat())
        // Use ADB's input tap when paired; if the wireless connection has gone stale,
        // fall back to the accessibility gesture rather than silently dropping the key.
        if (WirelessAdbBridge.tap(safeX.toInt(), safeY.toInt()) {
                dispatchAccessibilityTap(safeX, safeY)
            }) return
        dispatchAccessibilityTap(safeX, safeY)
    }

    private fun dispatchAccessibilityTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 65)).build()
        dispatchGesture(gesture, null, null)
    }

    private fun dispatchSimultaneousTaps(items: List<JSONObject>) {
        if (items.isEmpty() || gestureInFlight || prefs.getBoolean("editMode", false) || prefs.getBoolean("paused", false) || !prefs.getBoolean("controlsVisible", false)) return
        val now = android.os.SystemClock.uptimeMillis()
        // Back-pressure: nunca apilar gestos. Esto evita saturar AccessibilityService cuando
        // se pulsan varias teclas muy rápido; los eventos durante un gesto se descartan.
        if (now - lastGestureDispatchAt < 45L) return
        refreshScreenSize()
        val builder = GestureDescription.Builder()
        items.take(8).forEach { item ->
            val x = item.optInt("x", screenWidth / 2).toFloat().coerceIn(1f, (screenWidth - 2).coerceAtLeast(1).toFloat())
            val y = item.optInt("y", screenHeight / 2).toFloat().coerceIn(1f, (screenHeight - 2).coerceAtLeast(1).toFloat())
            val path = Path().apply { moveTo(x, y) }
            builder.addStroke(GestureDescription.StrokeDescription(path, 0, 55))
        }
        gestureInFlight = true
        lastGestureDispatchAt = now
        val accepted = runCatching {
            dispatchGesture(builder.build(), object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { gestureInFlight = false }
                override fun onCancelled(gestureDescription: GestureDescription?) { gestureInFlight = false }
            }, mainHandler)
        }.getOrDefault(false)
        if (!accepted) gestureInFlight = false
    }

    private fun setEditabilityFlag(params: WindowManager.LayoutParams) {
        // En uso normal, los círculos no bloquean toques al juego. En edición vuelven a recibirlos.
        if (prefs.getBoolean("editMode", false)) {
            params.flags = (params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()) or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        } else {
            params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
    }

    private fun applyControlTouchMode() {
        val manager = wm ?: return
        clickControls.values.forEach { (view, params) ->
            setEditabilityFlag(params)
            try { manager.updateViewLayout(view, params) } catch (_: Exception) {}
        }
    }

    private fun overlayType(): Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private fun overlayParams(width: Int = WindowManager.LayoutParams.WRAP_CONTENT, height: Int = WindowManager.LayoutParams.WRAP_CONTENT) =
        WindowManager.LayoutParams(width, height, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
        }

    private fun ensureBubble() {
        if (bubble != null || !Settings.canDrawOverlays(this)) return
        val view = ImageView(this).apply {
            setImageResource(com.example.keymapper.R.drawable.ic_keymapper)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(8, 8, 8, 8)
            background = rounded(Color.BLACK, 28)
            contentDescription = "Abrir menú Key Mapper"
            setOnClickListener { togglePanel() }
            setOnTouchListener(dragListener(null) { _, _ -> })
        }
        val params = overlayParams(54, 54).apply { x = (screenWidth - 74).coerceAtLeast(0); y = 200 }
        try { wm?.addView(view, params); bubble = view } catch (_: Exception) {
            Toast.makeText(this, "Concede el permiso para mostrarse sobre otras apps", Toast.LENGTH_LONG).show()
        }
    }

    private fun repositionBubble() {
        val v = bubble ?: return
        val p = v.layoutParams as? WindowManager.LayoutParams ?: return
        p.x = p.x.coerceIn(0, (screenWidth - v.width).coerceAtLeast(0))
        p.y = p.y.coerceIn(0, (screenHeight - v.height).coerceAtLeast(0))
        try { wm?.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    private fun dragListener(id: String?, afterDrag: (Int, Int) -> Unit): View.OnTouchListener = object : View.OnTouchListener {
        var rawX = 0f; var rawY = 0f; var startX = 0; var startY = 0; var dragged = false
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = v.layoutParams as? WindowManager.LayoutParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (id != null && !prefs.getBoolean("editMode", false)) return false
                    refreshScreenSize(); rawX = event.rawX; rawY = event.rawY; startX = p.x; startY = p.y; dragged = false; return true
                }
                MotionEvent.ACTION_MOVE -> {
                    refreshScreenSize()
                    val dx = (event.rawX - rawX).toInt(); val dy = (event.rawY - rawY).toInt()
                    if (abs(dx) > 4 || abs(dy) > 4) dragged = true
                    val viewW = (v.width.takeIf { it > 0 } ?: p.width.takeIf { it > 0 } ?: 52)
                    val viewH = (v.height.takeIf { it > 0 } ?: p.height.takeIf { it > 0 } ?: 52)
                    p.x = (startX + dx).coerceIn(0, (screenWidth - viewW).coerceAtLeast(0))
                    p.y = (startY + dy).coerceIn(0, (screenHeight - viewH).coerceAtLeast(0))
                    try { wm?.updateViewLayout(v, p) } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragged) {
                        val cx = p.x + v.width / 2; val cy = p.y + v.height / 2
                        if (id != null) savePosition(id, cx, cy)
                        else afterDrag(cx, cy)
                    } else v.performClick()
                    return true
                }
            }
            return false
        }
    }

    private fun togglePanel() {
        if (panel == null) {
            prefs.edit().putBoolean("editMode", true).apply()
            showPanel()
        } else {
            hidePanel()
            prefs.edit().putBoolean("editMode", false).apply()
        }
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 8, 8, 8)
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = 18f
                setStroke(1, Color.rgb(72, 72, 76))
            }
        }
        val handle = TextView(this).apply {
            text = "⠿"
            textSize = 22f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(8, 8, 12, 8)
            contentDescription = "Mover menú"
        }
        handle.setOnTouchListener(panelDragListener())
        box.addView(handle)
        box.addView(panelButton("＋  Clic") { addClickControl() })
        box.addView(panelButton(if (prefs.getBoolean("paused", false)) "▶  Reanudar" else "Ⅱ  Pausar") {
            val paused = !prefs.getBoolean("paused", false)
            prefs.edit().putBoolean("paused", paused).putBoolean("autoPausedForTyping", false).putBoolean("editMode", false).apply()
            autoPausedForTyping = false
            Toast.makeText(this, if (paused) "KeyMapper pausado" else "KeyMapper reanudado", Toast.LENGTH_SHORT).show()
            hidePanel()
        })
        val p = overlayParams().apply {
            x = (screenWidth - 340).coerceAtLeast(0)
            y = 280
        }
        try { wm?.addView(box, p); panel = box; panelParams = p } catch (_: Exception) {
            Toast.makeText(this, "No se pudo mostrar el menú flotante", Toast.LENGTH_SHORT).show()
        }
    }


    private fun panelDragListener(): View.OnTouchListener = object : View.OnTouchListener {
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = panelParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = p.x; startY = p.y; return true }
                MotionEvent.ACTION_MOVE -> {
                    val w = wm ?: return true
                    val target = panel ?: return true
                    p.x = (startX + event.rawX - downX).toInt().coerceIn(0, (screenWidth - (target.width.takeIf { it > 0 } ?: 300)).coerceAtLeast(0))
                    p.y = (startY + event.rawY - downY).toInt().coerceIn(0, (screenHeight - (target.height.takeIf { it > 0 } ?: 100)).coerceAtLeast(0))
                    try { w.updateViewLayout(target, p) } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
            }
            return false
        }
    }

    private fun panelButton(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(14, 13, 14, 13)
        background = GradientDrawable().apply {
            setColor(Color.rgb(25, 25, 28))
            cornerRadius = 12f
            setStroke(1, Color.rgb(82, 82, 86))
        }
        val lp = LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        lp.marginEnd = 6
        layoutParams = lp
        setOnClickListener { action() }
    }

    private fun addClickControl() {
        val array = mappings()
        val id = "click_${System.currentTimeMillis()}"
        array.put(JSONObject().apply { put("id", id); put("key", "?"); put("action", "TAP"); put("x", (screenWidth * 0.65f).toInt()); put("y", (screenHeight * 0.5f).toInt()) })
        prefs.edit().putString("mappings", array.toString()).putBoolean("controlsVisible", true).apply()
        Toast.makeText(this, "Control añadido. Usa KM → Asignar / editar teclas para configurarlo y arrástralo en modo edición.", Toast.LENGTH_LONG).show()
        rebuildControls(force = true)
    }

    private fun showControlPickerDialog() {
        val arr = mappings()
        val items = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
        if (items.isEmpty()) { Toast.makeText(this, "Primero añade un control Clic", Toast.LENGTH_SHORT).show(); return }
        val labels = items.map { "${it.optString("key", "?")}  ·  Clic  (${it.optString("id")})" }.toTypedArray()
        showOverlayDialog(AlertDialog.Builder(this).setTitle("Selecciona el control").setItems(labels) { _, which ->
            val selected = items[which]
            showKeyEditor(selected.optString("id"))
        }.create())
    }

    private fun configureClick(id: String) { showKeyEditor(id) }

    private fun showKeyEditor(id: String) {
        val item = findMapping(id) ?: return
        val input = EditText(this).apply { setSingleLine(true); hint = "Tecla física (ej. E, F, SPACE)"; setText(item.optString("key", "?")); selectAll() }
        val dialog = AlertDialog.Builder(this).setTitle("Asignar tecla al punto")
            .setMessage("La tecla ejecutará un toque en las coordenadas guardadas. Se permite repetir una tecla en varios controles.")
            .setView(input).setNegativeButton("Cancelar", null)
            .setNeutralButton("Eliminar control") { _, _ -> removeMapping(id) }
            .setPositiveButton("Guardar", null).create()
        try {
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
            dialog.show()
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val key = input.text.toString().trim().uppercase().let { if (it == "ESPACIO") "SPACE" else it }
                if (key.isBlank() || key == "?") { input.error = "Escribe una tecla válida"; return@setOnClickListener }
                item.put("key", key); replaceMapping(item); dialog.dismiss()
                Toast.makeText(this, "Tecla $key asignada a este punto", Toast.LENGTH_SHORT).show()
            }
        } catch (_: Exception) { Toast.makeText(this, "Activa el permiso de superposición para editar desde KM", Toast.LENGTH_LONG).show() }
    }

    private fun showOverlayDialog(dialog: AlertDialog) {
        try { dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); dialog.show(); dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY) }
        catch (_: Exception) { Toast.makeText(this, "Activa el permiso de superposición", Toast.LENGTH_SHORT).show() }
    }

    private fun requestBatteryExemption() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (_: Exception) { Toast.makeText(this, "Busca Key Mapper en Ajustes → Batería → Optimización de batería", Toast.LENGTH_LONG).show() }
        }
    }

    private fun launchEditor(extra: String, value: String? = null) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (value != null) putExtra(extra, value) else putExtra(extra, true)
        }
        try { startActivity(intent) } catch (_: Exception) {
            Toast.makeText(this, "No se pudo abrir el editor. Abre Key Mapper y vuelve a intentarlo.", Toast.LENGTH_LONG).show()
        }
    }

    private fun rebuildControls(force: Boolean = false) {
        if (!::prefs.isInitialized) return
        refreshScreenSize()
        if (!prefs.getBoolean("activationAuthorized", false) || !prefs.getBoolean("controlsVisible", false) || !Settings.canDrawOverlays(this)) { removeControls(); removeBubble(); hidePanel(); return }
        val arr = mappings()
        val tapItems = mutableListOf<JSONObject>()
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            if (item.optString("action", "TAP") == "TAP") tapItems.add(item)
        }
        val wanted = tapItems.map { it.optString("id", it.optString("key")) }.toSet()
        clickControls.keys.toList().filter { it !in wanted || force }.forEach { id ->
            clickControls[id]?.let { try { wm?.removeView(it.first) } catch (_: Exception) {} }
            clickControls.remove(id)
        }
        tapItems.forEachIndexed { index, item ->
            val id = item.optString("id", item.optString("key"))
            if (clickControls.containsKey(id)) {
                clickControls[id]?.first?.findViewById<TextView>(controlLabelId)?.text = item.optString("key", "?")
                clickControls[id]?.first?.alpha = prefs.getInt("controlsOpacity", 78).coerceIn(0, 100) / 100f
                return@forEachIndexed
            }
            val size = 60
            val view = FrameLayout(this).apply {
                clipChildren = false; clipToPadding = false
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(10, 10, 10)); setStroke(2, Color.WHITE) }
                val label = TextView(this@KeyMapperService).apply {
                    this.id = controlLabelId
                    text = item.optString("key", "?"); textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                    includeFontPadding = false
                    setPadding(3, 3, 3, 3)
                }
                addView(label, FrameParams(-1, -1))
                setOnClickListener { if (prefs.getBoolean("editMode", false)) beginInlineKeyEdit(id, this, item.optString("key", "?")) }
                if (prefs.getBoolean("editMode", false)) {
                    val delete = TextView(this@KeyMapperService).apply {
                        text = "×"; textSize = 17f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(190, 35, 35)); setStroke(1, Color.WHITE) }
                        elevation = 8f
                        translationX = -10f; translationY = -10f
                        setOnClickListener { removeMapping(id) }
                    }
                    addView(delete, FrameParams(23, 23, Gravity.TOP or Gravity.START))
                }
            }
            view.alpha = (prefs.getInt("controlsOpacity", 78).coerceIn(0, 100) / 100f)
            val p = overlayParams(size, size).apply {
                val centerX = item.optInt("x", -1); val centerY = item.optInt("y", -1)
                x = if (centerX >= 0) (centerX - size / 2).coerceIn(0, (screenWidth - size).coerceAtLeast(0)) else (screenWidth * .65f).toInt() + (index % 3) * 10
                y = if (centerY >= 0) (centerY - size / 2).coerceIn(0, (screenHeight - size).coerceAtLeast(0)) else (screenHeight * .45f).toInt() + (index % 4) * 10
            }
            view.setOnTouchListener(dragListener(id) { _, _ -> })
            setEditabilityFlag(p)
            try { wm?.addView(view, p); clickControls[id] = view to p } catch (_: Exception) {}
            if (item.optInt("x", -1) < 0 || item.optInt("y", -1) < 0) savePosition(id, p.x + size / 2, p.y + size / 2)
        }
    }


    private fun beginInlineKeyEdit(id: String, control: FrameLayout, currentKey: String) {
        if (control.findViewWithTag<EditText>("inline_key_editor") != null) return
        val params = clickControls[id]?.second ?: return
        val editor = EditText(this).apply {
            tag = "inline_key_editor"
            setSingleLine(true)
            hint = "Tecla"
            // Intencionalmente vacío: el usuario puede teclear la nueva asignación sin borrar nada.
            setText("")
            textSize = 14f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            imeOptions = EditorInfo.IME_ACTION_DONE
            setPadding(3, 3, 3, 3)
            background = GradientDrawable().apply { setColor(Color.rgb(35, 35, 38)); cornerRadius = 8f; setStroke(2, Color.rgb(80, 170, 255)) }
        }
        control.findViewById<View>(controlLabelId)?.let { control.removeView(it) }
        control.addView(editor, FrameParams(-1, -1))
        params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv() and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        try { wm?.updateViewLayout(control, params) } catch (_: Exception) {}
        editor.requestFocus()
        editor.post {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.showSoftInput(editor, InputMethodManager.SHOW_IMPLICIT)
        }
        var saved = false
        fun finish(save: Boolean) {
            if (saved) return
            saved = true
            val key = editor.text.toString().trim().uppercase().let { if (it == "ESPACIO") "SPACE" else it }
            (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(editor.windowToken, 0)
            if (editor.parent === control) control.removeView(editor)
            val label = TextView(this).apply {
                this.id = controlLabelId; text = if (save && key.isNotBlank()) key else currentKey
                textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; includeFontPadding = false
            }
            control.addView(label, 0, FrameParams(-1, -1))
            if (save && key.isNotBlank()) {
                val mapping = findMapping(id)
                if (mapping != null) { mapping.put("key", key); replaceMapping(mapping) }
            }
            setEditabilityFlag(params)
            try { wm?.updateViewLayout(control, params) } catch (_: Exception) {}
            if (save && key.isBlank()) Toast.makeText(this, "Escribe una tecla para cambiar la asignación", Toast.LENGTH_SHORT).show()
        }
        editor.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_NEXT) { finish(true); true } else false
        }
        editor.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP) { finish(true); true } else false
        }
        // Guardar también al salir del editor mediante el botón atrás del teclado.
        editor.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus && !saved) finish(true) }
    }

    private fun applyControlOpacity() {
        val alpha = prefs.getInt("controlsOpacity", 78).coerceIn(0, 100) / 100f
        clickControls.values.forEach { (view, _) -> view.alpha = alpha }
    }

    private fun savePosition(id: String, centerX: Int, centerY: Int) {
        val arr = mappings()
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            if (item.optString("id") == id) { item.put("x", centerX.coerceIn(1, screenWidth - 1)); item.put("y", centerY.coerceIn(1, screenHeight - 1)) }
        }
        prefs.edit().putString("mappings", arr.toString()).apply()
    }

    private fun findMapping(id: String): JSONObject? {
        val arr = mappings()
        for (i in 0 until arr.length()) { val item = arr.optJSONObject(i) ?: continue; if (item.optString("id") == id) return item }
        return null
    }
    private fun replaceMapping(updated: JSONObject) {
        val arr = mappings()
        for (i in 0 until arr.length()) if (arr.optJSONObject(i)?.optString("id") == updated.optString("id")) { arr.put(i, updated); break }
        prefs.edit().putString("mappings", arr.toString()).apply()
    }
    private fun removeMapping(id: String) {
        val old = mappings(); val updated = JSONArray()
        for (i in 0 until old.length()) { val item = old.optJSONObject(i) ?: continue; if (item.optString("id") != id) updated.put(item) }
        prefs.edit().putString("mappings", updated.toString()).apply()
    }
    private fun removeControls() {
        clickControls.values.forEach { try { wm?.removeView(it.first) } catch (_: Exception) {} }
        clickControls.clear()
    }
    private fun removeBubble() {
        try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) {}
        bubble = null
    }
    private fun hidePanel() { try { panel?.let { wm?.removeView(it) } } catch (_: Exception) {}; panel = null; panelParams = null }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat(); setStroke(2, Color.argb(170, 255, 255, 255)) }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) {}
        bubble = null; hidePanel(); removeControls(); mainHandler.removeCallbacksAndMessages(null)
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(this)
        return super.onUnbind(intent)
    }
}
