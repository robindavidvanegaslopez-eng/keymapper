package com.example.keymapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.content.SharedPreferences
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

class KeyMapperService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {
    private lateinit var prefs: SharedPreferences
    private var wm: WindowManager? = null
    private var bubble: TextView? = null
    private var panel: View? = null
    private var joyControl: TextView? = null
    private var joyParams: WindowManager.LayoutParams? = null
    private val clickControls = mutableMapOf<String, Pair<TextView, WindowManager.LayoutParams>>()
    private var screenWidth = 1080
    private var screenHeight = 1920

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = getSharedPreferences("mapping", MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        refreshScreenSize()
        ensureBubble()
        rebuildControls()
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        refreshScreenSize()
        Handler(Looper.getMainLooper()).post {
            repositionBubble()
            rebuildControls(force = true)
        }
    }

    private fun refreshScreenSize() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (wm?.defaultDisplay)?.getRealMetrics(metrics)
        val fallback = resources.displayMetrics
        val width = if (metrics.widthPixels > 0) metrics.widthPixels else fallback.widthPixels
        val height = if (metrics.heightPixels > 0) metrics.heightPixels else fallback.heightPixels
        // Always use the current physical orientation; do not cache portrait dimensions.
        screenWidth = maxOf(width, 1)
        screenHeight = maxOf(height, 1)
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        if (key == "mappings" || key == "controlsVisible" || key == "joySize" || key == "editMode") {
            Handler(Looper.getMainLooper()).post {
                rebuildControls(force = key == "joySize" || key == "editMode")
                applyControlTouchMode()
            }
        }
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0 || !::prefs.isInitialized) return false
        // During editing, let the keyboard behave normally; only map keys in play mode.
        if (prefs.getBoolean("editMode", false) || !prefs.getBoolean("controlsVisible", true)) return false
        val name = if (event.keyCode == KeyEvent.KEYCODE_SPACE) "SPACE" else KeyEvent.keyCodeToString(event.keyCode).removePrefix("KEYCODE_")
        val array = mappings()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            if (item.optString("key").uppercase() != name.uppercase()) continue
            when (item.optString("action", "TAP")) {
                "TAP" -> tap(item.optInt("x", screenWidth / 2).toFloat(), item.optInt("y", screenHeight / 2).toFloat())
                "UP" -> joystick("UP")
                "DOWN" -> joystick("DOWN")
                "LEFT" -> joystick("LEFT")
                "RIGHT" -> joystick("RIGHT")
            }
            return true
        }
        return false
    }

    private fun mappings(): JSONArray = try { JSONArray(prefs.getString("mappings", "[]")) } catch (_: Exception) { JSONArray() }

    private fun tap(x: Float, y: Float) {
        val safeX = x.coerceIn(1f, (screenWidth - 2).coerceAtLeast(1).toFloat())
        val safeY = y.coerceIn(1f, (screenHeight - 2).coerceAtLeast(1).toFloat())
        val path = Path().apply { moveTo(safeX, safeY) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 65)).build()
        dispatchGesture(gesture, null, null)
    }

    private fun joystick(direction: String) {
        val cx = prefs.getInt("joyX", (screenWidth * 0.18f).toInt()).toFloat()
        val cy = prefs.getInt("joyY", (screenHeight * 0.78f).toInt()).toFloat()
        val size = prefs.getInt("joySize", 150).coerceIn(80, 300)
        val radius = (size * 0.42f).coerceAtLeast(30f)
        val dx = when (direction) { "LEFT" -> -radius; "RIGHT" -> radius; else -> 0f }
        val dy = when (direction) { "UP" -> -radius; "DOWN" -> radius; else -> 0f }
        val endX = (cx + dx).coerceIn(1f, (screenWidth - 2).toFloat())
        val endY = (cy + dy).coerceIn(1f, (screenHeight - 2).toFloat())
        val path = Path().apply { moveTo(cx, cy); lineTo(endX, endY) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 180)).build()
        dispatchGesture(gesture, null, null)
    }

    private fun overlayType(): Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private fun overlayParams(width: Int = WindowManager.LayoutParams.WRAP_CONTENT, height: Int = WindowManager.LayoutParams.WRAP_CONTENT) =
        WindowManager.LayoutParams(width, height, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
        }

    private fun ensureBubble() {
        if (bubble != null) return
        val view = TextView(this).apply {
            text = "KM"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(15, 12, 15, 12); background = rounded(Color.rgb(35, 95, 210), 24)
            setOnClickListener { togglePanel() }
            setOnTouchListener(dragListener(null) { _, _ -> })
        }
        val params = overlayParams().apply { x = (screenWidth - 100).coerceAtLeast(0); y = 200 }
        try { wm?.addView(view, params); bubble = view } catch (_: Exception) {
            Toast.makeText(this, "Concede el permiso para mostrarse sobre otras apps", Toast.LENGTH_LONG).show()
        }
    }

    private fun repositionBubble() {
        val v = bubble ?: return
        val p = v.layoutParams as? WindowManager.LayoutParams ?: return
        p.x = p.x.coerceIn(0, (screenWidth - v.width).coerceAtLeast(0))
        p.y = p.y.coerceIn(0, (screenHeight - v.height).coerceAtLeast(0))
        try { wm?.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    private fun dragListener(id: String?, afterDrag: (Int, Int) -> Unit): View.OnTouchListener = object : View.OnTouchListener {
        var rawX = 0f; var rawY = 0f; var startX = 0; var startY = 0; var dragged = false
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = v.layoutParams as? WindowManager.LayoutParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (id != null && id != "__JOYSTICK__" && !prefs.getBoolean("editMode", false)) return false
                    if (id == "__JOYSTICK__" && !prefs.getBoolean("editMode", false)) return false
                    refreshScreenSize(); rawX = event.rawX; rawY = event.rawY; startX = p.x; startY = p.y; dragged = false; return true
                }
                MotionEvent.ACTION_MOVE -> {
                    refreshScreenSize()
                    val dx = (event.rawX - rawX).toInt(); val dy = (event.rawY - rawY).toInt()
                    if (abs(dx) > 4 || abs(dy) > 4) dragged = true
                    val viewW = (v.width.takeIf { it > 0 } ?: p.width.takeIf { it > 0 } ?: 52)
                    val viewH = (v.height.takeIf { it > 0 } ?: p.height.takeIf { it > 0 } ?: 52)
                    p.x = (startX + dx).coerceIn(0, (screenWidth - viewW).coerceAtLeast(0))
                    p.y = (startY + dy).coerceIn(0, (screenHeight - viewH).coerceAtLeast(0))
                    try { wm?.updateViewLayout(v, p) } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragged) {
                        val cx = p.x + v.width / 2; val cy = p.y + v.height / 2
                        if (id != null) savePosition(id, cx, cy)
                        else afterDrag(cx, cy)
                    } else v.performClick()
                    return true
                }
            }
            return false
        }
    }

    private fun togglePanel() {
        if (panel == null) {
            prefs.edit().putBoolean("editMode", true).apply()
            showPanel()
        } else {
            hidePanel()
            prefs.edit().putBoolean("editMode", false).apply()
        }
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(14, 14, 14, 14)
            background = rounded(Color.rgb(246, 248, 252), 18)
        }
        box.addView(TextView(this).apply {
            text = "KEY MAPPER"; textSize = 16f; setTextColor(Color.rgb(30, 70, 150)); setPadding(4, 2, 4, 10)
        })
        box.addView(panelButton("＋  Clic") { addClickControl() })
        box.addView(panelButton("＋  Joystick WASD") { addJoystick() })
        box.addView(panelButton("↔  Tamaño del joystick") { changeJoystickSize() })
        box.addView(panelButton("Listo / modo juego") {
            hidePanel()
            prefs.edit().putBoolean("editMode", false).apply()
            Toast.makeText(this, "Modo juego: los controles ya no se pueden mover y los toques pasan al juego", Toast.LENGTH_SHORT).show()
        })
        box.addView(panelButton("Ocultar controles") {
            prefs.edit().putBoolean("controlsVisible", false).putBoolean("editMode", false).apply(); hidePanel()
        })
        box.addView(panelButton("Cerrar menú (seguir editando)") { hidePanel() })
        val p = overlayParams().apply { x = (screenWidth - 270).coerceAtLeast(0); y = 280 }
        try { wm?.addView(box, p); panel = box } catch (_: Exception) {
            Toast.makeText(this, "No se pudo mostrar el menú flotante", Toast.LENGTH_SHORT).show()
        }
    }

    private fun panelButton(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL
        setPadding(16, 13, 16, 13); background = rounded(Color.rgb(35, 95, 210), 12)
        val lp = LinearLayout.LayoutParams(230, WindowManager.LayoutParams.WRAP_CONTENT); lp.bottomMargin = 7; layoutParams = lp
        setOnClickListener { action() }
    }

    private fun addClickControl() {
        val array = mappings()
        val id = "click_${System.currentTimeMillis()}"
        array.put(JSONObject().apply { put("id", id); put("key", "?"); put("action", "TAP"); put("x", (screenWidth * 0.65f).toInt()); put("y", (screenHeight * 0.5f).toInt()) })
        prefs.edit().putString("mappings", array.toString()).putBoolean("controlsVisible", true).apply()
        hidePanel()
        Handler(Looper.getMainLooper()).postDelayed({ configureClick(id) }, 350)
    }

    private fun configureClick(id: String) {
        if (!prefs.getBoolean("editMode", false)) return
        if (findMapping(id) == null) return
        launchEditor(MainActivity.EXTRA_EDIT_MAPPING_ID, id)
    }

    private fun launchEditor(extra: String, value: String? = null) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (value != null) putExtra(extra, value) else putExtra(extra, true)
        }
        try { startActivity(intent) } catch (_: Exception) {
            Toast.makeText(this, "No se pudo abrir el editor. Abre Key Mapper y vuelve a intentarlo.", Toast.LENGTH_LONG).show()
        }
    }

    private fun addJoystick() {
        val arr = mappings()
        val items = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
        val existing = items.filter { it.optString("action") in listOf("UP", "DOWN", "LEFT", "RIGHT") }
        if (existing.isNotEmpty()) {
            prefs.edit().putBoolean("controlsVisible", true).apply()
            hidePanel()
            Toast.makeText(this, "El joystick WASD ya está añadido. Arrastra el círculo verde.", Toast.LENGTH_SHORT).show()
            return
        }
        val defs = listOf("W" to "UP", "A" to "LEFT", "S" to "DOWN", "D" to "RIGHT")
        val occupied = items.firstOrNull { it.optString("key").uppercase() in listOf("W", "A", "S", "D") }
        if (occupied != null) {
            Toast.makeText(this, "Primero libera W, A, S y D: una de esas teclas ya tiene otra acción.", Toast.LENGTH_LONG).show()
            return
        }
        defs.forEachIndexed { index, pair -> arr.put(JSONObject().apply {
            put("id", "joy_${pair.second.lowercase()}_${System.currentTimeMillis()}_$index")
            put("key", pair.first); put("action", pair.second); put("x", prefs.getInt("joyX", (screenWidth * .18f).toInt())); put("y", prefs.getInt("joyY", (screenHeight * .78f).toInt()))
        }) }
        prefs.edit().putString("mappings", arr.toString()).putBoolean("controlsVisible", true).apply()
        hidePanel()
        Toast.makeText(this, "Joystick WASD añadido. Arrastra el círculo verde y ajusta su tamaño desde KM.", Toast.LENGTH_LONG).show()
    }

    private fun changeJoystickSize() {
        hidePanel()
        launchEditor(MainActivity.EXTRA_CHANGE_JOYSTICK_SIZE)
    }

    private fun rebuildControls(force: Boolean = false) {
        if (!::prefs.isInitialized) return
        refreshScreenSize()
        if (!prefs.getBoolean("controlsVisible", true)) { removeControls(); return }
        val arr = mappings()
        val tapItems = mutableListOf<JSONObject>()
        var hasJoy = false
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            if (item.optString("action", "TAP") == "TAP") tapItems.add(item)
            else if (item.optString("action") in listOf("UP", "DOWN", "LEFT", "RIGHT")) hasJoy = true
        }
        val wanted = tapItems.map { it.optString("id", it.optString("key")) }.toSet()
        clickControls.keys.toList().filter { it !in wanted || force }.forEach { id ->
            clickControls[id]?.let { try { wm?.removeView(it.first) } catch (_: Exception) {} }
            clickControls.remove(id)
        }
        tapItems.forEachIndexed { index, item ->
            val id = item.optString("id", item.optString("key"))
            if (clickControls.containsKey(id)) {
                clickControls[id]?.first?.text = item.optString("key", "?")
                return@forEachIndexed
            }
            val size = 52
            val view = TextView(this).apply {
                text = item.optString("key", "?"); textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                setPadding(7, 7, 7, 7); background = rounded(Color.argb(220, 35, 95, 210), 28)
                setOnClickListener { configureClick(id) }
            }
            val p = overlayParams(size, size).apply {
                val centerX = item.optInt("x", -1); val centerY = item.optInt("y", -1)
                x = if (centerX >= 0) (centerX - size / 2).coerceIn(0, (screenWidth - size).coerceAtLeast(0)) else (screenWidth * .65f).toInt() + (index % 3) * 10
                y = if (centerY >= 0) (centerY - size / 2).coerceIn(0, (screenHeight - size).coerceAtLeast(0)) else (screenHeight * .45f).toInt() + (index % 4) * 10
            }
            view.setOnTouchListener(dragListener(id) { _, _ -> })
            setEditabilityFlag(p)
            try { wm?.addView(view, p); clickControls[id] = view to p } catch (_: Exception) {}
            if (item.optInt("x", -1) < 0 || item.optInt("y", -1) < 0) savePosition(id, p.x + size / 2, p.y + size / 2)
        }
        if (hasJoy) ensureJoyControl(force) else removeJoyControl()
    }

    private fun ensureJoyControl(force: Boolean = false) {
        if (joyControl != null && !force) return
        if (force) removeJoyControl()
        val size = prefs.getInt("joySize", 150).coerceIn(80, 300)
        val view = TextView(this).apply {
            text = "W\nA  •  D\nS"; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(175, 25, 150, 85)); setStroke(3, Color.WHITE) }
        }
        val p = overlayParams(size, size).apply {
            x = (prefs.getInt("joyX", (screenWidth * .18f).toInt()) - size / 2).coerceIn(0, (screenWidth - size).coerceAtLeast(0))
            y = (prefs.getInt("joyY", (screenHeight * .78f).toInt()) - size / 2).coerceIn(0, (screenHeight - size).coerceAtLeast(0))
        }
        view.setOnTouchListener(dragListener("__JOYSTICK__") { cx, cy -> prefs.edit().putInt("joyX", cx).putInt("joyY", cy).apply() })
        setEditabilityFlag(p)
        try { wm?.addView(view, p); joyControl = view; joyParams = p } catch (_: Exception) {}
    }

    private fun setEditabilityFlag(params: WindowManager.LayoutParams) {
        if (prefs.getBoolean("editMode", false)) params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    }

    private fun applyControlTouchMode() {
        val editable = prefs.getBoolean("editMode", false)
        clickControls.values.forEach { (_, params) ->
            if (editable) params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try { clickControls.values.forEach { (view, params) -> wm?.updateViewLayout(view, params) } } catch (_: Exception) {}
        joyParams?.let { params ->
            if (editable) params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try { joyControl?.let { wm?.updateViewLayout(it, params) } } catch (_: Exception) {}
        }
    }

    private fun savePosition(id: String, centerX: Int, centerY: Int) {
        if (id == "__JOYSTICK__") { prefs.edit().putInt("joyX", centerX).putInt("joyY", centerY).apply(); return }
        val arr = mappings()
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            if (item.optString("id") == id) { item.put("x", centerX.coerceIn(1, screenWidth - 1)); item.put("y", centerY.coerceIn(1, screenHeight - 1)) }
        }
        prefs.edit().putString("mappings", arr.toString()).apply()
    }

    private fun findMapping(id: String): JSONObject? {
        val arr = mappings()
        for (i in 0 until arr.length()) { val item = arr.optJSONObject(i) ?: continue; if (item.optString("id") == id) return item }
        return null
    }
    private fun replaceMapping(updated: JSONObject) {
        val arr = mappings()
        for (i in 0 until arr.length()) if (arr.optJSONObject(i)?.optString("id") == updated.optString("id")) { arr.put(i, updated); break }
        prefs.edit().putString("mappings", arr.toString()).apply()
    }
    private fun removeMapping(id: String) {
        val old = mappings(); val updated = JSONArray()
        for (i in 0 until old.length()) { val item = old.optJSONObject(i) ?: continue; if (item.optString("id") != id) updated.put(item) }
        prefs.edit().putString("mappings", updated.toString()).apply()
    }
    private fun removeControls() {
        clickControls.values.forEach { try { wm?.removeView(it.first) } catch (_: Exception) {} }
        clickControls.clear(); removeJoyControl()
    }
    private fun removeJoyControl() {
        try { joyControl?.let { wm?.removeView(it) } } catch (_: Exception) {}
        joyControl = null; joyParams = null
    }
    private fun hidePanel() { try { panel?.let { wm?.removeView(it) } } catch (_: Exception) {}; panel = null }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat(); setStroke(2, Color.argb(170, 255, 255, 255)) }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) {}
        bubble = null; hidePanel(); removeControls()
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(this)
        return super.onUnbind(intent)
    }
}
