package com.example.keymapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

class KeyMapperService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {
    private lateinit var prefs: SharedPreferences
    private var wm: WindowManager? = null
    private var bubble: TextView? = null
    private var joyControl: TextView? = null
    private var joyParams: WindowManager.LayoutParams? = null
    private val controls = mutableMapOf<String, Pair<View, WindowManager.LayoutParams>>()
    private var screenWidth = 1080
    private var screenHeight = 1920

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = getSharedPreferences("mapping", MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = resources.displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        ensureBubble()
        rebuildControls()
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        if (key == "mappings" || key == "controlsVisible") {
            runOnMain { rebuildControls() }
        }
    }

    private fun runOnMain(action: () -> Unit) {
        android.os.Handler(mainLooper).post(action)
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0 || !::prefs.isInitialized) return false
        val name = when (event.keyCode) {
            KeyEvent.KEYCODE_SPACE -> "SPACE"
            else -> KeyEvent.keyCodeToString(event.keyCode).removePrefix("KEYCODE_")
        }
        val array = try { JSONArray(prefs.getString("mappings", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            if (item.optString("key").uppercase() != name.uppercase()) continue
            when (item.optString("action", "TAP")) {
                "TAP" -> tap(controlX(item), controlY(item))
                "UP" -> joystick("UP")
                "DOWN" -> joystick("DOWN")
                "LEFT" -> joystick("LEFT")
                "RIGHT" -> joystick("RIGHT")
            }
            return true
        }
        return false
    }

    private fun controlX(item: JSONObject): Float = item.optInt("x", screenWidth / 2).toFloat().coerceIn(1f, (screenWidth - 2).toFloat())
    private fun controlY(item: JSONObject): Float = item.optInt("y", screenHeight / 2).toFloat().coerceIn(1f, (screenHeight - 2).toFloat())

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 70)).build()
        dispatchGesture(gesture, null, null)
    }

    private fun joystick(direction: String) {
        val joyX = prefs.getInt("joyX", 170).toFloat()
        val joyY = prefs.getInt("joyY", screenHeight - 300).toFloat()
        val radius = prefs.getInt("joyRadius", 100).toFloat()
        val dx = when (direction) { "LEFT" -> -radius; "RIGHT" -> radius; else -> 0f }
        val dy = when (direction) { "UP" -> -radius; "DOWN" -> radius; else -> 0f }
        val path = Path().apply { moveTo(joyX, joyY); lineTo(joyX + dx, joyY + dy) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 180)).build()
        dispatchGesture(gesture, null, null)
    }

    private fun overlayType(): Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun ensureBubble() {
        if (bubble != null) return
        val view = TextView(this).apply {
            text = "KM"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(13, 11, 13, 11)
            background = rounded(Color.rgb(35, 95, 210), 24)
            setOnClickListener {
                prefs.edit().putBoolean("controlsVisible", !prefs.getBoolean("controlsVisible", true)).apply()
            }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = screenWidth - 150; y = 220 }
        try { wm?.addView(view, params); bubble = view } catch (_: Exception) { }
    }

    private fun rebuildControls() {
        val visible = prefs.getBoolean("controlsVisible", true)
        if (!visible) {
            removeControls()
            return
        }
        val array = try { JSONArray(prefs.getString("mappings", "[]")) } catch (_: Exception) { JSONArray() }
        val wanted = mutableSetOf<String>()
        var hasJoystick = false
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            if (item.optString("action") != "TAP") hasJoystick = true
            val id = item.optString("id", item.optString("key"))
            wanted.add(id)
            if (controls.containsKey(id)) continue
            val key = item.optString("key", "?")
            val action = item.optString("action", "TAP")
            val label = when (action) {
                "UP" -> "$key ↑"
                "DOWN" -> "$key ↓"
                "LEFT" -> "$key ←"
                "RIGHT" -> "$key →"
                else -> key
            }
            val view = TextView(this).apply {
                text = label
                textSize = 13f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(15, 12, 15, 12)
                background = rounded(Color.argb(210, 35, 95, 210), 22)
            }
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                val savedX = item.optInt("x", -1)
                val savedY = item.optInt("y", -1)
                x = if (savedX >= 0) (savedX - 28).coerceAtLeast(0) else (screenWidth * 0.45f).toInt() + (i % 3) * 12
                y = if (savedY >= 0) (savedY - 22).coerceAtLeast(0) else (screenHeight * 0.45f).toInt() + (i % 5) * 12
            }
            view.setOnTouchListener(object : View.OnTouchListener {
                var startX = 0f
                var startY = 0f
                var initialX = 0
                var initialY = 0
                var moved = false
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            startX = event.rawX; startY = event.rawY
                            initialX = params.x; initialY = params.y; moved = false
                            return true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (event.rawX - startX).toInt()
                            val dy = (event.rawY - startY).toInt()
                            if (kotlin.math.abs(dx) > 3 || kotlin.math.abs(dy) > 3) moved = true
                            params.x = (initialX + dx).coerceIn(0, (screenWidth - v.width).coerceAtLeast(0))
                            params.y = (initialY + dy).coerceIn(0, (screenHeight - v.height).coerceAtLeast(0))
                            try { wm?.updateViewLayout(v, params) } catch (_: Exception) { }
                            return true
                        }
                        MotionEvent.ACTION_UP -> {
                            if (moved) savePosition(id, params.x + v.width / 2, params.y + v.height / 2, action)
                            return true
                        }
                    }
                    return false
                }
            })
            try {
                wm?.addView(view, params)
                controls[id] = view to params
                if (savedPositionMissing(item)) {
                    savePosition(id, params.x + view.width / 2, params.y + view.height / 2, "TAP")
                }
            } catch (_: Exception) { }
        }
        if (hasJoystick) ensureJoyControl() else removeJoyControl()
        val iterator = controls.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (entry.key !in wanted) {
                try { wm?.removeView(entry.value.first) } catch (_: Exception) { }
                iterator.remove()
            }
        }
    }

    private fun savedPositionMissing(item: JSONObject): Boolean = item.optInt("x", -1) < 0 || item.optInt("y", -1) < 0

    private fun ensureJoyControl() {
        if (joyControl != null) return
        val view = TextView(this).apply {
            text = "JOY"
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(13, 10, 13, 10)
            background = rounded(Color.argb(220, 35, 145, 90), 24)
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (prefs.getInt("joyX", 170) - 25).coerceAtLeast(0)
            y = (prefs.getInt("joyY", screenHeight - 300) - 20).coerceAtLeast(0)
        }
        view.setOnTouchListener(object : View.OnTouchListener {
            var rawStartX = 0f; var rawStartY = 0f; var initialX = 0; var initialY = 0
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { rawStartX = event.rawX; rawStartY = event.rawY; initialX = params.x; initialY = params.y; return true }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = (initialX + (event.rawX - rawStartX).toInt()).coerceIn(0, (screenWidth - v.width).coerceAtLeast(0))
                        params.y = (initialY + (event.rawY - rawStartY).toInt()).coerceIn(0, (screenHeight - v.height).coerceAtLeast(0))
                        try { wm?.updateViewLayout(v, params) } catch (_: Exception) { }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        prefs.edit().putInt("joyX", params.x + v.width / 2).putInt("joyY", params.y + v.height / 2).apply()
                        return true
                    }
                }
                return false
            }
        })
        try { wm?.addView(view, params); joyControl = view; joyParams = params } catch (_: Exception) { }
    }

    private fun removeJoyControl() {
        try { joyControl?.let { wm?.removeView(it) } } catch (_: Exception) { }
        joyControl = null
        joyParams = null
    }

    private fun savePosition(id: String, centerX: Int, centerY: Int, action: String) {
        val array = try { JSONArray(prefs.getString("mappings", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            if (item.optString("id") == id) {
                item.put("x", centerX.coerceIn(1, screenWidth - 1))
                item.put("y", centerY.coerceIn(1, screenHeight - 1))
                if (action != "TAP") {
                    prefs.edit().putInt("joyX", centerX).putInt("joyY", centerY).apply()
                }
                break
            }
        }
        prefs.edit().putString("mappings", array.toString()).apply()
    }

    private fun removeControls() {
        controls.values.forEach { try { wm?.removeView(it.first) } catch (_: Exception) { } }
        controls.clear()
        removeJoyControl()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        setStroke(2, Color.argb(170, 255, 255, 255))
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) { }
        bubble = null
        removeControls()
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(this)
        return super.onUnbind(intent)
    }
}
