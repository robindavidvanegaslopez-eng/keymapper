package com.example.keymapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.content.SharedPreferences
import android.content.Intent
import android.app.AlertDialog
import android.text.InputType
import android.widget.EditText
import android.widget.SeekBar
import android.widget.FrameLayout
import android.widget.FrameLayout.LayoutParams as FrameParams
import android.provider.Settings
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

class KeyMapperService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {
    private lateinit var prefs: SharedPreferences
    private var wm: WindowManager? = null
    private var bubble: TextView? = null
    private var panel: View? = null
    private var joyControl: View? = null
    private var joyParams: WindowManager.LayoutParams? = null
    private val clickControls = mutableMapOf<String, Pair<TextView, WindowManager.LayoutParams>>()
    private var screenWidth = 1080
    private var screenHeight = 1920
    private val heldJoyDirections = linkedSetOf<String>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var joyRefreshScheduled = false
    private var lastJoyX = 0f
    private var lastJoyY = 0f

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = getSharedPreferences("mapping", MODE_PRIVATE)
        WirelessAdbBridge.restore(this)
        prefs.registerOnSharedPreferenceChangeListener(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        refreshScreenSize()
        if (prefs.getBoolean("controlsVisible", true)) ensureBubble() else removeBubble()
        rebuildControls()
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        refreshScreenSize()
        Handler(Looper.getMainLooper()).post {
            repositionBubble()
            rebuildControls(force = true)
        }
    }

    private fun refreshScreenSize() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (wm?.defaultDisplay)?.getRealMetrics(metrics)
        val fallback = resources.displayMetrics
        val width = if (metrics.widthPixels > 0) metrics.widthPixels else fallback.widthPixels
        val height = if (metrics.heightPixels > 0) metrics.heightPixels else fallback.heightPixels
        // Always use the current physical orientation; do not cache portrait dimensions.
        screenWidth = maxOf(width, 1)
        screenHeight = maxOf(height, 1)
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        if (key == "mappings" || key == "controlsVisible" || key == "joySize" || key == "editMode") {
            Handler(Looper.getMainLooper()).post {
                if (prefs.getBoolean("controlsVisible", true)) {
                    ensureBubble()
                    rebuildControls(force = key == "joySize" || key == "editMode")
                    applyControlTouchMode()
                } else {
                    heldJoyDirections.clear()
                    stopContinuousJoystick()
                    hidePanel()
                    removeControls()
                    removeBubble()
                }
            }
        }
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!::prefs.isInitialized) return false
        // En modo edición dejamos que la tecla llegue al campo de texto del editor.
        if (prefs.getBoolean("editMode", false) || !prefs.getBoolean("controlsVisible", true)) return false
        val name = if (event.keyCode == KeyEvent.KEYCODE_SPACE) "SPACE" else KeyEvent.keyCodeToString(event.keyCode).removePrefix("KEYCODE_")
        val array = mappings()
        val matched = (0 until array.length()).mapNotNull { array.optJSONObject(it) }
            .filter { it.optString("key").equals(name, true) }
        if (matched.isEmpty()) return false
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount > 0) return true
            val tapItems = matched.filter { it.optString("action", "TAP") == "TAP" }
            // Todos los clics asignados a esta tecla se despachan en un único gesto
            // multitáctil, con el mismo instante de inicio (sin cola ni retrasos).
            if (tapItems.isNotEmpty()) dispatchSimultaneousTaps(tapItems)
            matched.map { it.optString("action") }.filter { it in listOf("UP", "DOWN", "LEFT", "RIGHT") }
                .forEach { heldJoyDirections.add(it) }
            if (heldJoyDirections.isNotEmpty()) startOrUpdateContinuousJoystick()
            return true
        }
        if (event.action == KeyEvent.ACTION_UP) {
            val releasedDirections = matched.map { it.optString("action") }.filter { it in listOf("UP", "DOWN", "LEFT", "RIGHT") }
            if (releasedDirections.isNotEmpty()) {
                releasedDirections.forEach { heldJoyDirections.remove(it) }
                if (heldJoyDirections.isEmpty()) stopContinuousJoystick() else startOrUpdateContinuousJoystick()
            }
            return true
        }
        return false
    }

    private fun mappings(): JSONArray = try { JSONArray(prefs.getString("mappings", "[]")) } catch (_: Exception) { JSONArray() }

    private fun tap(x: Float, y: Float) {
        val safeX = x.coerceIn(1f, (screenWidth - 2).coerceAtLeast(1).toFloat())
        val safeY = y.coerceIn(1f, (screenHeight - 2).coerceAtLeast(1).toFloat())
        // Use ADB's input tap when paired; if the wireless connection has gone stale,
        // fall back to the accessibility gesture rather than silently dropping the key.
        if (WirelessAdbBridge.tap(safeX.toInt(), safeY.toInt()) {
                dispatchAccessibilityTap(safeX, safeY)
            }) return
        dispatchAccessibilityTap(safeX, safeY)
    }

    private fun dispatchAccessibilityTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 65)).build()
        dispatchGesture(gesture, null, null)
    }

    private fun dispatchSimultaneousTaps(items: List<JSONObject>) {
        if (items.isEmpty() || prefs.getBoolean("editMode", false) || !prefs.getBoolean("controlsVisible", true)) return
        refreshScreenSize()
        val builder = GestureDescription.Builder()
        items.forEach { item ->
            val x = item.optInt("x", screenWidth / 2).toFloat().coerceIn(1f, (screenWidth - 2).coerceAtLeast(1).toFloat())
            val y = item.optInt("y", screenHeight / 2).toFloat().coerceIn(1f, (screenHeight - 2).coerceAtLeast(1).toFloat())
            val path = Path().apply { moveTo(x, y) }
            builder.addStroke(GestureDescription.StrokeDescription(path, 0, 65))
        }
        dispatchGesture(builder.build(), null, null)
    }

    private fun joystickTarget(): Pair<Float, Float> {
        val cx = prefs.getInt("joyX", (screenWidth * 0.18f).toInt()).toFloat()
        val cy = prefs.getInt("joyY", (screenHeight * 0.78f).toInt()).toFloat()
        val size = prefs.getInt("joySize", 150).coerceIn(80, 1024)
        val radius = (size * 0.44f).coerceAtLeast(18f)
        val left = "LEFT" in heldJoyDirections
        val right = "RIGHT" in heldJoyDirections
        val up = "UP" in heldJoyDirections
        val down = "DOWN" in heldJoyDirections
        var dx = (if (right) 1f else 0f) - (if (left) 1f else 0f)
        var dy = (if (down) 1f else 0f) - (if (up) 1f else 0f)
        if (dx != 0f && dy != 0f) { dx *= 0.7071f; dy *= 0.7071f }
        return Pair((cx + dx * radius).coerceIn(1f, (screenWidth - 2).toFloat()), (cy + dy * radius).coerceIn(1f, (screenHeight - 2).toFloat()))
    }

    private fun startOrUpdateContinuousJoystick() {
        if (heldJoyDirections.isEmpty()) return
        val (tx, ty) = joystickTarget()
        lastJoyX = tx; lastJoyY = ty
        val cx = prefs.getInt("joyX", (screenWidth * 0.18f).toInt()).toFloat()
        val cy = prefs.getInt("joyY", (screenHeight * 0.78f).toInt()).toFloat()
        val path = Path().apply { moveTo(cx, cy); lineTo(tx, ty) }
        // Mantiene el contacto durante la tecla; se renueva antes del límite de duración del gesto.
        val stroke = GestureDescription.StrokeDescription(path, 0, 55000, false)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (heldJoyDirections.isNotEmpty() && !joyRefreshScheduled) {
                    joyRefreshScheduled = true
                    mainHandler.postDelayed({ joyRefreshScheduled = false; if (heldJoyDirections.isNotEmpty()) startOrUpdateContinuousJoystick() }, 30)
                }
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                // Cambiar de dirección o soltar una tecla cancela el gesto anterior intencionalmente.
            }
        }, null)
    }

    private fun stopContinuousJoystick() {
        joyRefreshScheduled = false
        // Un gesto nuevo cancela el contacto prolongado anterior y suelta el joystick.
        val x = lastJoyX.takeIf { it > 0 } ?: prefs.getInt("joyX", (screenWidth * 0.18f).toInt()).toFloat()
        val y = lastJoyY.takeIf { it > 0 } ?: prefs.getInt("joyY", (screenHeight * 0.78f).toInt()).toFloat()
        val path = Path().apply { moveTo(x, y); lineTo(x, y) }
        val release = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 1)).build()
        dispatchGesture(release, null, null)
    }

    private fun overlayType(): Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private fun overlayParams(width: Int = WindowManager.LayoutParams.WRAP_CONTENT, height: Int = WindowManager.LayoutParams.WRAP_CONTENT) =
        WindowManager.LayoutParams(width, height, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
        }

    private fun ensureBubble() {
        if (bubble != null) return
        val view = TextView(this).apply {
            text = "KM"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(15, 12, 15, 12); background = rounded(Color.rgb(35, 95, 210), 24)
            setOnClickListener { togglePanel() }
            setOnTouchListener(dragListener(null) { _, _ -> })
        }
        val params = overlayParams().apply { x = (screenWidth - 100).coerceAtLeast(0); y = 200 }
        try { wm?.addView(view, params); bubble = view } catch (_: Exception) {
            Toast.makeText(this, "Concede el permiso para mostrarse sobre otras apps", Toast.LENGTH_LONG).show()
        }
    }

    private fun repositionBubble() {
        val v = bubble ?: return
        val p = v.layoutParams as? WindowManager.LayoutParams ?: return
        p.x = p.x.coerceIn(0, (screenWidth - v.width).coerceAtLeast(0))
        p.y = p.y.coerceIn(0, (screenHeight - v.height).coerceAtLeast(0))
        try { wm?.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    private fun dragListener(id: String?, afterDrag: (Int, Int) -> Unit): View.OnTouchListener = object : View.OnTouchListener {
        var rawX = 0f; var rawY = 0f; var startX = 0; var startY = 0; var dragged = false
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = v.layoutParams as? WindowManager.LayoutParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (id != null && id != "__JOYSTICK__" && !prefs.getBoolean("editMode", false)) return false
                    if (id == "__JOYSTICK__" && !prefs.getBoolean("editMode", false)) return false
                    refreshScreenSize(); rawX = event.rawX; rawY = event.rawY; startX = p.x; startY = p.y; dragged = false; return true
                }
                MotionEvent.ACTION_MOVE -> {
                    refreshScreenSize()
                    val dx = (event.rawX - rawX).toInt(); val dy = (event.rawY - rawY).toInt()
                    if (abs(dx) > 4 || abs(dy) > 4) dragged = true
                    val viewW = (v.width.takeIf { it > 0 } ?: p.width.takeIf { it > 0 } ?: 52)
                    val viewH = (v.height.takeIf { it > 0 } ?: p.height.takeIf { it > 0 } ?: 52)
                    p.x = (startX + dx).coerceIn(0, (screenWidth - viewW).coerceAtLeast(0))
                    p.y = (startY + dy).coerceIn(0, (screenHeight - viewH).coerceAtLeast(0))
                    try { wm?.updateViewLayout(v, p) } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragged) {
                        val cx = p.x + v.width / 2; val cy = p.y + v.height / 2
                        if (id != null) savePosition(id, cx, cy)
                        else afterDrag(cx, cy)
                    } else v.performClick()
                    return true
                }
            }
            return false
        }
    }

    private fun togglePanel() {
        if (panel == null) {
            prefs.edit().putBoolean("editMode", true).apply()
            showPanel()
        } else {
            hidePanel()
            prefs.edit().putBoolean("editMode", false).apply()
        }
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(14, 14, 14, 14)
            background = rounded(Color.rgb(246, 248, 252), 18)
        }
        box.addView(TextView(this).apply {
            text = "KEY MAPPER"; textSize = 16f; setTextColor(Color.rgb(30, 70, 150)); setPadding(4, 2, 4, 10)
        })
        box.addView(panelButton("＋  Clic") { addClickControl() })
        box.addView(panelButton("＋  Joystick WASD") { addJoystick() })
        box.addView(panelButton("⌨  Asignar / editar teclas") { showControlPickerDialog() })
        box.addView(panelButton("↔  Tamaño del joystick") { changeJoystickSize() })
        box.addView(panelButton("Listo / modo juego") {
            hidePanel()
            prefs.edit().putBoolean("editMode", false).apply()
            Toast.makeText(this, "Modo juego: los controles ya no se pueden mover y los toques pasan al juego", Toast.LENGTH_SHORT).show()
        })
        box.addView(panelButton("🔗  Conectar ADB inalámbrico") {
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra(MainActivity.EXTRA_SHOW_PAIR_CODE, true)
            }
            startActivity(intent)
        })
        box.addView(panelButton("🔋  Quitar ahorro de batería") { requestBatteryExemption() })
        box.addView(panelButton("⏻  Apagar KeyMapper") {
            prefs.edit().putBoolean("controlsVisible", false).putBoolean("editMode", false).apply()
            hidePanel()
        })
        box.addView(panelButton("Cerrar menú (seguir editando)") { hidePanel() })
        val p = overlayParams().apply { x = (screenWidth - 270).coerceAtLeast(0); y = 280 }
        try { wm?.addView(box, p); panel = box } catch (_: Exception) {
            Toast.makeText(this, "No se pudo mostrar el menú flotante", Toast.LENGTH_SHORT).show()
        }
    }

    private fun panelButton(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL
        setPadding(16, 13, 16, 13); background = rounded(Color.rgb(35, 95, 210), 12)
        val lp = LinearLayout.LayoutParams(230, WindowManager.LayoutParams.WRAP_CONTENT); lp.bottomMargin = 7; layoutParams = lp
        setOnClickListener { action() }
    }

    private fun addClickControl() {
        val array = mappings()
        val id = "click_${System.currentTimeMillis()}"
        array.put(JSONObject().apply { put("id", id); put("key", "?"); put("action", "TAP"); put("x", (screenWidth * 0.65f).toInt()); put("y", (screenHeight * 0.5f).toInt()) })
        prefs.edit().putString("mappings", array.toString()).putBoolean("controlsVisible", true).apply()
        Toast.makeText(this, "Control añadido. Usa KM → Asignar / editar teclas para configurarlo y arrástralo en modo edición.", Toast.LENGTH_LONG).show()
        rebuildControls(force = true)
    }

    private fun showControlPickerDialog() {
        val arr = mappings()
        val items = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
        if (items.isEmpty()) { Toast.makeText(this, "Primero añade un control Clic o Joystick WASD", Toast.LENGTH_SHORT).show(); return }
        val labels = items.map { "${it.optString("key", "?")}  ·  ${if (it.optString("action", "TAP") == "TAP") "Clic" else "Joystick ${it.optString("action")}"}  (${it.optString("id")})" }.toTypedArray()
        showOverlayDialog(AlertDialog.Builder(this).setTitle("Selecciona el control").setItems(labels) { _, which ->
            val selected = items[which]
            showKeyEditor(selected.optString("id"))
        }.create())
    }

    private fun configureClick(id: String) { showKeyEditor(id) }

    private fun showKeyEditor(id: String) {
        val item = findMapping(id) ?: return
        val input = EditText(this).apply { setSingleLine(true); hint = "Tecla física (ej. E, F, SPACE)"; setText(item.optString("key", "?")); selectAll() }
        val dialog = AlertDialog.Builder(this).setTitle("Asignar tecla al punto")
            .setMessage("La tecla ejecutará un toque en las coordenadas guardadas. Se permite repetir una tecla en varios controles.")
            .setView(input).setNegativeButton("Cancelar", null)
            .setNeutralButton("Eliminar control") { _, _ -> removeMapping(id) }
            .setPositiveButton("Guardar", null).create()
        try {
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
            dialog.show()
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val key = input.text.toString().trim().uppercase().let { if (it == "ESPACIO") "SPACE" else it }
                if (key.isBlank() || key == "?") { input.error = "Escribe una tecla válida"; return@setOnClickListener }
                item.put("key", key); replaceMapping(item); dialog.dismiss()
                Toast.makeText(this, "Tecla $key asignada a este punto", Toast.LENGTH_SHORT).show()
            }
        } catch (_: Exception) { Toast.makeText(this, "Activa el permiso de superposición para editar desde KM", Toast.LENGTH_LONG).show() }
    }

    private fun showOverlayDialog(dialog: AlertDialog) {
        try { dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); dialog.show(); dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY) }
        catch (_: Exception) { Toast.makeText(this, "Activa el permiso de superposición", Toast.LENGTH_SHORT).show() }
    }

    private fun requestBatteryExemption() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (_: Exception) { Toast.makeText(this, "Busca Key Mapper en Ajustes → Batería → Optimización de batería", Toast.LENGTH_LONG).show() }
        }
    }

    private fun launchEditor(extra: String, value: String? = null) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (value != null) putExtra(extra, value) else putExtra(extra, true)
        }
        try { startActivity(intent) } catch (_: Exception) {
            Toast.makeText(this, "No se pudo abrir el editor. Abre Key Mapper y vuelve a intentarlo.", Toast.LENGTH_LONG).show()
        }
    }

    private fun addJoystick() {
        val arr = mappings()
        val items = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
        val existing = items.filter { it.optString("action") in listOf("UP", "DOWN", "LEFT", "RIGHT") }
        if (existing.isNotEmpty()) {
            prefs.edit().putBoolean("controlsVisible", true).apply()
            hidePanel()
            Toast.makeText(this, "El joystick WASD ya está añadido. Arrastra el círculo verde.", Toast.LENGTH_SHORT).show()
            return
        }
        val defs = listOf("W" to "UP", "A" to "LEFT", "S" to "DOWN", "D" to "RIGHT")
        defs.forEachIndexed { index, pair -> arr.put(JSONObject().apply {
            put("id", "joy_${pair.second.lowercase()}_${System.currentTimeMillis()}_$index")
            put("key", pair.first); put("action", pair.second); put("x", prefs.getInt("joyX", (screenWidth * .18f).toInt())); put("y", prefs.getInt("joyY", (screenHeight * .78f).toInt()))
        }) }
        prefs.edit().putString("mappings", arr.toString()).putBoolean("controlsVisible", true).apply()
        hidePanel()
        Toast.makeText(this, "Joystick WASD añadido. Arrastra el círculo verde y ajusta su tamaño desde KM.", Toast.LENGTH_LONG).show()
    }

    private fun changeJoystickSize() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 12, 24, 4) }
        val current = prefs.getInt("joySize", 150).coerceIn(80, 1024)
        val label = TextView(this).apply { text = "Tamaño: $current px"; textSize = 16f; setTextColor(Color.DKGRAY) }
        val slider = SeekBar(this).apply { max = 944; progress = current - 80 }
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { label.text = "Tamaño: ${progress + 80} px" }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        layout.addView(label); layout.addView(slider)
        val dialog = AlertDialog.Builder(this).setTitle("Tamaño del joystick")
            .setMessage("Puedes ajustar el círculo de 80 a 1024 px. Las teclas WASD se adaptan y quedan sobre el borde del círculo.")
            .setView(layout).setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ -> prefs.edit().putInt("joySize", slider.progress + 80).apply() }.create()
        showOverlayDialog(dialog)
    }

    private fun rebuildControls(force: Boolean = false) {
        if (!::prefs.isInitialized) return
        refreshScreenSize()
        if (!prefs.getBoolean("controlsVisible", true)) { removeControls(); removeBubble(); hidePanel(); return }
        val arr = mappings()
        val tapItems = mutableListOf<JSONObject>()
        var hasJoy = false
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            if (item.optString("action", "TAP") == "TAP") tapItems.add(item)
            else if (item.optString("action") in listOf("UP", "DOWN", "LEFT", "RIGHT")) hasJoy = true
        }
        val wanted = tapItems.map { it.optString("id", it.optString("key")) }.toSet()
        clickControls.keys.toList().filter { it !in wanted || force }.forEach { id ->
            clickControls[id]?.let { try { wm?.removeView(it.first) } catch (_: Exception) {} }
            clickControls.remove(id)
        }
        tapItems.forEachIndexed { index, item ->
            val id = item.optString("id", item.optString("key"))
            if (clickControls.containsKey(id)) {
                clickControls[id]?.first?.text = item.optString("key", "?")
                return@forEachIndexed
            }
            val size = 60
            val view = TextView(this).apply {
                text = item.optString("key", "?"); textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                includeFontPadding = false
                setPadding(3, 3, 3, 3); background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(22, 22, 24)); setStroke(2, Color.WHITE) }
                setOnClickListener { if (prefs.getBoolean("editMode", false)) configureClick(id) }
            }
            val p = overlayParams(size, size).apply {
                val centerX = item.optInt("x", -1); val centerY = item.optInt("y", -1)
                x = if (centerX >= 0) (centerX - size / 2).coerceIn(0, (screenWidth - size).coerceAtLeast(0)) else (screenWidth * .65f).toInt() + (index % 3) * 10
                y = if (centerY >= 0) (centerY - size / 2).coerceIn(0, (screenHeight - size).coerceAtLeast(0)) else (screenHeight * .45f).toInt() + (index % 4) * 10
            }
            view.setOnTouchListener(dragListener(id) { _, _ -> })
            setEditabilityFlag(p)
            try { wm?.addView(view, p); clickControls[id] = view to p } catch (_: Exception) {}
            if (item.optInt("x", -1) < 0 || item.optInt("y", -1) < 0) savePosition(id, p.x + size / 2, p.y + size / 2)
        }
        if (hasJoy) ensureJoyControl(force) else removeJoyControl()
    }

    private fun ensureJoyControl(force: Boolean = false) {
        if (joyControl != null && !force) return
        if (force) removeJoyControl()
        val size = prefs.getInt("joySize", 150).coerceIn(80, 1024)
        val view = FrameLayout(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(85, 20, 20, 22)); setStroke(2, Color.argb(210, 255, 255, 255)) }
            // Los centros de WASD quedan cerca del borde; cada círculo de tecla
            // cruza ligeramente la circunferencia, mitad dentro y mitad fuera.
            val keySize = (size * 0.20f).toInt().coerceIn(24, (size / 3).coerceAtLeast(24))
            val offset = (size * 0.45f).toInt()
            fun keyCircle(label: String, gravityValue: Int, marginX: Int = 0, marginY: Int = 0) {
                val key = TextView(this@KeyMapperService).apply {
                    text = label; textSize = (keySize * 0.34f).coerceIn(10f, 18f); setTextColor(Color.WHITE); gravity = Gravity.CENTER; includeFontPadding = false
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(18, 18, 20)); setStroke(1, Color.WHITE) }
                }
                val lp = FrameParams(keySize, keySize, gravityValue).apply {
                    when (label) {
                        "W" -> topMargin = marginY
                        "S" -> bottomMargin = offset - keySize / 2
                        "A" -> leftMargin = marginX
                        "D" -> rightMargin = offset - keySize / 2
                    }
                }
                addView(key, lp)
            }
            keyCircle("W", Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, offset - keySize / 2)
            keyCircle("S", Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, offset - keySize / 2)
            keyCircle("A", Gravity.CENTER_VERTICAL or Gravity.START, offset - keySize / 2, 0)
            keyCircle("D", Gravity.CENTER_VERTICAL or Gravity.END, 0, 0)
        }
        val p = overlayParams(size, size).apply {
            x = (prefs.getInt("joyX", (screenWidth * .18f).toInt()) - size / 2).coerceIn(0, (screenWidth - size).coerceAtLeast(0))
            y = (prefs.getInt("joyY", (screenHeight * .78f).toInt()) - size / 2).coerceIn(0, (screenHeight - size).coerceAtLeast(0))
        }
        view.setOnTouchListener(dragListener("__JOYSTICK__") { cx, cy -> prefs.edit().putInt("joyX", cx).putInt("joyY", cy).apply() })
        setEditabilityFlag(p)
        try { wm?.addView(view, p); joyControl = view; joyParams = p } catch (_: Exception) {}
    }

    private fun setEditabilityFlag(params: WindowManager.LayoutParams) {
        if (prefs.getBoolean("editMode", false)) params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    }

    private fun applyControlTouchMode() {
        val editable = prefs.getBoolean("editMode", false)
        clickControls.values.forEach { (_, params) ->
            if (editable) params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try { clickControls.values.forEach { (view, params) -> wm?.updateViewLayout(view, params) } } catch (_: Exception) {}
        joyParams?.let { params ->
            if (editable) params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try { joyControl?.let { wm?.updateViewLayout(it, params) } } catch (_: Exception) {}
        }
    }

    private fun savePosition(id: String, centerX: Int, centerY: Int) {
        if (id == "__JOYSTICK__") { prefs.edit().putInt("joyX", centerX).putInt("joyY", centerY).apply(); return }
        val arr = mappings()
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            if (item.optString("id") == id) { item.put("x", centerX.coerceIn(1, screenWidth - 1)); item.put("y", centerY.coerceIn(1, screenHeight - 1)) }
        }
        prefs.edit().putString("mappings", arr.toString()).apply()
    }

    private fun findMapping(id: String): JSONObject? {
        val arr = mappings()
        for (i in 0 until arr.length()) { val item = arr.optJSONObject(i) ?: continue; if (item.optString("id") == id) return item }
        return null
    }
    private fun replaceMapping(updated: JSONObject) {
        val arr = mappings()
        for (i in 0 until arr.length()) if (arr.optJSONObject(i)?.optString("id") == updated.optString("id")) { arr.put(i, updated); break }
        prefs.edit().putString("mappings", arr.toString()).apply()
    }
    private fun removeMapping(id: String) {
        val old = mappings(); val updated = JSONArray()
        for (i in 0 until old.length()) { val item = old.optJSONObject(i) ?: continue; if (item.optString("id") != id) updated.put(item) }
        prefs.edit().putString("mappings", updated.toString()).apply()
    }
    private fun removeControls() {
        clickControls.values.forEach { try { wm?.removeView(it.first) } catch (_: Exception) {} }
        clickControls.clear(); removeJoyControl()
    }
    private fun removeJoyControl() {
        try { joyControl?.let { wm?.removeView(it) } } catch (_: Exception) {}
        joyControl = null; joyParams = null
    }
    private fun removeBubble() {
        try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) {}
        bubble = null
    }
    private fun hidePanel() { try { panel?.let { wm?.removeView(it) } } catch (_: Exception) {}; panel = null }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat(); setStroke(2, Color.argb(170, 255, 255, 255)) }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) {}
        bubble = null; hidePanel(); removeControls(); heldJoyDirections.clear(); mainHandler.removeCallbacksAndMessages(null)
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(this)
        return super.onUnbind(intent)
    }
}
