package com.example.keymapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Color
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class KeyMapperService : AccessibilityService() {
    private var wm: WindowManager? = null
    private var bubble: View? = null
    private var panel: View? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return false
        val prefs = getSharedPreferences("mapping", MODE_PRIVATE)
        val keyName = KeyEvent.keyCodeToString(event.keyCode).removePrefix("KEYCODE_")
        val configuredKey = prefs.getString("tapKey", "E")?.uppercase() ?: "E"
        if (keyName == configuredKey || (configuredKey == "SPACE" && event.keyCode == KeyEvent.KEYCODE_SPACE)) {
            val x = prefs.getString("tapX", "540")?.toFloatOrNull() ?: 540f
            val y = prefs.getString("tapY", "1200")?.toFloatOrNull() ?: 1200f
            tap(x, y)
            return true
        }
        val cx = prefs.getString("joyX", "180")?.toFloatOrNull() ?: 180f
        val cy = prefs.getString("joyY", "1500")?.toFloatOrNull() ?: 1500f
        val radius = prefs.getString("joyRadius", "100")?.toFloatOrNull() ?: 100f
        val (dx, dy) = when (event.keyCode) {
            KeyEvent.KEYCODE_W -> 0f to -radius
            KeyEvent.KEYCODE_A -> -radius to 0f
            KeyEvent.KEYCODE_S -> 0f to radius
            KeyEvent.KEYCODE_D -> radius to 0f
            else -> return false
        }
        swipe(cx, cy, cx + dx, cy + dy, 150)
        return true
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        dispatchGesture(gesture, null, null)
    }
    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build()
        dispatchGesture(gesture, null, null)
    }

    private fun showBubble() {
        if (bubble != null) return
        val view = TextView(this).apply {
            text = "KM"
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(35, 95, 210))
            gravity = Gravity.CENTER
            setPadding(18, 14, 18, 14)
            setOnClickListener { togglePanel() }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 220 }
        try { wm?.addView(view, params); bubble = view } catch (_: Exception) { }
    }
    private fun togglePanel() { if (panel == null) showPanel() else hidePanel() }
    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 16)
            setBackgroundColor(Color.rgb(245, 247, 252))
        }
        box.addView(TextView(this).apply {
            text = "KEY MAPPER • ACTIVO\nWASD: joystick · tecla configurada: toque"
            textSize = 15f
            setTextColor(Color.rgb(30, 70, 150))
            setPadding(0, 0, 0, 12)
        })
        box.addView(TextView(this).apply {
            text = "OCULTAR PANEL"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(20, 14, 20, 14)
            setBackgroundColor(Color.rgb(35, 95, 210))
            setOnClickListener { hidePanel() }
        })
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 280 }
        try { wm?.addView(box, params); panel = box } catch (_: Exception) {
            Toast.makeText(this, "No se pudo mostrar el panel flotante", Toast.LENGTH_SHORT).show()
        }
    }
    private fun hidePanel() {
        panel?.let { try { wm?.removeView(it) } catch (_: Exception) { } }
        panel = null
    }
    override fun onUnbind(intent: android.content.Intent?): Boolean {
        try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) { }
        bubble = null
        hidePanel()
        return super.onUnbind(intent)
    }
}
