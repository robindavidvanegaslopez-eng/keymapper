# Key Mapper Android — prototipo mínimo

Proyecto nativo en Kotlin para Android. Incluye una tecla configurable que envía un toque a una coordenada, controles flotantes y WASD que envía gestos cortos hacia un punto de joystick configurado.

## Abrir y compilar
1. Descomprime el ZIP.
2. Abre la carpeta `KeyMapperAndroid` en Android Studio.
3. Espera a que Gradle sincronice.
4. Usa **Build > Build APK(s)** para compilar.

## Activar en el teléfono
1. Instala el APK.
2. Abre Key Mapper y configura la tecla y las coordenadas.
3. Pulsa **Activar servicio de accesibilidad** y activa `Key Mapper - controles`.
4. Conecta el teclado y vuelve al juego. La burbuja `KM` permite mostrar u ocultar el panel.

## Configuración
- Las coordenadas X/Y son píxeles desde la esquina superior izquierda.
- La tecla inicial es `E`; se puede cambiar a otra tecla reconocida.
- Centro X/Y y radio determinan el punto y la distancia del gesto WASD.

## Limitaciones
- Es un prototipo sin pruebas en todos los modelos ni juegos.
- WASD envía un gesto corto por pulsación; **no mantiene un dedo pulsado como un joystick analógico real**.
- Android, el fabricante o el propio juego pueden bloquear o ignorar gestos sintéticos o eventos globales del teclado.
- Hay que calibrar las coordenadas según resolución, orientación y escala del juego.
- El permiso de accesibilidad es potente: actívalo solo si confías en el APK y entiendes su función.

## Compilar desde el celular usando GitHub Actions
1. Sube el contenido de esta carpeta a la raíz de un repositorio GitHub (incluida la carpeta oculta `.github`).
2. Abre la pestaña **Actions** del repositorio y habilita los workflows si GitHub lo solicita.
3. En el workflow **Build Android APK**, pulsa **Run workflow**. También se ejecuta al subir cambios a `main` o `master`.
4. Cuando termine con estado verde, abre esa ejecución y descarga el artefacto `KeyMapper-debug-apk`.
5. Descomprime el artefacto descargado e instala `app-debug.apk`. Android puede pedirte permitir la instalación desde el navegador/archivos.

No subas contraseñas ni claves privadas al repositorio. El APK generado es de depuración y no está firmado para distribución en Play Store.
