# Key Mapper Android

Proyecto Android para asignar teclas de un teclado físico a puntos de clic en pantalla.

## Funciones
- Burbuja flotante `KM` con opciones para añadir un control de clic y pausar/reanudar Key Mapper.
- Controles negros circulares, arrastrables en modo edición, con una X para eliminarlos.
- La misma tecla física puede activar varios puntos de clic simultáneamente.
- Pausa manual desde el menú flotante y desde la pantalla principal.
- Pausa automática al detectar el foco en un campo de texto compatible, para reducir clics accidentales mientras se escribe.
- Opción para solicitar la exclusión de optimización de batería.
- Notificación de depuración inalámbrica con entrada directa del código de seis dígitos, sin tener que abrir la app.
- Búsqueda automática por mDNS de los puertos de emparejamiento y conexión ADB.

## Límites importantes
La pausa automática al escribir depende de que Android y el juego expongan el campo de texto al servicio de accesibilidad. Algunos juegos dibujan el chat de forma personalizada; en esos casos, usa la opción **Pausar** antes de escribir y **Reanudar** al terminar. Android genera el código temporal de depuración inalámbrica; Key Mapper no lo inventa ni lo obtiene por sí solo.

Para enviar clics se usa ADB inalámbrico si está conectado, con un gesto de accesibilidad como alternativa. ADB es opcional para el mapeo básico, pero requiere activar Depuración inalámbrica, abrir la pantalla de vinculación y mantener el teléfono conectado a una red Wi-Fi.

## Compilar
Sube el proyecto a GitHub y usa el flujo de GitHub Actions incluido. El artefacto de salida se publica como `app-debug.apk`.
