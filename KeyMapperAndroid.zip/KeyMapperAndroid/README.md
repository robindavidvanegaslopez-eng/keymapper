# Key Mapper Android

Proyecto Android mínimo para mapear un teclado físico a gestos de accesibilidad en pantalla.

## Funciones
- Burbuja flotante `KM` con opciones **Clic**, **Joystick WASD**, tamaño del joystick y ocultar controles.
- Los controles de clic se pueden arrastrar y tocar para editar su tecla física.
- El joystick verde es un único control arrastrable; WASD se asigna al añadirlo y su tamaño se puede ajustar.
- Las posiciones se limitan usando las dimensiones actuales de la pantalla, incluyendo orientación horizontal.
- Acceso a los ajustes de superposición y accesibilidad.
- Guía de depuración inalámbrica mediante notificación. Android, no la app, genera el código de emparejamiento.

## Límites importantes
La app usa `AccessibilityService.dispatchGesture` para enviar toques y deslizamientos cortos. No activa por sí sola la depuración inalámbrica ni puede generar el código seguro de emparejamiento de Android. Para el mapeo básico de gestos, la depuración inalámbrica no debería ser necesaria si el servicio de accesibilidad está activado. El joystick envía gestos direccionales cortos; no es un joystick analógico continuo.

## Compilar
Abre el proyecto en Android Studio o usa el flujo de GitHub Actions incluido. El artefacto de salida es `app-debug.apk`.


## Correcciones de esta versión
- El servicio de accesibilidad solicita explícitamente el filtrado de eventos del teclado físico.
- Los diálogos de editar una tecla y cambiar el tamaño del joystick se abren en `MainActivity`, no desde el servicio, para evitar cierres por contexto de ventana inválido.
- El modo edición se activa desde KM; al elegir “Listo / modo juego”, los controles flotantes dejan pasar los toques al juego y ya no se pueden arrastrar.
- Los límites de arrastre se recalculan en la orientación actual para mejorar el uso horizontal.

## Nota sobre ADB
La casilla del código de emparejamiento no implementa por sí misma un cliente ADB. El código de Android se usa por un cliente ADB host que debe ejecutar el protocolo de emparejamiento. Esta app usa el servicio de accesibilidad para filtrar teclas y enviar gestos; no se debe mostrar el estado ADB como conectado mientras no exista una implementación real del protocolo.


## Cambios de esta versión
- Menú KM incluye acceso para asignar/editar controles sin abrir la actividad principal, además de un acceso a los ajustes de optimización de batería.
- Los controles de clic son círculos negros más grandes con la etiqueta centrada.
- El tamaño del joystick se puede ajustar de 80 a 1024 px y sus teclas WASD escalan con él, colocadas sobre el borde del círculo.
- Si una misma tecla activa varios clics, todos se envían en un único gesto multitáctil con el mismo instante de inicio.
- El botón **Apagar KeyMapper** quita burbuja, controles y acciones; **Iniciar KeyMapper** desde la app los restaura conservando las posiciones guardadas.
- WASD mantiene un gesto de joystick mientras la tecla está presionada y calcula diagonales al combinar direcciones. El gesto de accesibilidad tiene límites de Android y no sustituye una implementación ADB real.
- La opción de batería abre los ajustes del sistema para que el usuario autorice la excepción; la app no puede quitar la optimización silenciosamente.


## ADB inalámbrico integrado

KeyMapper 1.2 incluye reconexión automática por mDNS cuando cambia el puerto de depuración, y conserva el gesto de accesibilidad como alternativa si una orden ADB falla. La dirección IP y los puertos se buscan automáticamente; solo se solicita el código temporal de Android. KeyMapper incluye un cliente ADB basado en Kadb. Desde KM o desde la notificación, introduce solamente el código de seis dígitos que muestra Android en Opciones de desarrollador → Depuración inalámbrica → Vincular dispositivo con código. La app busca los puertos de emparejamiento y conexión por mDNS en la red local, completa el emparejamiento y prueba la conexión con un comando inocuo. Si la conexión queda activa, los controles de tipo Clic ejecutan `input tap X Y` en las coordenadas guardadas; mientras ADB no esté conectado, se conserva el gesto de accesibilidad como alternativa.

Requisitos: Android 11 o superior, Depuración inalámbrica activada, la pantalla de vinculación abierta al introducir el código y el teléfono conectado a una red Wi-Fi. El código no se inventa ni se envía a servidores; el emparejamiento se realiza localmente con el servicio ADB del propio teléfono. La búsqueda automática depende de que Android anuncie los servicios ADB por mDNS.
