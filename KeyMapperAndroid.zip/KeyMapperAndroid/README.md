# Key Mapper Android

Aplicación Android para asignar teclas de un teclado físico a puntos de clic elegidos por la persona usuaria.

## Funciones
- Logo propio en la app y en el menú flotante.
- El servicio de accesibilidad no muestra el menú por sí solo: primero se concede la superposición y después se pulsa **Iniciar KeyMapper** dentro de la app.
- Menú flotante movible desde su asa, con opciones para añadir controles y pausar/reanudar.
- Controles negros circulares arrastrables en modo edición, con botón para eliminarlos.
- Editor de tecla directamente sobre el control, con el campo vacío para introducir la nueva tecla.
- Varias posiciones pueden compartir una tecla física.
- Control de opacidad de los botones desde la app.
- Pausa manual en la app y en el menú flotante; pausa automática al escribir cuando el juego expone un campo editable a Android.
- Notificación de depuración inalámbrica con entrada directa del código temporal de seis dígitos.
- Búsqueda mDNS de los puertos de emparejamiento y conexión ADB.
- Protección contra ráfagas de gestos: ignora repeticiones de tecla y no apila gestos táctiles simultáneos, reduciendo la presión sobre el servicio de accesibilidad.

## Seguridad, permisos y Play Protect
La app utiliza Accesibilidad para leer teclas físicas y ejecutar los toques configurados; utiliza superposición para mostrar controles, y red local/ADB inalámbrico solo si la persona activa esa función. No debe ocultar estas funciones ni intentar eludir Play Protect. Una APK de depuración instalada fuera de Play Store puede recibir advertencias por ser desconocida o por sus permisos sensibles; este proyecto no puede garantizar que Play Protect no la marque. Para distribución amplia se recomienda una versión release firmada de forma consistente, una explicación clara de permisos y una política de privacidad accesible.

## Límites importantes
La pausa automática al escribir depende de que Android y el juego expongan el campo de texto al servicio de accesibilidad. Algunos juegos dibujan el chat de forma personalizada; en esos casos, pulsa **Pausar** antes de escribir y **Reanudar** al terminar. Android genera el código temporal de depuración inalámbrica; Key Mapper no lo inventa ni lo obtiene por sí solo.

Los reinicios del teléfono no son un comportamiento normal de una app. La limitación de gestos reduce la carga generada por pulsaciones rápidas, pero no puede garantizar que se corrija un reinicio provocado por un fallo del sistema, firmware, periféricos Bluetooth o del propio Android. Si vuelve a ocurrir, prueba primero con ADB inalámbrico desactivado y con menos asignaciones, y evita probar repetidamente si el teléfono se reinicia.

## Compilar
Sube el proyecto a GitHub y ejecuta el flujo de GitHub Actions incluido. El artefacto de salida se publica como `app-debug.apk`. Esta APK de depuración no equivale a una versión release firmada para distribución.
