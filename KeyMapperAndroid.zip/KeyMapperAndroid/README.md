# Key Mapper Android

Proyecto Android mínimo para mapear un teclado físico a gestos de accesibilidad en pantalla.

## Funciones
- Burbuja flotante `KM` con opciones **Clic**, **Joystick WASD**, tamaño del joystick y ocultar controles.
- Los controles de clic se pueden arrastrar y tocar para editar su tecla física.
- El joystick verde es un único control arrastrable; WASD se asigna al añadirlo y su tamaño se puede ajustar.
- Las posiciones se limitan usando las dimensiones actuales de la pantalla, incluyendo orientación horizontal.
- Acceso a los ajustes de superposición y accesibilidad.
- Guía de depuración inalámbrica mediante notificación. Android, no la app, genera el código de emparejamiento.

## Límites importantes
La app usa `AccessibilityService.dispatchGesture` para enviar toques y deslizamientos cortos. No activa por sí sola la depuración inalámbrica ni puede generar el código seguro de emparejamiento de Android. Para el mapeo básico de gestos, la depuración inalámbrica no debería ser necesaria si el servicio de accesibilidad está activado. El joystick envía gestos direccionales cortos; no es un joystick analógico continuo.

## Compilar
Abre el proyecto en Android Studio o usa el flujo de GitHub Actions incluido. El artefacto de salida es `app-debug.apk`.


## Correcciones de esta versión
- El servicio de accesibilidad solicita explícitamente el filtrado de eventos del teclado físico.
- Los diálogos de editar una tecla y cambiar el tamaño del joystick se abren en `MainActivity`, no desde el servicio, para evitar cierres por contexto de ventana inválido.
- El modo edición se activa desde KM; al elegir “Listo / modo juego”, los controles flotantes dejan pasar los toques al juego y ya no se pueden arrastrar.
- Los límites de arrastre se recalculan en la orientación actual para mejorar el uso horizontal.

## Nota sobre ADB
La casilla del código de emparejamiento no implementa por sí misma un cliente ADB. El código de Android se usa por un cliente ADB host que debe ejecutar el protocolo de emparejamiento. Esta app usa el servicio de accesibilidad para filtrar teclas y enviar gestos; no se debe mostrar el estado ADB como conectado mientras no exista una implementación real del protocolo.


## Cambios de esta versión
- Menú KM incluye acceso para asignar/editar controles sin abrir la actividad principal, además de un acceso a los ajustes de optimización de batería.
- Los controles de clic son círculos negros más grandes con la etiqueta centrada.
- El tamaño del joystick se puede ajustar de 80 a 300 px y sus teclas interiores escalan con él.
- Se permiten varias asignaciones con la misma tecla; se procesan todos los controles coincidentes en secuencia.
- WASD mantiene un gesto de joystick mientras la tecla está presionada y calcula diagonales al combinar direcciones. El gesto de accesibilidad tiene límites de Android y no sustituye una implementación ADB real.
- La opción de batería abre los ajustes del sistema para que el usuario autorice la excepción; la app no puede quitar la optimización silenciosamente.
