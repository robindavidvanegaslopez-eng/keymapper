# Plantillas de Free Fire

Tres diseños (Perfiles → ＋ Plantilla Free Fire, o al añadir Free Fire desde Inicio):

| Diseño | Reparto |
|---|---|
| Predeterminado · 2 dedos | Joystick a la izquierda; disparo, mirilla y acciones a la derecha |
| 3 dedos | Disparo a la izquierda (índice izquierdo); cámara y acciones a la derecha |
| 4 dedos | Disparo a la izquierda; mirilla y salto arriba a la derecha; pulgares solo mueven y apuntan |

Teclas: WASD mover · Shift caminar · clic izq. disparo · clic der. mirilla · Espacio saltar · C agacharse · Z tumbarse · R recargar · Q cambiar arma · F1 captura la cámara.

Las posiciones son aproximadas: las guías públicas muestran los HUD como imágenes, sin coordenadas. Pasos:
1. En Free Fire: Ajustes → Controles → HUD personalizado. Elige el mismo diseño (o importa un código de HUD de la comunidad, p. ej. los listados en freefiremania.com.br).
2. En KeyMapper Pro: Editar controles sobre el juego y arrastra cada control encima del botón real.
