# Capacidades reales y limitaciones

| Mecanismo | Qué permite | Limitaciones |
|---|---|---|
| Servicio de accesibilidad (filtro de teclas) | Leer teclado físico y botones de mouse sin root | Solo recibe teclas mientras el servicio está activo; algunas teclas del sistema no se pueden interceptar |
| `dispatchGesture` | Toques, deslizamientos y multitouch (hasta 9 trazos) | Latencia de decenas de ms; no equivale a un dedo real; juegos con anti-trampas pueden ignorarlos |
| Captura de puntero (Android 8+) | Movimiento relativo, 5 botones y rueda | Requiere una ventana con foco; con el cursor sin capturar los botones del mouse no llegan a la app |
| Superposición (`SYSTEM_ALERT_WINDOW`) | Editor y botones sobre el juego | Requiere permiso manual |
| Captura de pantalla (Android 11+) | Detección automática del joystick | No disponible en versiones anteriores |

No se puede: cambiar el DPI real del mouse, distinguir USB de Bluetooth desde una app, ni garantizar combinaciones simultáneas que el teclado no envíe (ghosting).
Aceleración, DPI y suavizado se emulan escalando el movimiento relativo que Android entrega.
