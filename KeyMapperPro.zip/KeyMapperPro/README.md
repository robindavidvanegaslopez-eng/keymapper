# KeyMapper Pro
Mapeador de teclado y mouse a toques para Android (estilo BlueStacks).

## Compilar en GitHub
1. Sube todo el contenido de esta carpeta (incluida `.github`) a un repositorio.
2. Pestaña **Actions** → "Build APK" (se ejecuta solo al hacer push, o con *Run workflow*).
3. Al terminar, descarga el artefacto **KeyMapperPro-debug** (contiene el .apk).
