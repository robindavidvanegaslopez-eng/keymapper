# KeyMapper Pro 2.0
Mapeador universal de teclado y mouse a toques para Android. No impone ninguna distribución: todo lo defines tú.

## Compilar en GitHub
1. Sube todo el contenido de esta carpeta (incluida `.github`) a un repositorio.
2. Pestaña **Actions** → "Build APK" (se ejecuta solo al hacer push, o con *Run workflow*).
3. Descarga el artefacto **KeyMapperPro-debug** (contiene el .apk).

## Estilo BlueStacks
- **Inicio = biblioteca de juegos:** cada perfil es una tarjeta con el icono del juego, ▶ Jugar (abre el juego y activa los controles) y Editar controles. «＋ Añadir juego» crea el perfil desde tus apps instaladas (Free Fire usa su plantilla).
- **Editor:** panel lateral con los tipos de control; se arrastran al juego y se sueltan donde quieras (o tócalos para añadirlos al centro). Barra superior con ↶ ↷ Cancelar (descarta cambios) y ✓ Guardar. Panel de ajustes con pestañas: Teclas · Posición · Acción.
- **Al jugar:** burbuja ☰ con menú: Editar controles, Pausar, Ocultar/Mostrar teclas, Sensibilidad, Salir.

## Free Fire
- **Disparo:** tipo de control propio, ya asignado al clic izquierdo; mantiene el dedo pulsado mientras disparas (o dispara en ráfaga) a la vez que mueves la cámara.
- **Sensibilidad de cámara X/Y:** por conjunto (pestaña Mouse), por botón Mira, y en vivo desde el menú ☰ mientras juegas.
- Plantilla «Free Fire» (Perfiles → ＋ Plantilla Free Fire): joystick fijo, zona de mira, disparo (clic izq. mantenido), mirilla (clic der.), saltar, agacharse, recargar y cambiar arma. Las posiciones son aproximadas: colócalos sobre tu HUD.
- Joystick estilo Free Fire: el dedo nace en el centro y se desliza al borde; tecla de caminar (radio reducido) y auto-correr opcional.
- Cámara: al llegar al borde de la zona, el dedo se cambia por otro en el centro dentro del mismo gesto (sin hueco). Opción de activarla sola al pulsar ▶ Jugar.

## Secciones de la app
Inicio · Dispositivos · Perfiles · Controles · Mouse · Teclado · Avanzado · Importar/Exportar

## Qué se puede configurar por botón (editor visual)
- Tecla, botón del mouse (izq., der., medio, atrás, adelante, rueda ↑/↓) y modificadores Ctrl/Shift/Alt/Meta.
- Varias teclas para una acción; varias acciones para una tecla (prioridad + «exclusiva»).
- Disparador: al presionar, mantenida, doble pulsación, al soltar, secuencia de teclas.
- Posición (arrastre, flechas de 1/5/20 px, deslizadores X/Y), tamaño, forma, opacidad, bloquear, duplicar, borrar.
- Duración del toque, retardo, repeticiones e intervalo, activar/desactivar, condición (con/sin cámara activa).

## Mouse
Conjuntos de sensibilidad por perfil (H/V independientes, aceleración, suavizado, DPI relativo, inversión de ejes). Se cambian jugando con una tecla global.

## Arquitectura
| Módulo | Archivo |
|---|---|
| Captura de entradas | `MapperService.kt` (teclas), `Overlay.kt` (mouse capturado) |
| Asignación de acciones | `Mapper.kt` |
| Eventos táctiles | `Engine.kt` |
| Perfiles y almacenamiento | `Models.kt` (`Store`, `Cfg`) |
| Editor visual | `Overlay.kt` |
| Dispositivos y pantallas | `MainActivity.kt` |

Limitaciones reales de Android: ver `docs/LIMITACIONES.md`.
