package com.keymapperpro.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.delay

class Slot(var x: Float, var y: Float, val smooth: Float) {
    var tx = x
    var ty = y
    var stroke: GestureDescription.StrokeDescription? = null
    var releasing = false
}

/**
 * Motor de toques: mantiene "dedos" activos (slots) y los envía todos juntos en un único
 * GestureDescription cada ~25 ms usando trazos continuados (multitouch real).
 */
class TouchEngine(private val svc: AccessibilityService) {
    private val tickMs = 25L
    private val slots = LinkedHashMap<String, Slot>()
    private val h = Handler(Looper.getMainLooper())
    private var inflight = false
    private var posted = false
    private var n = 0

    fun has(id: String) = slots[id]?.releasing == false
    fun slot(id: String): Slot? = slots[id]?.takeIf { !it.releasing }
    fun press(id: String, x: Float, y: Float, smooth: Float = 1f) { slots[id] = Slot(x, y, smooth); kick() }
    fun move(id: String, x: Float, y: Float) { slots[id]?.let { it.tx = x; it.ty = y }; kick() }
    fun release(id: String) { slots[id]?.releasing = true; kick() }
    fun releaseAll() { slots.values.forEach { it.releasing = true }; kick() }

    suspend fun tap(x: Float, y: Float, hold: Long = 40) {
        val id = "t" + (n++)
        press(id, x, y)
        try { delay(hold) } finally { release(id) }
    }

    /** Varios toques en el mismo instante (mismo gesto). */
    suspend fun tapAll(pts: List<Pair<Float, Float>>, hold: Long = 40) {
        val ids = pts.map { val id = "t" + (n++); press(id, it.first, it.second); id }
        try { delay(hold) } finally { ids.forEach { release(it) } }
    }

    private fun kick() {
        if (!inflight && !posted) { posted = true; h.post { posted = false; step() } }
    }

    private fun step() {
        if (inflight || slots.isEmpty()) return
        val b = GestureDescription.Builder()
        val used = ArrayList<Pair<String, Slot>>()
        for ((id, s) in slots) {
            if (used.size >= 9) break
            val nx = s.x + (s.tx - s.x) * s.smooth
            val ny = s.y + (s.ty - s.y) * s.smooth
            val p = Path()
            p.moveTo(s.x, s.y)
            if (nx != s.x || ny != s.y) p.lineTo(nx, ny)
            val cont = !s.releasing
            val prev = s.stroke
            val st = if (prev != null) prev.continueStroke(p, 0, tickMs, cont) else GestureDescription.StrokeDescription(p, 0, tickMs, cont)
            s.stroke = st; s.x = nx; s.y = ny
            b.addStroke(st)
            used.add(id to s)
        }
        inflight = true
        val ok = svc.dispatchGesture(b.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { finish(used, false) }
            override fun onCancelled(g: GestureDescription?) { finish(used, true) }
        }, null)
        if (!ok) { inflight = false; slots.clear() }
    }

    private fun finish(used: List<Pair<String, Slot>>, cancelled: Boolean) {
        inflight = false
        if (cancelled) { slots.clear(); return }
        for ((id, s) in used) if (s.releasing && slots[id] === s) slots.remove(id)
        if (slots.isNotEmpty()) kick()
    }
}
