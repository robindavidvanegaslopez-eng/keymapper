package com.keymapperpro.app

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Detecta el aro del joystick (círculo grande, zona inferior izquierda) con una transformada de Hough. */
object JoyDetector {
    /** cx, cy en fracción 0..1 de la captura; r en píxeles reales. */
    class Result(val cx: Float, val cy: Float, val r: Float, val score: Float)

    fun detect(src: Bitmap): Result? {
        val bw = src.width; val bh = src.height
        val minDim = min(bw, bh)
        val rx = 0; val ry = (bh * 0.30f).toInt()
        val rw = (bw * 0.55f).toInt(); val rh = bh - ry
        if (rw < 50 || rh < 50) return null
        val roi = Bitmap.createBitmap(src, rx, ry, rw, rh)
        val sc = min(1f, 340f / max(rw, rh))
        val w = max(8, (rw * sc).toInt()); val h = max(8, (rh * sc).toInt())
        val small = Bitmap.createScaledBitmap(roi, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        val gray = IntArray(w * h) { val c = px[it]; (Color.red(c) * 30 + Color.green(c) * 59 + Color.blue(c) * 11) / 100 }

        val gx = IntArray(w * h); val gy = IntArray(w * h); val mag = FloatArray(w * h)
        var mx = 0f
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val a = gray[i - w - 1]; val b = gray[i - w]; val c = gray[i - w + 1]
            val d = gray[i - 1]; val e = gray[i + 1]
            val f = gray[i + w - 1]; val g = gray[i + w]; val hh = gray[i + w + 1]
            val sx = (c + 2 * e + hh) - (a + 2 * d + f)
            val sy = (f + 2 * g + hh) - (a + 2 * b + c)
            gx[i] = sx; gy[i] = sy
            val m = sqrt((sx * sx + sy * sy).toFloat())
            mag[i] = m
            if (m > mx) mx = m
        }
        if (mx < 60f) return null
        val thr = max(50f, mx * 0.28f)

        val rMin = max(6, (minDim * 0.06f * sc).toInt())
        val rMax = max(rMin + 2, (minDim * 0.22f * sc).toInt())
        val radii = (rMin..rMax step 2).toList()
        val acc = Array(radii.size) { IntArray(w * h) }
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val m = mag[i]
            if (m < thr) continue
            val nx = gx[i] / m; val ny = gy[i] / m
            for (k in radii.indices) {
                val r = radii[k]
                for (sgn in intArrayOf(-1, 1)) {
                    val cx = (x + sgn * r * nx).roundToInt()
                    val cy = (y + sgn * r * ny).roundToInt()
                    if (cx in 0 until w && cy in 0 until h) acc[k][cy * w + cx]++
                }
            }
        }

        var best = 0f
        val bf = FloatArray(radii.size); val bxs = IntArray(radii.size); val bys = IntArray(radii.size)
        for (k in radii.indices) {
            val a = acc[k]
            val circ = (2 * Math.PI * radii[k]).toFloat()
            for (y in 1 until h - 1) for (x in 1 until w - 1) {
                val i = y * w + x
                val s = a[i - w - 1] + a[i - w] + a[i - w + 1] + a[i - 1] + a[i] + a[i + 1] + a[i + w - 1] + a[i + w] + a[i + w + 1]
                val v = s / circ
                if (v > bf[k]) { bf[k] = v; bxs[k] = x; bys[k] = y }
            }
            if (bf[k] > best) best = bf[k]
        }
        if (best < 0.3f) return null
        // entre los radios casi igual de bien soportados, el mayor (aro exterior, no la palanca)
        var pick = -1
        for (k in radii.indices) if (bf[k] >= 0.6f * best) pick = k
        if (pick < 0) return null
        val cxFull = bxs[pick] / sc + rx
        val cyFull = bys[pick] / sc + ry
        return Result(cxFull / bw, cyFull / bh, radii[pick] / sc, bf[pick])
    }
}
