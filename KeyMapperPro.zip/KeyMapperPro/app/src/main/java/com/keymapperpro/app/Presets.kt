package com.keymapperpro.app

import android.view.KeyEvent

/**
 * Plantillas opcionales de Free Fire. Los diseños siguen el reparto de funciones de las configuraciones
 * más recomendadas (2, 3 y 4 dedos), pero las posiciones son aproximadas: cada HUD es personalizable en el juego,
 * así que hay que alinear los controles sobre el HUD real con «Editar controles».
 */
object Presets {
    const val FF_PKG = "com.dts.freefireth"   // Free Fire MAX: com.dts.freefiremax (cámbialo con «Juego»)

    val FF_LAYOUTS: List<Pair<String, String>> = listOf(
        "Predeterminado · 2 dedos" to "Pulgares: joystick a la izquierda; disparo, mirilla y acciones a la derecha.",
        "3 dedos" to "El índice izquierdo dispara; el pulgar derecho maneja la cámara y las acciones (saltar, agacharse, mirilla, recargar).",
        "4 dedos" to "Disparo en el índice izquierdo; mirilla y salto en el índice derecho; los pulgares solo mueven y apuntan."
    )

    private fun btn(t: BType, key: Int, fx: Float, fy: Float, size: Float, init: MapButton.() -> Unit = {}): MapButton =
        MapButton(type = t, key = key, fx = fx, fy = fy, size = size).apply(init)

    /** Diseñado en horizontal para una pantalla de 1080 px de lado corto (se reescala solo). */
    fun freeFire(layout: Int = 0): Profile {
        val l = layout.coerceIn(0, FF_LAYOUTS.size - 1)
        val b = mutableListOf<MapButton>()
        b.add(btn(BType.JOYSTICK, KeyEvent.KEYCODE_SHIFT_LEFT, 0.14f, 0.72f, 330f) { param = 0.4f; param2 = 0.5f; opt2 = true })
        b.add(btn(BType.LOOK, KeyEvent.KEYCODE_F1, if (l == 0) 0.70f else 0.66f, 0.40f, 720f) { param = 1f; param2 = 1f; opt = true })

        // disparo = clic izquierdo (mantenido)
        val fire = when (l) { 0 -> 0.86f to 0.62f; 1 -> 0.10f to 0.45f; else -> 0.09f to 0.40f }
        b.add(btn(BType.FIRE, -1, fire.first, fire.second, 150f))

        // mirilla = clic derecho; saltar = Espacio
        val scope = when (l) { 0 -> 0.94f to 0.46f; 1 -> 0.93f to 0.46f; else -> 0.93f to 0.30f }
        val jump = when (l) { 2 -> 0.93f to 0.46f; else -> 0.93f to 0.80f }
        val crouch = if (l == 2) 0.86f to 0.80f else 0.83f to 0.87f
        val prone = if (l == 2) 0.77f to 0.86f else 0.74f to 0.87f
        b.add(btn(BType.TAP, -2, scope.first, scope.second, 115f))
        b.add(btn(BType.TAP, KeyEvent.KEYCODE_SPACE, jump.first, jump.second, 120f))
        b.add(btn(BType.TAP, KeyEvent.KEYCODE_C, crouch.first, crouch.second, 105f))
        b.add(btn(BType.TAP, KeyEvent.KEYCODE_Z, prone.first, prone.second, 100f))
        b.add(btn(BType.TAP, KeyEvent.KEYCODE_R, 0.65f, 0.86f, 105f))     // recargar
        b.add(btn(BType.TAP, KeyEvent.KEYCODE_Q, 0.55f, 0.90f, 100f))     // cambiar arma

        val name = when (l) { 1 -> "Free Fire 3 dedos"; 2 -> "Free Fire 4 dedos"; else -> "Free Fire" }
        return Profile(
            name = name, pkg = FF_PKG, buttons = b, land = true, refMin = 1080,
            sens = mutableListOf(
                SensSet("Normal", 1f, 1f, 0f, 0.1f),
                SensSet("Precisión", 0.55f, 0.55f, 0f, 0.2f),
                SensSet("Rápida", 1.6f, 1.4f, 0.6f, 0f)
            )
        )
    }
}
