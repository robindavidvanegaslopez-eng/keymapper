package com.keymapperpro.app

import android.graphics.Point
import kotlinx.coroutines.*
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/** Traduce teclas / mouse a toques usando TouchEngine. */
class Mapper(private val svc: MapperService) {
    val eng = TouchEngine(svc)
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val jobs = HashMap<String, Job>()
    private val held = HashSet<Int>()
    private var idle: Job? = null
    private var sw = 0

    var buttons: List<MapButton> = emptyList()
    var active = false
    var lookOn = false
    private var lookBtn: MapButton? = null
    var onLookChange: (Boolean) -> Unit = {}

    private fun scr(): Point = svc.screen()
    private fun px(f: Float) = f * scr().x
    private fun py(f: Float) = f * scr().y

    fun stopAll() {
        jobs.values.forEach { it.cancel() }
        jobs.clear(); held.clear(); idle?.cancel()
        eng.releaseAll()
        if (lookOn) { lookOn = false; lookBtn = null; onLookChange(false) }
    }

    fun onKey(code: Int, down: Boolean, repeat: Boolean): Boolean {
        if (!active) return false
        val bs = buttons.filter { code in it.allKeys() }
        if (bs.isEmpty()) return false
        if (repeat) return true
        if (down) held.add(code) else held.remove(code)
        if (down) {
            val taps = bs.filter { it.type == BType.TAP && !it.opt }
            if (taps.isNotEmpty()) {
                val pts = taps.map { px(it.fx) to py(it.fy) }
                scope.launch { eng.tapAll(pts) }
            }
        }
        bs.forEach { handle(it, down) }
        return true
    }

    private fun handle(b: MapButton, down: Boolean) {
        val x = px(b.fx); val y = py(b.fy)
        when (b.type) {
            BType.TAP -> {
                if (b.opt) { if (down) eng.press(b.id, x, y) else eng.release(b.id) }
                // los toques simples se lanzan juntos en onKey (tapAll)
            }
            BType.TURBO -> turbo(b, down)
            BType.SWIPE -> if (down) scope.launch { swipe(x, y, px(b.fx2), py(b.fy2), b.param.toLong()) }
            BType.MACRO -> if (down) macro(b)
            BType.JOYSTICK -> joy(b)
            BType.LOOK -> if (down) toggleLook(b)
        }
    }

    // ---- Turbo / autoclick ----
    private fun turbo(b: MapButton, down: Boolean) {
        val on = jobs[b.id]?.isActive == true
        if (b.opt) {
            if (!down) return
            if (on) jobs[b.id]?.cancel() else startTurbo(b)
        } else if (down) { if (!on) startTurbo(b) } else jobs[b.id]?.cancel()
    }

    private fun rnd(r: Float) = if (r == 0f) 0f else (Random.nextFloat() * 2 - 1) * r

    private fun startTurbo(b: MapButton) {
        jobs[b.id] = scope.launch {
            val period = 1000f / b.param.coerceIn(1f, 50f)
            while (isActive) {
                val j = if (b.opt2) 4f else 0f
                val x = px(b.fx) + rnd(j); val y = py(b.fy) + rnd(j)
                launch { eng.tap(x, y, min(40f, period / 2).toLong()) }
                val k = if (b.opt2) 0.85f + Random.nextFloat() * 0.3f else 1f
                delay((period * k).toLong().coerceAtLeast(1))
            }
        }
    }

    // ---- Swipe ----
    private suspend fun swipe(ax: Float, ay: Float, bx: Float, by: Float, ms: Long) {
        val id = "sw" + (sw++)
        eng.press(id, ax, ay)
        try {
            val steps = max(1L, ms / 25)
            for (i in 1..steps) {
                delay(25)
                val t = i / steps.toFloat()
                val e = t * t * (3 - 2 * t)
                eng.move(id, ax + (bx - ax) * e, ay + (by - ay) * e)
            }
            delay(30)
        } finally { eng.release(id) }
    }

    // ---- Macro ----
    private fun macro(b: MapButton) {
        if (jobs[b.id]?.isActive == true) { jobs[b.id]?.cancel(); return }
        jobs[b.id] = scope.launch {
            var n = 0
            val sp = b.param2.coerceAtLeast(0.1f)
            while (isActive && (b.opt || n < b.param.toInt())) {
                if (b.steps.isEmpty()) break
                for (s in b.steps.toList()) {
                    when (s.k) {
                        "wait" -> delay((s.ms / sp).toLong())
                        "tap" -> eng.tap(px(s.x), py(s.y), (50 / sp).toLong().coerceAtLeast(20))
                        "swipe" -> swipe(px(s.x), py(s.y), px(s.x2), py(s.y2), (s.ms / sp).toLong())
                    }
                }
                n++
                yield()
            }
        }
    }

    // ---- Joystick ----
    private fun joy(b: MapButton) {
        val k = b.keys
        fun hd(c: Int) = if (c in held) 1 else 0
        val dx = hd(k[3]) - hd(k[1])
        val dy = hd(k[2]) - hd(k[0])
        val id = "joy" + b.id
        if (dx == 0 && dy == 0) { eng.release(id); return }
        val cx = px(b.fx); val cy = py(b.fy)
        val len = hypot(dx.toFloat(), dy.toFloat())
        val r = b.size / 2
        val tx = cx + dx / len * r
        val ty = cy + dy / len * r
        if (!eng.has(id)) eng.press(id, tx, ty, 1f) else eng.move(id, tx, ty)
    }

    // ---- Mira con mouse ----
    private fun toggleLook(b: MapButton) {
        lookOn = !lookOn
        lookBtn = if (lookOn) b else null
        if (!lookOn) { idle?.cancel(); eng.release("look") }
        onLookChange(lookOn)
    }

    fun onMouse(dx: Float, dy: Float) {
        val b = lookBtn ?: return
        val cx = px(b.fx); val cy = py(b.fy)
        var s = eng.slot("look")
        if (s == null) { eng.press("look", cx, cy); s = eng.slot("look") ?: return }
        val tx = s.tx + dx * b.param
        val ty = s.ty + dy * b.param2
        if (hypot(tx - cx, ty - cy) > b.size / 2) { eng.release("look"); return } // recentrar
        eng.move("look", tx, ty)
        idle?.cancel()
        idle = scope.launch { delay(250); eng.release("look") }
    }

    fun onMouseButton(code: Int, down: Boolean) { onKey(code, down, false) }
}
