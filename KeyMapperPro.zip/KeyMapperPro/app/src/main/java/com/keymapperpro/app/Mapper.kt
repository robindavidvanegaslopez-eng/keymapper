package com.keymapperpro.app

import android.graphics.Point
import android.os.SystemClock
import android.view.KeyEvent
import kotlinx.coroutines.*
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Traduce teclas / mouse a toques usando TouchEngine.
 * Soporta combinaciones (Ctrl/Shift/Alt/Meta), varias teclas por acción, varias acciones por tecla
 * con prioridad, disparadores (presionar, mantener, doble, soltar, secuencia), retardo y repetición.
 */
class Mapper(private val svc: MapperService) {
    val eng = TouchEngine(svc)
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val jobs = HashMap<String, Job>()
    private val held = HashSet<Int>()
    private val downFor = HashMap<Int, List<MapButton>>()
    private val lastDown = HashMap<String, Long>()
    private val seqPos = HashMap<String, Int>()
    private val seqLast = HashMap<String, Long>()
    private var idle: Job? = null
    private var sw = 0
    private var sdx = 0f
    private var sdy = 0f

    var buttons: List<MapButton> = emptyList()
    var sens: SensSet = SensSet()
        set(v) { field = v; sdx = 0f; sdy = 0f }
    var active = false
    var lookOn = false
    private var lookBtn: MapButton? = null
    var onLookChange: (Boolean) -> Unit = {}

    private fun scr(): Point = svc.screen()
    private fun px(f: Float) = f * scr().x
    private fun py(f: Float) = f * scr().y

    fun stopAll() {
        jobs.values.forEach { it.cancel() }
        jobs.clear(); held.clear(); idle?.cancel()
        downFor.clear(); lastDown.clear(); seqPos.clear(); seqLast.clear()
        sdx = 0f; sdy = 0f
        eng.releaseAll()
        if (lookOn) { lookOn = false; lookBtn = null; onLookChange(false) }
    }

    // ------------------------------------------------------------ entrada de teclas / botones
    private fun modMask(): Int {
        var m = 0
        if (KeyEvent.KEYCODE_CTRL_LEFT in held || KeyEvent.KEYCODE_CTRL_RIGHT in held) m = m or 1
        if (KeyEvent.KEYCODE_SHIFT_LEFT in held || KeyEvent.KEYCODE_SHIFT_RIGHT in held) m = m or 2
        if (KeyEvent.KEYCODE_ALT_LEFT in held || KeyEvent.KEYCODE_ALT_RIGHT in held) m = m or 4
        if (KeyEvent.KEYCODE_META_LEFT in held || KeyEvent.KEYCODE_META_RIGHT in held) m = m or 8
        return m
    }

    private fun condOk(b: MapButton): Boolean = when (b.cond) {
        1 -> lookOn
        2 -> !lookOn
        else -> true
    }

    /** Elige qué botones responden a una tecla ahora mismo (modificadores, prioridad, exclusividad). */
    private fun pick(code: Int, mask: Int): List<MapButton> {
        val all = buttons.filter { it.enabled && it.trigger != 4 && code in it.allKeys() && condOk(it) }
        val joys = all.filter { it.type == BType.JOYSTICK }
        val others = all.filter { it.type != BType.JOYSTICK && (mask and it.mods) == it.mods }
        val top = others.maxOfOrNull { Integer.bitCount(it.mods) } ?: 0
        val spec = others.filter { Integer.bitCount(it.mods) == top }.sortedByDescending { it.priority }
        val res = ArrayList<MapButton>()
        for (b in spec) { res.add(b); if (b.exclusive) break }
        return joys + res
    }

    fun onKey(code: Int, down: Boolean, repeat: Boolean): Boolean {
        if (!active) return false
        if (repeat) return downFor.containsKey(code)
        if (down) held.add(code) else held.remove(code)
        if (down) trackSeq(code)

        val cands: List<MapButton> = if (down) pick(code, modMask()) else (downFor.remove(code) ?: emptyList())
        if (cands.isEmpty()) return false

        if (down) {
            downFor[code] = cands
            // Ruta rápida: toques simples simultáneos en un mismo gesto (multitouch real).
            val fast = cands.filter { it.type == BType.TAP && it.trigger == 0 && !it.opt && it.delayMs == 0 && it.reps <= 1 }
            if (fast.isNotEmpty()) {
                val pts = fast.map { px(it.fx) to py(it.fy) }
                val hold = fast.maxOf { it.pulseMs }.toLong().coerceAtLeast(10)
                scope.launch { eng.tapAll(pts, hold) }
            }
            for (b in cands) if (fast.none { it === b }) dispatch(b, true)
        } else {
            for (b in cands) dispatch(b, false)
        }
        return true
    }

    private fun dispatch(b: MapButton, down: Boolean) {
        val t = if (b.type == BType.JOYSTICK) 0 else b.trigger
        when (t) {
            0 -> press(b, down)
            1 -> {
                if (down) {
                    jobs["h" + b.id]?.cancel()
                    jobs["h" + b.id] = scope.launch { delay(b.holdMs.toLong()); fire(b) }
                } else jobs.remove("h" + b.id)?.cancel()
            }
            2 -> if (down) {
                val now = SystemClock.uptimeMillis()
                val last = lastDown[b.id] ?: 0L
                if (now - last <= b.gapMs) { lastDown.remove(b.id); fire(b) } else lastDown[b.id] = now
            }
            3 -> if (!down) fire(b)
        }
    }

    private fun trackSeq(code: Int) {
        val now = SystemClock.uptimeMillis()
        for (b in buttons) {
            if (!b.enabled || b.trigger != 4 || b.seq.size < 2 || !condOk(b)) continue
            var pos = seqPos[b.id] ?: 0
            if (pos > 0 && now - (seqLast[b.id] ?: 0L) > b.gapMs) pos = 0
            pos = if (code == b.seq[pos]) pos + 1 else if (code == b.seq[0]) 1 else 0
            seqLast[b.id] = now
            if (pos >= b.seq.size) { seqPos[b.id] = 0; fire(b) } else seqPos[b.id] = pos
        }
    }

    /** Acción de tecla pulsada/soltada (disparador "al presionar"). */
    private fun press(b: MapButton, down: Boolean) {
        val x = px(b.fx); val y = py(b.fy)
        when (b.type) {
            BType.TAP -> {
                if (b.opt) { if (down) eng.press(b.id, x, y) else eng.release(b.id) }
                else if (down) runOnce(b)   // toques con retardo/repetición (los simples van por la ruta rápida)
            }
            BType.TURBO -> turbo(b, down)
            BType.SWIPE -> if (down) runOnce(b)
            BType.MACRO -> if (down) macro(b)
            BType.JOYSTICK -> joy(b)
            BType.LOOK -> if (down) toggleLook(b)
        }
    }

    /** Ejecución única de la acción (para mantenida, doble, soltar y secuencia). */
    private fun fire(b: MapButton) {
        when (b.type) {
            BType.TAP, BType.SWIPE -> runOnce(b)
            BType.TURBO -> { if (jobs[b.id]?.isActive == true) jobs[b.id]?.cancel() else startTurbo(b) }
            BType.MACRO -> macro(b)
            BType.LOOK -> toggleLook(b)
            BType.JOYSTICK -> {}
        }
    }

    private fun runOnce(b: MapButton) {
        scope.launch {
            if (b.delayMs > 0) delay(b.delayMs.toLong())
            val n = max(1, b.reps)
            for (i in 0 until n) {
                if (b.type == BType.SWIPE) swipe(px(b.fx), py(b.fy), px(b.fx2), py(b.fy2), b.param.toLong())
                else eng.tap(px(b.fx), py(b.fy), b.pulseMs.toLong().coerceAtLeast(10))
                if (i < n - 1) delay(b.repeatMs.toLong().coerceAtLeast(1))
            }
        }
    }

    // ---- Turbo / autoclick ----
    private fun turbo(b: MapButton, down: Boolean) {
        val on = jobs[b.id]?.isActive == true
        if (b.opt) {
            if (!down) return
            if (on) jobs[b.id]?.cancel() else startTurbo(b)
        } else if (down) { if (!on) startTurbo(b) } else jobs[b.id]?.cancel()
    }

    private fun rnd(r: Float) = if (r == 0f) 0f else (Random.nextFloat() * 2 - 1) * r

    private fun startTurbo(b: MapButton) {
        jobs[b.id] = scope.launch {
            val period = 1000f / b.param.coerceIn(1f, 50f)
            while (isActive) {
                val j = if (b.opt2) 4f else 0f
                val x = px(b.fx) + rnd(j); val y = py(b.fy) + rnd(j)
                launch { eng.tap(x, y, min(40f, period / 2).toLong()) }
                val k = if (b.opt2) 0.85f + Random.nextFloat() * 0.3f else 1f
                delay((period * k).toLong().coerceAtLeast(1))
            }
        }
    }

    // ---- Swipe ----
    private suspend fun swipe(ax: Float, ay: Float, bx: Float, by: Float, ms: Long) {
        val id = "sw" + (sw++)
        eng.press(id, ax, ay)
        try {
            val steps = max(1L, ms / 25)
            for (i in 1..steps) {
                delay(25)
                val t = i / steps.toFloat()
                val e = t * t * (3 - 2 * t)
                eng.move(id, ax + (bx - ax) * e, ay + (by - ay) * e)
            }
            delay(30)
        } finally { eng.release(id) }
    }

    // ---- Macro ----
    private fun macro(b: MapButton) {
        if (jobs[b.id]?.isActive == true) { jobs[b.id]?.cancel(); return }
        jobs[b.id] = scope.launch {
            var n = 0
            val sp = b.param2.coerceAtLeast(0.1f)
            while (isActive && (b.opt || n < b.param.toInt())) {
                if (b.steps.isEmpty()) break
                for (s in b.steps.toList()) {
                    when (s.k) {
                        "wait" -> delay((s.ms / sp).toLong())
                        "tap" -> eng.tap(px(s.x), py(s.y), (50 / sp).toLong().coerceAtLeast(20))
                        "swipe" -> swipe(px(s.x), py(s.y), px(s.x2), py(s.y2), (s.ms / sp).toLong())
                    }
                }
                n++
                yield()
            }
        }
    }

    // ---- Joystick ----
    private fun joy(b: MapButton) {
        val k = b.keys
        fun hd(c: Int) = if (c in held) 1 else 0
        val dx = hd(k[3]) - hd(k[1])
        val dy = hd(k[2]) - hd(k[0])
        val id = "joy" + b.id
        if (dx == 0 && dy == 0) { eng.release(id); return }
        val cx = px(b.fx); val cy = py(b.fy)
        val len = hypot(dx.toFloat(), dy.toFloat())
        val r = b.size / 2
        val tx = cx + dx / len * r
        val ty = cy + dy / len * r
        if (!eng.has(id)) eng.press(id, tx, ty, 1f) else eng.move(id, tx, ty)
    }

    // ---- Mira con mouse ----
    private fun toggleLook(b: MapButton) {
        lookOn = !lookOn
        lookBtn = if (lookOn) b else null
        sdx = 0f; sdy = 0f
        if (!lookOn) { idle?.cancel(); eng.release("look") }
        onLookChange(lookOn)
    }

    /**
     * Movimiento relativo del mouse capturado. Orden: aceleración → DPI → sensibilidad X/Y
     * (conjunto del perfil × valor del botón Mira) → inversión → suavizado.
     */
    fun onMouse(dx: Float, dy: Float) {
        val b = lookBtn ?: return
        val s = sens
        val speed = hypot(dx, dy)
        val acc = 1f + max(0f, s.accel) * (min(speed, 50f) / 50f)
        val k = s.dpi / 800f
        var mx = dx * acc * k * s.sx * b.param
        var my = dy * acc * k * s.sy * b.param2
        if (s.invX) mx = -mx
        if (s.invY) my = -my
        val a = 1f - s.smooth.coerceIn(0f, 0.9f)
        sdx += (mx - sdx) * a
        sdy += (my - sdy) * a

        val cx = px(b.fx); val cy = py(b.fy)
        var sl = eng.slot("look")
        if (sl == null) { eng.press("look", cx, cy); sl = eng.slot("look") ?: return }
        val tx = sl.tx + sdx
        val ty = sl.ty + sdy
        if (hypot(tx - cx, ty - cy) > b.size / 2) { eng.release("look"); sdx = 0f; sdy = 0f; return } // recentrar
        eng.move("look", tx, ty)
        idle?.cancel()
        idle = scope.launch { delay(Cfg.idleMs(svc)); eng.release("look"); sdx = 0f; sdy = 0f }
    }

    fun onMouseButton(code: Int, down: Boolean) { onKey(code, down, false) }
}
