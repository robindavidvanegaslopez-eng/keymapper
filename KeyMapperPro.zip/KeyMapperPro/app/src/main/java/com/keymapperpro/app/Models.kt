package com.keymapperpro.app

import android.content.Context
import com.google.gson.Gson
import java.io.File
import java.util.UUID

enum class BType(val label: String) {
    TAP("Toque"), TURBO("Turbo"), SWIPE("Deslizar"), MACRO("Macro"), JOYSTICK("Joystick"), LOOK("Mira")
}

/** k = "tap" | "swipe" | "wait". Coordenadas como fracción 0..1 de la pantalla. */
data class Step(var k: String = "tap", var x: Float = 0f, var y: Float = 0f, var x2: Float = 0f, var y2: Float = 0f, var ms: Long = 0)

data class MapButton(
    var id: String = UUID.randomUUID().toString(),
    var type: BType = BType.TAP,
    var key: Int = 0,                                   // keycode; -1/-2/-3 = clic izq/der/medio
    var keys: MutableList<Int> = mutableListOf(51, 29, 47, 32), // joystick: W A S D (arriba, izq, abajo, der)
    var fx: Float = 0.5f, var fy: Float = 0.5f,
    var fx2: Float = 0.7f, var fy2: Float = 0.5f,       // final del swipe
    var size: Float = 120f, var alpha: Float = 0.6f,
    var param: Float = 10f, var param2: Float = 1f,
    var opt: Boolean = false, var opt2: Boolean = false,
    var locked: Boolean = false,
    var steps: MutableList<Step> = mutableListOf()
) {
    fun allKeys(): List<Int> = if (type == BType.JOYSTICK) keys else if (key != 0) listOf(key) else emptyList()
}

data class Profile(
    var name: String = "Nuevo",
    var pkg: String = "",
    var buttons: MutableList<MapButton> = mutableListOf(),   // botones de la orientación actual
    var alt: MutableList<MapButton> = mutableListOf(),       // botones de la otra orientación
    var land: Boolean? = null,                               // orientación a la que pertenece `buttons`
    var refMin: Int = 0                                      // lado corto de pantalla con el que se diseñó
)

object Store {
    private val g = Gson()
    private fun dir(c: Context) = File(c.filesDir, "profiles").apply { mkdirs() }
    private fun safe(n: String) = n.replace(Regex("[^A-Za-z0-9_-]"), "_")
    private fun prefs(c: Context) = c.getSharedPreferences("kmp", Context.MODE_PRIVATE)

    fun list(c: Context): List<Profile> =
        dir(c).listFiles { f -> f.extension == "json" }.orEmpty()
            .mapNotNull { runCatching { g.fromJson(it.readText(), Profile::class.java) }.getOrNull() }
            .sortedBy { it.name }

    fun save(c: Context, p: Profile) { File(dir(c), safe(p.name) + ".json").writeText(g.toJson(p)) }
    fun delete(c: Context, p: Profile) { File(dir(c), safe(p.name) + ".json").delete() }
    fun toJson(p: Profile): String = g.toJson(p)
    fun fromJson(s: String): Profile? = runCatching { g.fromJson(s, Profile::class.java) }.getOrNull()

    fun selected(c: Context): String = prefs(c).getString("sel", "") ?: ""
    fun select(c: Context, n: String) { prefs(c).edit().putString("sel", n).apply() }
    fun current(c: Context): Profile? { val l = list(c); return l.firstOrNull { it.name == selected(c) } ?: l.firstOrNull() }
    fun forPkg(c: Context, pkg: String): Profile? = list(c).firstOrNull { it.pkg == pkg }
    fun ensureDefault(c: Context) { if (list(c).isEmpty()) save(c, Profile("Predeterminado")) }
}
