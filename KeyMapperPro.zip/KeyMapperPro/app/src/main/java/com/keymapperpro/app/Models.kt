package com.keymapperpro.app

import android.content.Context
import android.view.KeyEvent
import com.google.gson.Gson
import com.google.gson.JsonParser
import java.io.File
import java.util.UUID

enum class BType(val label: String) {
    TAP("Toque"), TURBO("Turbo"), SWIPE("Deslizar"), MACRO("Macro"), JOYSTICK("Joystick"), LOOK("Mira")
}

/** k = "tap" | "swipe" | "wait". Coordenadas como fracción 0..1 de la pantalla. */
data class Step(var k: String = "tap", var x: Float = 0f, var y: Float = 0f, var x2: Float = 0f, var y2: Float = 0f, var ms: Long = 0)

/** Conjunto de sensibilidad del mouse (un perfil puede tener varios y alternarlos). */
data class SensSet(
    var name: String = "Normal",
    var sx: Float = 1f,          // sensibilidad horizontal
    var sy: Float = 1f,          // sensibilidad vertical
    var accel: Float = 0f,       // aceleración 0..3 (0 = lineal)
    var smooth: Float = 0f,      // suavizado 0..0.9
    var dpi: Int = 800,          // DPI emulado (800 = sin cambio)
    var invX: Boolean = false,
    var invY: Boolean = false
)

data class MapButton(
    var id: String = UUID.randomUUID().toString(),
    var type: BType = BType.TAP,
    var key: Int = 0,                                   // keycode; -1/-2/-3 = clic izq/der/medio; -4/-5 = atrás/adelante; -6/-7 = rueda arriba/abajo
    var keys: MutableList<Int> = mutableListOf(51, 29, 47, 32), // joystick: W A S D (arriba, izq, abajo, der)
    var fx: Float = 0.5f, var fy: Float = 0.5f,
    var fx2: Float = 0.7f, var fy2: Float = 0.5f,       // final del swipe
    var size: Float = 120f, var alpha: Float = 0.6f,
    var param: Float = 10f, var param2: Float = 1f,
    var opt: Boolean = false, var opt2: Boolean = false,
    var locked: Boolean = false,
    var steps: MutableList<Step> = mutableListOf(),
    // ---- v2: mapeo universal
    var mods: Int = 0,                                  // modificadores requeridos: 1 Ctrl · 2 Shift · 4 Alt · 8 Meta
    var extra: MutableList<Int> = mutableListOf(),      // teclas adicionales que activan la misma acción
    var trigger: Int = 0,                               // 0 al presionar · 1 mantenida · 2 doble · 3 al soltar · 4 secuencia
    var seq: MutableList<Int> = mutableListOf(),        // teclas de la secuencia (trigger = 4)
    var holdMs: Int = 400,                              // tiempo para "mantenida"
    var gapMs: Int = 300,                               // ventana de doble pulsación / entre teclas de secuencia
    var pulseMs: Int = 40,                              // duración del toque
    var delayMs: Int = 0,                               // retardo antes de ejecutar
    var reps: Int = 1,                                  // repeticiones
    var repeatMs: Int = 100,                            // intervalo entre repeticiones
    var priority: Int = 0,                              // mayor = primero
    var exclusive: Boolean = false,                     // bloquea a las de menor prioridad con la misma tecla
    var enabled: Boolean = true,
    var cond: Int = 0,                                  // 0 siempre · 1 solo con cámara activa · 2 solo con cámara inactiva
    var shape: Int = 0                                  // 0 círculo · 1 cuadrado redondeado · 2 cuadrado
) {
    fun allKeys(): List<Int> =
        if (type == BType.JOYSTICK) keys else (listOf(key) + extra).filter { it != 0 }.distinct()
}

data class Profile(
    var name: String = "Nuevo",
    var pkg: String = "",
    var buttons: MutableList<MapButton> = mutableListOf(),   // botones de la orientación actual
    var alt: MutableList<MapButton> = mutableListOf(),       // botones de la otra orientación
    var land: Boolean? = null,                               // orientación a la que pertenece `buttons`
    var refMin: Int = 0,                                     // lado corto de pantalla con el que se diseñó
    var sens: MutableList<SensSet> = mutableListOf(SensSet()),
    var sensSel: Int = 0
) {
    fun curSens(): SensSet {
        if (sens.isEmpty()) sens.add(SensSet())
        return sens[sensSel.coerceIn(0, sens.size - 1)]
    }
}

/** Ajustes globales de la app (no dependen del perfil). */
object Cfg {
    private fun p(c: Context) = c.getSharedPreferences("kmp_cfg", Context.MODE_PRIVATE)
    fun tick(c: Context): Long = p(c).getInt("tick", 25).toLong()
    fun setTick(c: Context, v: Int) { p(c).edit().putInt("tick", v).apply() }
    fun idleMs(c: Context): Long = p(c).getInt("idle", 250).toLong()
    fun setIdle(c: Context, v: Int) { p(c).edit().putInt("idle", v).apply() }
    /** name = "pause" | "sens" | "prof" */
    fun key(c: Context, name: String): Int = p(c).getInt("k_$name", when (name) {
        "pause" -> KeyEvent.KEYCODE_F8
        "sens" -> KeyEvent.KEYCODE_F9
        else -> KeyEvent.KEYCODE_F10
    })
    fun setKey(c: Context, name: String, code: Int) { p(c).edit().putInt("k_$name", code).apply() }
    fun reset(c: Context) { p(c).edit().clear().apply() }
}

object Store {
    private val g = Gson()
    private fun dir(c: Context) = File(c.filesDir, "profiles").apply { mkdirs() }
    private fun safe(n: String) = n.replace(Regex("[^A-Za-z0-9_-]"), "_")
    private fun prefs(c: Context) = c.getSharedPreferences("kmp", Context.MODE_PRIVATE)

    fun list(c: Context): List<Profile> =
        dir(c).listFiles { f -> f.extension == "json" }.orEmpty()
            .mapNotNull { runCatching { g.fromJson(it.readText(), Profile::class.java) }.getOrNull() }
            .sortedBy { it.name }

    fun save(c: Context, p: Profile) { File(dir(c), safe(p.name) + ".json").writeText(g.toJson(p)) }
    fun delete(c: Context, p: Profile) { File(dir(c), safe(p.name) + ".json").delete() }
    fun toJson(p: Profile): String = g.toJson(p)
    fun fromJson(s: String): Profile? = runCatching { g.fromJson(s, Profile::class.java) }.getOrNull()
    fun toJsonAll(c: Context): String = g.toJson(list(c))

    fun selected(c: Context): String = prefs(c).getString("sel", "") ?: ""
    fun select(c: Context, n: String) { prefs(c).edit().putString("sel", n).apply() }
    fun current(c: Context): Profile? { val l = list(c); return l.firstOrNull { it.name == selected(c) } ?: l.firstOrNull() }
    fun forPkg(c: Context, pkg: String): Profile? = list(c).firstOrNull { it.pkg == pkg }
    fun ensureDefault(c: Context) { if (list(c).isEmpty()) save(c, Profile("Predeterminado")) }

    private fun uniqueName(c: Context, base: String): String {
        val names = list(c).map { it.name }.toSet()
        var n = base; var i = 2
        while (n in names) { n = "$base ($i)"; i++ }
        return n
    }

    /** Copia completa (botones, sensibilidad, orientaciones). Los botones reciben ids nuevos. */
    fun duplicate(c: Context, p: Profile): Profile {
        val copy = g.fromJson(g.toJson(p), Profile::class.java)
        copy.name = uniqueName(c, p.name + " copia")
        (copy.buttons + copy.alt).forEach { it.id = UUID.randomUUID().toString() }
        save(c, copy)
        return copy
    }

    fun rename(c: Context, p: Profile, newName: String): Boolean {
        val n = newName.trim()
        if (n.isEmpty()) return false
        if (n != p.name && list(c).any { it.name == n }) return false
        val wasSel = selected(c) == p.name
        delete(c, p)
        p.name = n
        save(c, p)
        if (wasSel) select(c, n)
        return true
    }

    /** Acepta un perfil suelto o una lista de perfiles. Devuelve cuántos importó. */
    fun importAny(c: Context, text: String): Int {
        val found: List<Profile> = runCatching {
            val el = JsonParser.parseString(text)
            if (el.isJsonArray) el.asJsonArray.mapNotNull { g.fromJson(it, Profile::class.java) }
            else listOfNotNull(g.fromJson(el, Profile::class.java))
        }.getOrDefault(emptyList())
        var n = 0
        for (p in found) {
            if (p.name.isBlank()) continue
            p.name = uniqueName(c, p.name)
            save(c, p)
            n++
        }
        return n
    }
}
