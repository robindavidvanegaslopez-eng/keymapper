package com.keymapperpro.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.SystemClock
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.google.gson.Gson
import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

fun keyName(k: Int): String = when (k) {
    0 -> "?"
    -1 -> "ClicI"
    -2 -> "ClicD"
    -3 -> "ClicM"
    else -> KeyEvent.keyCodeToString(k).removePrefix("KEYCODE_")
}

class BtnView(ctx: Context, val b: MapButton, val end: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var selected = false

    override fun onDraw(c: Canvas) {
        val w = width / 2f
        val r = w - 4f
        val col = if (end) Color.parseColor("#FFA000") else Color.parseColor(
            when (b.type) {
                BType.TAP -> "#42A5F5"
                BType.TURBO -> "#EF5350"
                BType.SWIPE -> "#66BB6A"
                BType.MACRO -> "#AB47BC"
                BType.JOYSTICK -> "#26C6DA"
                BType.LOOK -> "#FFCA28"
            }
        )
        p.style = Paint.Style.FILL; p.color = col; p.alpha = (b.alpha * 255).toInt().coerceIn(40, 255)
        c.drawCircle(w, w, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = if (selected) 7f else 3f
        p.color = Color.WHITE; p.alpha = if (selected) 255 else 190
        c.drawCircle(w, w, r, p)
        p.style = Paint.Style.FILL; p.color = Color.WHITE
        if (!end && b.type == BType.JOYSTICK) { p.alpha = 110; c.drawCircle(w, w, r * 0.3f, p) }
        if (!end && b.type == BType.LOOK) {
            p.strokeWidth = 4f; p.alpha = 160
            c.drawLine(w - r * 0.25f, w, w + r * 0.25f, w, p)
            c.drawLine(w, w - r * 0.25f, w, w + r * 0.25f, p)
        }
        p.alpha = 255; p.textAlign = Paint.Align.CENTER
        val big = minOf(width * 0.22f, 44f)
        p.textSize = big
        val label = if (end) "B" else if (b.type == BType.JOYSTICK) b.keys.joinToString("") { keyName(it).take(1) } else keyName(b.key)
        c.drawText(label, w, w + big / 3, p)
        if (!end) { p.textSize = big * 0.5f; c.drawText(b.type.label, w, w - big * 0.8f, p) }
    }
}

class LineView(ctx: Context, private val bs: () -> List<MapButton>) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 102, 187, 106); strokeWidth = 6f }
    override fun onDraw(c: Canvas) {
        for (b in bs()) if (b.type == BType.SWIPE) c.drawLine(b.fx * width, b.fy * height, b.fx2 * width, b.fy2 * height, p)
    }
}

@SuppressLint("ClickableViewAccessibility")
class Overlay(private val svc: MapperService, private val m: Mapper) {
    private val ctx = ContextThemeWrapper(svc, android.R.style.Theme_DeviceDefault)
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = svc.resources.displayMetrics.density
    private val pad = (6 * d).toInt()
    private val g = Gson()
    private val layer = FrameLayout(ctx)
    private val bubble = TextView(ctx)
    private lateinit var lp: LP
    private lateinit var bp: LP
    lateinit var profile: Profile
    var editing = false
    private var sel: MapButton? = null
    private var panel: View? = null
    private var lines: LineView? = null
    private val views = ArrayList<BtnView>()
    private val undoS = ArrayList<String>()
    private val redoS = ArrayList<String>()

    private val fBase = LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS
    private val fPlay = fBase or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_NOT_FOCUSABLE
    private val fLook = fBase or LP.FLAG_NOT_TOUCHABLE
    private val fEdit = fBase or LP.FLAG_NOT_FOCUSABLE

    private fun toast(t: String) = Toast.makeText(svc, t, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------ ciclo de vida
    fun show(p: Profile) {
        val s = svc.screen()
        lp = LP(s.x, s.y, LP.TYPE_APPLICATION_OVERLAY, fPlay, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            alpha = 0.8f
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        layer.isFocusable = true
        layer.isFocusableInTouchMode = true
        layer.setOnCapturedPointerListener { _, e -> onCaptured(e); true }
        layer.setOnTouchListener { _, e -> if (editing && e.action == MotionEvent.ACTION_DOWN) select(null); false }
        wm.addView(layer, lp)

        bubble.apply {
            textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            minWidth = (48 * d).toInt(); minHeight = (48 * d).toInt()
        }
        bp = LP(LP.WRAP_CONTENT, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY, LP.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 16; y = 120
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = bp.x; oy = bp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) + abs(dy) > 12 * d) moved = true
                    if (moved) { bp.x = ox + dx.toInt(); bp.y = oy + dy.toInt(); wm.updateViewLayout(bubble, bp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) { if (editing) play() else edit() }
            }
            true
        }
        wm.addView(bubble, bp)

        m.onLookChange = { on ->
            if (!editing) {
                if (on) {
                    applyFlags(fLook, 0.8f)
                    layer.postDelayed({ layer.requestFocus(); layer.requestPointerCapture() }, 150)
                } else {
                    layer.releasePointerCapture()
                    applyFlags(fPlay, 0.8f)
                }
            }
        }
        profile = p
        play()
    }

    fun hide() {
        m.onLookChange = {}
        m.stopAll(); m.active = false
        runCatching { layer.releasePointerCapture() }
        runCatching { wm.removeView(layer) }
        runCatching { wm.removeView(bubble) }
        save()
    }

    fun setProfile(p: Profile) {
        profile = p; m.buttons = p.buttons; sel = null
        undoS.clear(); redoS.clear()
        refresh()
        toast("Perfil: " + p.name)
    }

    fun togglePause() {
        if (editing) return
        m.active = !m.active
        if (!m.active) m.stopAll()
        paintBubble()
        toast(if (m.active) "Mapeo activo" else "Mapeo en pausa (F8)")
    }

    private fun applyFlags(f: Int, a: Float) { lp.flags = f; lp.alpha = a; wm.updateViewLayout(layer, lp) }

    private fun paintBubble() {
        bubble.text = if (editing) "▶" else "✎"
        val col = if (editing) "#2E7D32" else if (m.active) "#303F9F" else "#C62828"
        bubble.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(col)); alpha = 220 }
    }

    fun play() {
        save()
        editing = false; sel = null
        m.buttons = profile.buttons; m.active = true
        applyFlags(fPlay, 0.8f)
        refresh(); paintBubble()
    }

    private fun edit() {
        m.stopAll(); m.active = false
        runCatching { layer.releasePointerCapture() }
        editing = true
        applyFlags(fEdit, 1f)
        refresh(); paintBubble()
    }

    private fun save() { if (::profile.isInitialized) Store.save(svc, profile) }

    // ------------------------------------------------------------ mouse capturado
    private fun onCaptured(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_HOVER_MOVE -> m.onMouse(e.x, e.y)
            MotionEvent.ACTION_BUTTON_PRESS -> m.onMouseButton(mcode(e.actionButton), true)
            MotionEvent.ACTION_BUTTON_RELEASE -> m.onMouseButton(mcode(e.actionButton), false)
        }
    }

    private fun mcode(b: Int) = when (b) {
        MotionEvent.BUTTON_PRIMARY -> -1
        MotionEvent.BUTTON_SECONDARY -> -2
        else -> -3
    }

    // ------------------------------------------------------------ dibujo
    private fun refresh() {
        layer.removeAllViews(); views.clear(); panel = null
        lines = LineView(ctx) { profile.buttons }.also { layer.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        for (b in profile.buttons) {
            addBtn(b, false)
            if (editing && b.type == BType.SWIPE) addBtn(b, true)
        }
        if (editing) { palette(); inspector() }
    }

    private fun addBtn(b: MapButton, end: Boolean) {
        val s = svc.screen()
        val sz = if (end) (36 * d).toInt() else b.size.toInt()
        val v = BtnView(ctx, b, end)
        v.selected = (b === sel && !end)
        layer.addView(v, FrameLayout.LayoutParams(sz, sz))
        v.x = (if (end) b.fx2 else b.fx) * s.x - sz / 2f
        v.y = (if (end) b.fy2 else b.fy) * s.y - sz / 2f
        views.add(v)
        if (editing) v.setOnTouchListener(drag(v, b, end))
    }

    private fun relayout(b: MapButton) {
        val s = svc.screen()
        views.filter { it.b === b && !it.end }.forEach { v ->
            val sz = b.size.toInt()
            v.layoutParams = FrameLayout.LayoutParams(sz, sz)
            v.x = b.fx * s.x - sz / 2f; v.y = b.fy * s.y - sz / 2f
            v.invalidate()
        }
    }

    private fun select(b: MapButton?) {
        sel = b
        views.forEach { it.selected = (it.b === b && !it.end); it.invalidate() }
        inspector()
    }

    private fun drag(v: BtnView, b: MapButton, end: Boolean): View.OnTouchListener {
        var ox = 0f; var oy = 0f; var moved = false
        return View.OnTouchListener { _, e ->
            val s = svc.screen()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    ox = v.x - e.rawX; oy = v.y - e.rawY; moved = false
                    if (sel !== b) select(b)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (b.locked && !end) return@OnTouchListener true
                    if (!moved) { snap(); moved = true }
                    v.x = e.rawX + ox; v.y = e.rawY + oy
                    val fx = ((v.x + v.width / 2f) / s.x).coerceIn(0f, 1f)
                    val fy = ((v.y + v.height / 2f) / s.y).coerceIn(0f, 1f)
                    if (end) { b.fx2 = fx; b.fy2 = fy } else { b.fx = fx; b.fy = fy }
                    lines?.invalidate()
                }
            }
            true
        }
    }

    // ------------------------------------------------------------ deshacer / rehacer
    private fun snap() { undoS.add(g.toJson(profile)); if (undoS.size > 50) undoS.removeAt(0); redoS.clear() }
    private fun restore(json: String) {
        profile = g.fromJson(json, Profile::class.java)
        m.buttons = profile.buttons; sel = null; refresh()
    }
    private fun doUndo() { if (undoS.isEmpty()) return; redoS.add(g.toJson(profile)); restore(undoS.removeAt(undoS.size - 1)) }
    private fun doRedo() { if (redoS.isEmpty()) return; undoS.add(g.toJson(profile)); restore(redoS.removeAt(redoS.size - 1)) }

    // ------------------------------------------------------------ UI de edición
    private fun mk(t: String, f: () -> Unit) = Button(ctx).apply {
        text = t; textSize = 10f; isAllCaps = false
        minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
        setPadding(6, 10, 6, 10)
        setOnClickListener { f() }
    }

    private fun palette() {
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(0xDD202020.toInt()) }
        fun add(t: String, f: () -> Unit) = row.addView(mk(t, f))
        BType.values().forEach { t -> add("+ " + t.label) { addButton(t) } }
        add("↶") { doUndo() }
        add("↷") { doRedo() }
        add("Guardar") { save(); toast("Perfil guardado") }
        add("Cerrar") { svc.stop() }
        val sv = HorizontalScrollView(ctx).apply { addView(row) }
        layer.addView(sv, FrameLayout.LayoutParams((svc.screen().x * 0.7f).toInt(), -2))
    }

    private fun defaults(b: MapButton) {
        b.opt = false; b.opt2 = false
        when (b.type) {
            BType.TAP -> b.size = 120f
            BType.TURBO -> { b.size = 120f; b.param = 10f }
            BType.SWIPE -> { b.size = 120f; b.param = 300f }
            BType.MACRO -> { b.size = 120f; b.param = 1f; b.param2 = 1f }
            BType.JOYSTICK -> { b.size = 260f; b.param = 0.4f }
            BType.LOOK -> { b.size = 600f; b.param = 1f; b.param2 = 1f; if (b.key == 0) b.key = KeyEvent.KEYCODE_F1 }
        }
    }

    private fun addButton(t: BType) {
        snap()
        val b = MapButton(type = t)
        defaults(b)
        if (t == BType.JOYSTICK) { b.fx = 0.2f; b.fy = 0.7f }
        if (t == BType.LOOK) { b.fx = 0.75f; b.fy = 0.5f }
        profile.buttons.add(b); sel = b; refresh()
    }

    private fun meta(t: BType): List<Triple<String, Float, Float>> = when (t) {
        BType.TURBO -> listOf(Triple("CPS (clics/seg)", 1f, 50f))
        BType.SWIPE -> listOf(Triple("Duración (ms)", 50f, 1500f))
        BType.MACRO -> listOf(Triple("Repeticiones", 1f, 50f), Triple("Velocidad (x)", 0.25f, 4f))
        BType.JOYSTICK -> listOf(Triple("Suavizado", 0.05f, 1f))
        BType.LOOK -> listOf(Triple("Sensibilidad X", 0.2f, 5f), Triple("Sensibilidad Y", 0.2f, 5f))
        else -> emptyList()
    }

    private fun opts(t: BType): List<String> = when (t) {
        BType.TAP -> listOf("Mantener mientras la tecla esté pulsada")
        BType.TURBO -> listOf("Modo toggle (pulsa = on/off)", "Variación aleatoria")
        BType.MACRO -> listOf("Bucle infinito")
        else -> emptyList()
    }

    private fun stepText(s: Step) = when (s.k) {
        "tap" -> "Toque"
        "swipe" -> "Deslizar ${s.ms}ms"
        else -> "Espera ${s.ms}ms"
    }

    private fun inspector() {
        panel?.let { layer.removeView(it) }; panel = null
        val b = sel ?: return
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad); setBackgroundColor(0xEE202020.toInt())
        }
        fun tv(t: String) { col.addView(TextView(ctx).apply { text = t; setTextColor(Color.WHITE); textSize = 12f }) }
        fun row(): LinearLayout = LinearLayout(ctx).also { col.addView(it) }
        fun LinearLayout.btn(t: String, f: () -> Unit) { addView(mk(t, f), LinearLayout.LayoutParams(0, -2, 1f)) }
        fun seek(label: String, lo: Float, hi: Float, v: Float, set: (Float) -> Unit) {
            val t = TextView(ctx).apply { setTextColor(Color.WHITE); textSize = 11f }
            fun upd(x: Float) { t.text = label + ": " + (Math.round(x * 100) / 100f) }
            upd(v)
            val sb = SeekBar(ctx)
            sb.max = 100
            sb.progress = (((v - lo) / (hi - lo)) * 100).toInt().coerceIn(0, 100)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u) { val x = lo + (hi - lo) * p / 100f; set(x); upd(x) }
                }
                override fun onStartTrackingTouch(s: SeekBar?) { snap() }
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            col.addView(t); col.addView(sb)
        }

        tv(b.type.label + "  ·  " + (if (b.type == BType.JOYSTICK) b.keys.joinToString(" ") { keyName(it) } else keyName(b.key)))
        if (b.type == BType.JOYSTICK) {
            row().apply { btn("Asignar teclas (↑ ← ↓ →)") { assignJoy(b) } }
        } else {
            row().apply {
                btn("Tecla") { assign(b) }
                btn("Clic izq") { snap(); b.key = -1; refresh() }
                btn("Clic der") { snap(); b.key = -2; refresh() }
            }
        }
        row().apply {
            btn("Tipo ↻") {
                snap(); val v = BType.values(); b.type = v[(b.type.ordinal + 1) % v.size]; defaults(b); refresh()
            }
            btn("Duplicar") {
                snap()
                val c = g.fromJson(g.toJson(b), MapButton::class.java)
                c.id = UUID.randomUUID().toString(); c.fx = (c.fx + 0.05f).coerceAtMost(1f); c.key = 0
                profile.buttons.add(c); sel = c; refresh()
            }
            btn("Borrar") { snap(); profile.buttons.remove(b); sel = null; refresh() }
            btn(if (b.locked) "Desbloq." else "Bloquear") { snap(); b.locked = !b.locked; inspector() }
        }
        seek("Tamaño", 40f, 800f, b.size) { x -> b.size = x; relayout(b) }
        seek("Opacidad", 0.15f, 1f, b.alpha) { x -> b.alpha = x; views.filter { it.b === b }.forEach { it.invalidate() } }
        meta(b.type).forEachIndexed { i, (label, lo, hi) ->
            seek(label, lo, hi, if (i == 0) b.param else b.param2) { x -> if (i == 0) b.param = x else b.param2 = x }
        }
        opts(b.type).forEachIndexed { i, t ->
            col.addView(CheckBox(ctx).apply {
                text = t; textSize = 12f; setTextColor(Color.WHITE)
                isChecked = if (i == 0) b.opt else b.opt2
                setOnCheckedChangeListener { _, c -> snap(); if (i == 0) b.opt = c else b.opt2 = c }
            })
        }
        if (b.type == BType.MACRO) {
            row().apply {
                btn("● Grabar") { record(b) }
                btn("Borrar pasos") { snap(); b.steps.clear(); inspector() }
            }
            tv("Pasos: " + b.steps.size)
            b.steps.forEachIndexed { i, s ->
                row().apply {
                    addView(TextView(ctx).apply { text = "${i + 1}. " + stepText(s); setTextColor(Color.WHITE); textSize = 11f }, LinearLayout.LayoutParams(0, -2, 2f))
                    if (s.k == "wait") {
                        btn("−") { snap(); s.ms = max(0L, s.ms - 50); inspector() }
                        btn("+") { snap(); s.ms += 50; inspector() }
                    }
                    btn("×") { snap(); b.steps.removeAt(i); inspector() }
                }
            }
        }
        val sv = ScrollView(ctx).apply { addView(col) }
        layer.addView(sv, FrameLayout.LayoutParams((240 * d).toInt(), -1, Gravity.END))
        panel = sv
    }

    // ------------------------------------------------------------ asignar teclas
    private fun conflict(b: MapButton, code: Int) {
        profile.buttons.firstOrNull { it !== b && code in it.allKeys() }?.let { toast("⚠ Conflicto con botón " + it.type.label) }
    }

    private fun assign(b: MapButton) {
        toast("Pulsa una tecla…")
        svc.captureKey = { code -> snap(); conflict(b, code); b.key = code; refresh() }
    }

    private fun assignJoy(b: MapButton) {
        val names = listOf("ARRIBA", "IZQUIERDA", "ABAJO", "DERECHA")
        snap()
        fun next(i: Int) {
            if (i == 4) { refresh(); return }
            toast("Pulsa tecla: " + names[i])
            svc.captureKey = { code -> b.keys[i] = code; next(i + 1) }
        }
        next(0)
    }

    // ------------------------------------------------------------ grabación de macros
    private fun record(b: MapButton) {
        layer.removeAllViews(); panel = null
        val rec = ArrayList<Step>()
        var lastEnd = 0L; var t0 = 0L; var x0 = 0f; var y0 = 0f
        val s = svc.screen()
        val v = View(ctx).apply { setBackgroundColor(0x33FF0000) }
        v.setOnTouchListener { _, e ->
            val now = SystemClock.uptimeMillis()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (lastEnd > 0 && now - lastEnd > 30) rec.add(Step("wait", ms = now - lastEnd))
                    t0 = now; x0 = e.rawX; y0 = e.rawY
                }
                MotionEvent.ACTION_UP -> {
                    if (hypot(e.rawX - x0, e.rawY - y0) < 24 * d) rec.add(Step("tap", x0 / s.x, y0 / s.y))
                    else rec.add(Step("swipe", x0 / s.x, y0 / s.y, e.rawX / s.x, e.rawY / s.y, max(80L, now - t0)))
                    lastEnd = now
                }
            }
            true
        }
        layer.addView(v, FrameLayout.LayoutParams(-1, -1))
        layer.addView(mk("■ Detener grabación") { snap(); b.steps = rec; refresh() }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        toast("Grabando: toca / desliza en la pantalla")
    }
}
