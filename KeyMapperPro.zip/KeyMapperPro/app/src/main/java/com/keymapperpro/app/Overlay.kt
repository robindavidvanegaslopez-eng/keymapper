package com.keymapperpro.app

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.SystemClock
import android.text.TextUtils
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import com.google.gson.Gson
import java.util.UUID
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ---------------------------------------------------------------- tema
val ACC: Int = Color.parseColor("#FF5A1F")
val C_PANEL: Int = Color.parseColor("#F2101012")
val C_CARD: Int = Color.parseColor("#1C1C1F")
val C_CARD2: Int = Color.parseColor("#2A2A2E")
val C_LINE: Int = Color.parseColor("#34343A")
val C_TXT: Int = Color.parseColor("#F2F2F2")
val C_SUB: Int = Color.parseColor("#9A9AA0")
val C_DANGER: Int = Color.parseColor("#E5484D")
val C_OK: Int = Color.parseColor("#3DDC84")

fun typeColor(t: BType): Int = Color.parseColor(
    when (t) {
        BType.TAP -> "#FF8A3D"
        BType.TURBO -> "#EF5350"
        BType.SWIPE -> "#4CD08A"
        BType.MACRO -> "#B66DFF"
        BType.JOYSTICK -> "#E6E6E6"
        BType.LOOK -> "#FFCA28"
    }
)

fun keyName(k: Int): String = when (k) {
    0 -> "?"
    -1 -> "ClicI"
    -2 -> "ClicD"
    -3 -> "ClicM"
    else -> KeyEvent.keyCodeToString(k).removePrefix("KEYCODE_")
}

fun shortKey(k: Int, n: Int = 4): String = when (val s = keyName(k)) {
    "DPAD_UP" -> "↑"
    "DPAD_DOWN" -> "↓"
    "DPAD_LEFT" -> "←"
    "DPAD_RIGHT" -> "→"
    "SPACE" -> "Esp"
    else -> s.take(n)
}

// ---------------------------------------------------------------- vistas de botones
class BtnView(ctx: Context, val b: MapButton, val end: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    var picked = false

    private fun lighten(c: Int) = Color.rgb(min(255, Color.red(c) + 70), min(255, Color.green(c) + 70), min(255, Color.blue(c) + 70))
    private fun base() = (70 + b.alpha * 185).toInt().coerceIn(60, 255)

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int = Color.WHITE, bold: Boolean = true) {
        p.style = Paint.Style.FILL; p.shader = null; p.color = col
        p.textAlign = Paint.Align.CENTER; p.textSize = size
        p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        p.setShadowLayer(size * 0.15f, 0f, size * 0.06f, Color.BLACK)
        c.drawText(s, x, y + size / 3f, p)
        p.clearShadowLayer()
    }

    private fun ring(c: Canvas, w: Float, r: Float) {
        p.shader = null; p.style = Paint.Style.STROKE
        p.strokeWidth = if (picked) 7f else 3f
        p.color = if (picked) ACC else Color.WHITE
        p.alpha = if (picked) 255 else 200
        c.drawCircle(w, w, r, p)
        if (picked) { p.strokeWidth = 2f; p.color = Color.WHITE; p.alpha = 230; c.drawCircle(w, w, r - 7f, p) }
    }

    override fun onDraw(c: Canvas) {
        val w = width / 2f
        val r = w - 5f
        if (end) { drawEnd(c, w, r); return }
        when (b.type) {
            BType.JOYSTICK -> drawJoy(c, w, r)
            BType.LOOK -> drawLook(c, w, r)
            else -> drawBtn(c, w, r)
        }
    }

    private fun drawEnd(c: Canvas, w: Float, r: Float) {
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(w, w * 0.8f, r * 1.2f, lighten(typeColor(BType.SWIPE)), typeColor(BType.SWIPE), Shader.TileMode.CLAMP)
        p.alpha = 235
        c.drawCircle(w, w, r, p)
        ring(c, w, r)
        txt(c, "B", w, w, width * 0.5f)
    }

    private fun drawBtn(c: Canvas, w: Float, r: Float) {
        val col = typeColor(b.type)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(w, w * 0.75f, r * 1.2f, lighten(col), col, Shader.TileMode.CLAMP)
        p.alpha = base()
        c.drawCircle(w, w, r, p)
        ring(c, w, r)
        val big = min(width * 0.26f, 48f)
        txt(c, shortKey(b.key, 5), w, w + big * 0.15f, big)
        txt(c, b.type.label.uppercase(), w, w - big * 0.95f, big * 0.42f, Color.argb(225, 255, 255, 255), false)
    }

    private fun drawJoy(c: Canvas, w: Float, r: Float) {
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            w, w, r,
            intArrayOf(Color.argb(60, 255, 255, 255), Color.argb(150, 14, 14, 16), Color.argb(215, 0, 0, 0)),
            floatArrayOf(0f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        p.alpha = base()
        c.drawCircle(w, w, r, p)
        ring(c, w, r)
        // aro punteado interior
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = Color.WHITE; p.alpha = 80
        p.pathEffect = DashPathEffect(floatArrayOf(4f, 10f), 0f)
        c.drawCircle(w, w, r * 0.62f, p)
        p.pathEffect = null
        // flechas + teclas (arriba, izquierda, abajo, derecha)
        val ang = floatArrayOf(-90f, 180f, 90f, 0f)
        val ts = max(11f, min(r * 0.16f, 34f))
        for (i in 0 until 4) {
            val rad = Math.toRadians(ang[i].toDouble())
            val dx = cos(rad).toFloat(); val dy = sin(rad).toFloat()
            val cx = w + dx * r * 0.52f; val cy = w + dy * r * 0.52f
            val s = r * 0.07f
            path.reset()
            path.moveTo(cx + dx * s * 1.3f, cy + dy * s * 1.3f)
            path.lineTo(cx - dx * s * 0.7f - dy * s, cy - dy * s * 0.7f + dx * s)
            path.lineTo(cx - dx * s * 0.7f + dy * s, cy - dy * s * 0.7f - dx * s)
            path.close()
            p.style = Paint.Style.FILL; p.color = if (picked) ACC else Color.WHITE; p.alpha = 220
            c.drawPath(path, p)
            txt(c, shortKey(b.keys[i], 3), w + dx * r * 0.80f, w + dy * r * 0.80f, ts)
        }
        // marcas de diagonales
        p.style = Paint.Style.FILL; p.color = Color.WHITE; p.alpha = 120
        for (a in floatArrayOf(-45f, 45f, 135f, 225f)) {
            val rad = Math.toRadians(a.toDouble())
            c.drawCircle(w + cos(rad).toFloat() * r * 0.8f, w + sin(rad).toFloat() * r * 0.8f, 3.5f, p)
        }
        // palanca
        val tr = r * 0.3f
        p.shader = RadialGradient(w - tr * 0.3f, w - tr * 0.35f, tr * 1.3f, Color.rgb(250, 250, 250), Color.rgb(70, 70, 76), Shader.TileMode.CLAMP)
        p.style = Paint.Style.FILL; p.alpha = 255
        c.drawCircle(w, w, tr, p)
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = ACC; p.alpha = 255
        c.drawCircle(w, w, tr, p)
    }

    private fun drawLook(c: Canvas, w: Float, r: Float) {
        val col = typeColor(BType.LOOK)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            w, w, r,
            intArrayOf(Color.argb(20, 255, 255, 255), Color.argb(110, 10, 10, 10)),
            floatArrayOf(0.4f, 1f), Shader.TileMode.CLAMP
        )
        p.alpha = base()
        c.drawCircle(w, w, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = if (picked) 6f else 3f
        p.color = if (picked) ACC else col; p.alpha = 255
        p.pathEffect = DashPathEffect(floatArrayOf(22f, 14f), 0f)
        c.drawCircle(w, w, r, p)
        p.pathEffect = null
        val a = r * 0.12f; val bb = r * 0.3f
        p.strokeWidth = 4f; p.color = col; p.alpha = 230
        c.drawLine(w - bb, w, w - a, w, p); c.drawLine(w + a, w, w + bb, w, p)
        c.drawLine(w, w - bb, w, w - a, p); c.drawLine(w, w + a, w, w + bb, p)
        p.style = Paint.Style.FILL; c.drawCircle(w, w, 5f, p)
        txt(c, "MIRA · " + shortKey(b.key, 5), w, w + r * 0.62f, max(12f, min(r * 0.1f, 30f)), col)
    }
}

class LineView(ctx: Context, private val bs: () -> List<MapButton>) : View(ctx) {
    private val col = typeColor(BType.SWIPE)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col; strokeWidth = 6f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val f = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col; style = Paint.Style.FILL }
    private val path = Path()

    override fun onDraw(c: Canvas) {
        for (b in bs()) {
            if (b.type != BType.SWIPE) continue
            val x1 = b.fx * width; val y1 = b.fy * height; val x2 = b.fx2 * width; val y2 = b.fy2 * height
            p.pathEffect = DashPathEffect(floatArrayOf(22f, 14f), 0f)
            c.drawLine(x1, y1, x2, y2, p)
            val a = atan2(y2 - y1, x2 - x1)
            val s = 28f
            path.reset()
            path.moveTo(x2, y2)
            path.lineTo(x2 - cos(a - 0.45f) * s, y2 - sin(a - 0.45f) * s)
            path.lineTo(x2 - cos(a + 0.45f) * s, y2 - sin(a + 0.45f) * s)
            path.close()
            c.drawPath(path, f)
        }
    }
}

// ---------------------------------------------------------------- overlay
@SuppressLint("ClickableViewAccessibility")
class Overlay(private val svc: MapperService, private val m: Mapper) {
    private val ctx = ContextThemeWrapper(svc, android.R.style.Theme_DeviceDefault)
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = svc.resources.displayMetrics.density
    private val g = Gson()
    private val layer = FrameLayout(ctx)
    private val bubble = TextView(ctx)
    private lateinit var lp: LP
    private lateinit var bp: LP
    lateinit var profile: Profile
    var editing = false
    private var sel: MapButton? = null
    private var panel: View? = null
    private var banner: TextView? = null
    private var nudge = 1
    private var menu: View? = null
    private var dockLeft = false
    private var panelHidden = false
    private var posTv: TextView? = null
    private var lines: LineView? = null
    private val views = ArrayList<BtnView>()
    private val undoS = ArrayList<String>()
    private val redoS = ArrayList<String>()

    private val fBase = LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS
    private val fPlay = fBase or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_NOT_FOCUSABLE
    private val fLook = fBase or LP.FLAG_NOT_TOUCHABLE
    private val fEdit = fBase or LP.FLAG_NOT_FOCUSABLE

    private fun dp(v: Int) = (v * d).toInt()
    private fun rounded(fill: Int, r: Int, stroke: Int = 0, sw: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = r * d
        if (sw > 0) setStroke(dp(sw), stroke)
    }

    /** Mensaje grande en pantalla. ms = 0 → se queda hasta el siguiente cambio. */
    private fun hint(t: String, ms: Long = 2400) {
        banner?.let { layer.removeView(it) }
        val tv = TextView(ctx).apply {
            text = t; textSize = 17f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(dp(24), dp(14), dp(24), dp(14))
            background = rounded(Color.parseColor("#EE000000"), 30, ACC, 2)
        }
        banner = tv
        layer.addView(tv, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(28) })
        if (ms > 0) tv.postDelayed({ if (banner === tv) { layer.removeView(tv); banner = null } }, ms)
    }
    private fun toast(t: String) = hint(t)

    // ------------------------------------------------------------ ciclo de vida
    fun show(p: Profile, startEdit: Boolean = false) {
        val s = svc.screen()
        lp = LP(s.x, s.y, LP.TYPE_APPLICATION_OVERLAY, fPlay, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            alpha = 0.8f
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        layer.isFocusable = true
        layer.isFocusableInTouchMode = true
        layer.setOnCapturedPointerListener { _, e -> onCaptured(e); true }
        layer.setOnTouchListener { _, e -> if (editing && e.action == MotionEvent.ACTION_DOWN) select(null); false }
        wm.addView(layer, lp)

        bubble.apply {
            textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            minWidth = dp(54); minHeight = dp(54)
        }
        bp = LP(LP.WRAP_CONTENT, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY, LP.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(76)
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = bp.x; oy = bp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) + abs(dy) > 12 * d) moved = true
                    if (moved) { bp.x = ox + dx.toInt(); bp.y = oy + dy.toInt(); wm.updateViewLayout(bubble, bp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) { if (editing) play() else edit() }
            }
            true
        }
        wm.addView(bubble, bp)

        m.onLookChange = { on ->
            if (!editing) {
                if (on) {
                    applyFlags(fLook, 0.8f)
                    layer.postDelayed({ layer.requestFocus(); layer.requestPointerCapture() }, 150)
                } else {
                    layer.releasePointerCapture()
                    applyFlags(fPlay, 0.8f)
                }
            }
        }
        profile = p
        syncOrientation()
        if (startEdit) edit() else play()
    }

    fun hide() {
        m.onLookChange = {}
        m.stopAll(); m.active = false
        runCatching { layer.releasePointerCapture() }
        runCatching { wm.removeView(layer) }
        runCatching { wm.removeView(bubble) }
        save()
    }

    fun loadProfile(p: Profile) {
        profile = p; syncOrientation(); sel = null
        undoS.clear(); redoS.clear()
        refresh()
        hint("Perfil: " + p.name)
    }

    fun togglePause() {
        if (editing) return
        m.active = !m.active
        if (!m.active) m.stopAll()
        paintBubble()
        hint(if (m.active) "Mapeo activo" else "Mapeo en pausa  ·  F8 para reanudar")
    }

    private fun applyFlags(f: Int, a: Float) { lp.flags = f; lp.alpha = a; wm.updateViewLayout(layer, lp) }

    private fun paintBubble() {
        bubble.text = if (editing) "▶" else "✎"
        val ringCol = if (editing) ACC else if (m.active) C_OK else C_DANGER
        bubble.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#F0101012"))
            setStroke(dp(3), ringCol)
        }
    }

    fun play() {
        save()
        editing = false; sel = null
        m.buttons = profile.buttons; m.active = true
        applyFlags(fPlay, 0.8f)
        refresh(); paintBubble()
    }

    private fun edit() {
        m.stopAll(); m.active = false
        runCatching { layer.releasePointerCapture() }
        editing = true
        applyFlags(fEdit, 1f)
        refresh(); paintBubble()
        hint("Modo edición  ·  toca ＋ Añadir para agregar botones", 3500)
    }

    private fun save() { if (::profile.isInitialized) Store.save(svc, profile) }

    // ------------------------------------------------------------ mouse capturado
    private fun onCaptured(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_HOVER_MOVE -> m.onMouse(e.x, e.y)
            MotionEvent.ACTION_BUTTON_PRESS -> m.onMouseButton(mcode(e.actionButton), true)
            MotionEvent.ACTION_BUTTON_RELEASE -> m.onMouseButton(mcode(e.actionButton), false)
        }
    }

    private fun mcode(b: Int) = when (b) {
        MotionEvent.BUTTON_PRIMARY -> -1
        MotionEvent.BUTTON_SECONDARY -> -2
        else -> -3
    }

    // ------------------------------------------------------------ dibujo
    private fun refresh() {
        layer.removeAllViews(); views.clear(); panel = null; banner = null; menu = null
        lines = LineView(ctx) { profile.buttons }.also { layer.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        for (b in profile.buttons) {
            addBtn(b, false)
            if (editing && b.type == BType.SWIPE) addBtn(b, true)
        }
        if (editing) { topBar(); inspector() }
    }

    private fun addBtn(b: MapButton, end: Boolean) {
        val s = svc.screen()
        val sz = if (end) dp(40) else b.size.toInt()
        val v = BtnView(ctx, b, end)
        v.picked = (b === sel && !end)
        layer.addView(v, FrameLayout.LayoutParams(sz, sz))
        v.x = (if (end) b.fx2 else b.fx) * s.x - sz / 2f
        v.y = (if (end) b.fy2 else b.fy) * s.y - sz / 2f
        views.add(v)
        if (editing) v.setOnTouchListener(drag(v, b, end))
    }

    private fun relayout(b: MapButton) {
        val s = svc.screen()
        views.filter { it.b === b && !it.end }.forEach { v ->
            val sz = b.size.toInt()
            v.layoutParams = FrameLayout.LayoutParams(sz, sz)
            v.x = b.fx * s.x - sz / 2f; v.y = b.fy * s.y - sz / 2f
            v.invalidate()
        }
    }

    private fun select(b: MapButton?) {
        if (b != null && b !== sel) panelHidden = false
        sel = b
        views.forEach { it.picked = (it.b === b && !it.end); it.invalidate() }
        inspector()
    }

    private fun drag(v: BtnView, b: MapButton, end: Boolean): View.OnTouchListener {
        var ox = 0f; var oy = 0f; var moved = false
        return View.OnTouchListener { _, e ->
            val s = svc.screen()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    ox = v.x - e.rawX; oy = v.y - e.rawY; moved = false
                    if (sel !== b) select(b)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (b.locked && !end) return@OnTouchListener true
                    if (!moved) { snap(); moved = true }
                    v.x = e.rawX + ox; v.y = e.rawY + oy
                    val fx = ((v.x + v.width / 2f) / s.x).coerceIn(0f, 1f)
                    val fy = ((v.y + v.height / 2f) / s.y).coerceIn(0f, 1f)
                    if (end) { b.fx2 = fx; b.fy2 = fy } else { b.fx = fx; b.fy = fy }
                    lines?.invalidate()
                    if (!end) posTv?.text = posText(b)
                }
                MotionEvent.ACTION_UP -> if (moved && !end && (b.fx > 0.5f) != dockLeft && panel != null && !panelHidden) inspector()
            }
            true
        }
    }

    // ------------------------------------------------------------ deshacer / rehacer
    private fun snap() { undoS.add(g.toJson(profile)); if (undoS.size > 50) undoS.removeAt(0); redoS.clear() }
    private fun restore(json: String) {
        profile = g.fromJson(json, Profile::class.java)
        m.buttons = profile.buttons; sel = null; refresh()
    }
    private fun doUndo() { if (undoS.isEmpty()) return; redoS.add(g.toJson(profile)); restore(undoS.removeAt(undoS.size - 1)) }
    private fun doRedo() { if (redoS.isEmpty()) return; undoS.add(g.toJson(profile)); restore(redoS.removeAt(redoS.size - 1)) }

    // ------------------------------------------------------------ componentes de UI
    /** kind: 0 normal, 1 principal (naranja), 2 peligro */
    private fun mk(t: String, kind: Int = 0, strokeCol: Int = 0, f: () -> Unit) = Button(ctx).apply {
        text = t; textSize = 14f; isAllCaps = false; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (kind == 1) Color.BLACK else if (kind == 2) Color.parseColor("#FF8A8E") else Color.WHITE)
        stateListAnimator = null; elevation = 0f
        minWidth = 0; minimumWidth = 0; minHeight = dp(48); minimumHeight = dp(48)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = when (kind) {
            1 -> rounded(ACC, 14)
            2 -> rounded(Color.parseColor("#3A1517"), 14, C_DANGER, 1)
            else -> rounded(C_CARD2, 14, if (strokeCol != 0) strokeCol else C_LINE, if (strokeCol != 0) 2 else 1)
        }
        setOnClickListener { f() }
    }

    private fun topBar() {
        val s = svc.screen()
        val w = min(s.x - dp(20), dp(580))
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(dp(6), dp(6), dp(6), dp(6))
            background = rounded(C_PANEL, 20, C_LINE, 1)
        }
        fun add(t: String, kind: Int, wgt: Float, f: () -> Unit) {
            val bt = mk(t, kind, 0, f).apply {
                textSize = 13f; minHeight = dp(44); minimumHeight = dp(44); setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            bar.addView(bt, LinearLayout.LayoutParams(0, -2, wgt).apply { marginStart = dp(3); marginEnd = dp(3) })
        }
        add("＋ Añadir", 1, 1.7f) { addMenu() }
        add("↶", 0, 0.8f) { doUndo() }
        add("↷", 0, 0.8f) { doRedo() }
        add("Guardar", 0, 1.3f) { save(); hint("Perfil guardado ✓") }
        add("▶ Jugar", 0, 1.4f) { play() }
        add("✕ Salir", 2, 1.3f) { svc.stop() }
        layer.addView(bar, FrameLayout.LayoutParams(w, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(8) })
    }

    private fun closeMenu() { menu?.let { layer.removeView(it) }; menu = null }

    private fun tile(t: BType): View {
        val ll = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(C_CARD, 18, typeColor(t), 2)
            isClickable = true
            setOnClickListener { closeMenu(); addButton(t) }
        }
        ll.addView(BtnView(ctx, MapButton(type = t, alpha = 0.9f), false), LinearLayout.LayoutParams(dp(54), dp(54)))
        ll.addView(TextView(ctx).apply {
            text = t.label; textSize = 17f; setTextColor(C_TXT); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0)
        })
        ll.addView(TextView(ctx).apply {
            text = desc(t); textSize = 11f; setTextColor(C_SUB); gravity = Gravity.CENTER
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END
        })
        return ll
    }

    /** Menú grande de tipos de botón (rejilla, sin barra desplazable). */
    private fun addMenu() {
        closeMenu()
        val s = svc.screen()
        val land = s.x > s.y
        val w = min(s.x - dp(32), dp(760))
        val h = min(s.y - dp(32), if (land) dp(430) else dp(640))
        val root = FrameLayout(ctx)
        root.addView(View(ctx).apply {
            setBackgroundColor(Color.parseColor("#B3000000")); setOnClickListener { closeMenu() }
        }, FrameLayout.LayoutParams(-1, -1))
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(14))
            background = rounded(Color.parseColor("#F5101012"), 26, C_LINE, 1)
            isClickable = true
        }
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(TextView(ctx).apply { text = "Añadir botón"; textSize = 22f; setTextColor(C_TXT); typeface = Typeface.DEFAULT_BOLD })
        titles.addView(TextView(ctx).apply { text = "Elige un tipo. Aparece en el centro; arrástralo donde lo necesites."; textSize = 12f; setTextColor(C_SUB) })
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(mk("✕") { closeMenu() }, LinearLayout.LayoutParams(dp(52), -2))
        box.addView(head)
        val types = BType.values()
        val cols = if (land) 3 else 2
        val rows = (types.size + cols - 1) / cols
        for (r in 0 until rows) {
            val line = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until cols) {
                val i = r * cols + c
                val cell = LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
                if (i >= types.size) line.addView(View(ctx), cell) else line.addView(tile(types[i]), cell)
            }
            box.addView(line, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(4) })
        }
        root.addView(box, FrameLayout.LayoutParams(w, h, Gravity.CENTER))
        layer.addView(root, FrameLayout.LayoutParams(-1, -1))
        menu = root
    }

    private fun scaleK(): Float { val s = svc.screen(); return (min(s.x, s.y) / 1080f).coerceIn(0.5f, 2.5f) }

    private fun defaults(b: MapButton) {
        b.opt = false; b.opt2 = false
        when (b.type) {
            BType.TAP -> b.size = 130f
            BType.TURBO -> { b.size = 130f; b.param = 10f }
            BType.SWIPE -> { b.size = 130f; b.param = 300f }
            BType.MACRO -> { b.size = 130f; b.param = 1f; b.param2 = 1f }
            BType.JOYSTICK -> { b.size = 300f; b.param = 0.4f }
            BType.LOOK -> { b.size = 600f; b.param = 1f; b.param2 = 1f; if (b.key == 0) b.key = KeyEvent.KEYCODE_F1 }
        }
        b.size *= scaleK()
    }

    private fun addButton(t: BType) {
        snap()
        val b = MapButton(type = t)
        defaults(b)
        if (t == BType.JOYSTICK) { b.fx = 0.2f; b.fy = 0.7f }
        if (t == BType.LOOK) { b.fx = 0.75f; b.fy = 0.5f }
        profile.buttons.add(b); sel = b; panelHidden = false; refresh()
    }

    private class PMeta(val label: String, val lo: Float, val hi: Float, val unit: String = "", val whole: Boolean = false)

    private fun meta(t: BType): List<PMeta> = when (t) {
        BType.TURBO -> listOf(PMeta("Velocidad de clics", 1f, 50f, " clics/s", true))
        BType.SWIPE -> listOf(PMeta("Duración del deslizamiento", 50f, 1500f, " ms", true))
        BType.MACRO -> listOf(PMeta("Repeticiones", 1f, 50f, "x", true), PMeta("Velocidad de reproducción", 0.25f, 4f, "x"))
        BType.LOOK -> listOf(PMeta("Sensibilidad horizontal", 0.2f, 5f, "x"), PMeta("Sensibilidad vertical", 0.2f, 5f, "x"))
        else -> emptyList()
    }

    private fun opts(t: BType): List<String> = when (t) {
        BType.TAP -> listOf("Mantener pulsado mientras la tecla esté pulsada")
        BType.TURBO -> listOf("Modo toggle (una pulsación activa / otra apaga)", "Variación aleatoria de posición y tiempo")
        BType.MACRO -> listOf("Repetir en bucle infinito")
        else -> emptyList()
    }

    private fun desc(t: BType) = when (t) {
        BType.TAP -> "Toca el punto de la pantalla donde colocas este botón."
        BType.TURBO -> "Toca una y otra vez mientras mantienes la tecla."
        BType.SWIPE -> "Desliza del círculo A al círculo B (arrastra la B verde)."
        BType.MACRO -> "Reproduce una secuencia grabada de toques y deslizamientos."
        BType.JOYSTICK -> "Mueve al personaje con 4 teclas. Combina dos para las diagonales."
        BType.LOOK -> "El mouse mueve la cámara dentro de esta zona."
    }

    private fun stepText(s: Step) = when (s.k) {
        "tap" -> "Toque"
        "swipe" -> "Deslizar ${s.ms} ms"
        else -> "Espera ${s.ms} ms"
    }

    private fun inspector() {
        panel?.let { layer.removeView(it) }; panel = null
        val b = sel ?: return
        dockLeft = b.fx > 0.5f
        if (panelHidden) { showTab(b); return }
        val tcol = typeColor(b.type)
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(18)) }
        var host: LinearLayout = col

        fun tv(t: String, sp: Float = 14f, color: Int = C_TXT, bold: Boolean = false): TextView {
            val v = TextView(ctx).apply { text = t; textSize = sp; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }
            host.addView(v); return v
        }
        fun section(t: String) {
            col.addView(TextView(ctx).apply {
                text = t.uppercase(); textSize = 11f; setTextColor(C_SUB); letterSpacing = 0.12f
                typeface = Typeface.DEFAULT_BOLD; setPadding(dp(2), dp(16), 0, dp(6))
            })
            val card = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12))
                background = rounded(C_CARD, 16, C_LINE, 1)
            }
            col.addView(card); host = card
        }
        fun row(): LinearLayout {
            val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            host.addView(r, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            return r
        }
        fun LinearLayout.btn(t: String, kind: Int = 0, f: () -> Unit) {
            addView(mk(t, kind, 0, f), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        }
        fun seek(label: String, lo: Float, hi: Float, v: Float, fmt: (Float) -> String, set: (Float) -> Unit) {
            val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            val vv = TextView(ctx).apply { text = fmt(v); textSize = 14f; setTextColor(ACC); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.END }
            head.addView(TextView(ctx).apply { text = label; textSize = 14f; setTextColor(C_TXT) }, LinearLayout.LayoutParams(0, -2, 1f))
            head.addView(vv, LinearLayout.LayoutParams(-2, -2))
            val sb = SeekBar(ctx)
            sb.max = 100
            sb.progress = (((v - lo) / (hi - lo)) * 100).toInt().coerceIn(0, 100)
            sb.progressTintList = ColorStateList.valueOf(ACC)
            sb.thumbTintList = ColorStateList.valueOf(ACC)
            sb.setPadding(dp(8), dp(12), dp(8), dp(12))
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u) { val x = lo + (hi - lo) * p / 100f; set(x); vv.text = fmt(x) }
                }
                override fun onStartTrackingTouch(s: SeekBar?) { snap() }
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            host.addView(head, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
            host.addView(sb)
        }

        // ---- cabecera
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(View(ctx).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(tcol) }
        }, LinearLayout.LayoutParams(dp(16), dp(16)).apply { marginEnd = dp(10) })
        head.addView(TextView(ctx).apply { text = b.type.label; textSize = 24f; setTextColor(C_TXT); typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(mk(if (dockLeft) "‹ Ocultar" else "Ocultar ›") { panelHidden = true; inspector() }.apply {
            textSize = 12f; minHeight = dp(40); minimumHeight = dp(40)
        }, LinearLayout.LayoutParams(-2, -2))
        col.addView(head)
        tv(desc(b.type), 13f, C_SUB)

        // ---- tecla
        section(if (b.type == BType.JOYSTICK) "Teclas de dirección" else "Tecla")
        if (b.type == BType.JOYSTICK) {
            fun chip(arrow: String, k: Int) = TextView(ctx).apply {
                text = arrow + "  " + shortKey(k, 6); textSize = 17f; setTextColor(C_TXT); typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER; background = rounded(C_CARD2, 12)
            }
            fun spacer() = View(ctx)
            fun cell(v: View) = LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
            val r1 = LinearLayout(ctx); val r2 = LinearLayout(ctx)
            val sp1 = spacer(); val sp2 = spacer()
            r1.addView(sp1, cell(sp1)); val up = chip("↑", b.keys[0]); r1.addView(up, cell(up)); r1.addView(sp2, cell(sp2))
            val lf = chip("←", b.keys[1]); val dn = chip("↓", b.keys[2]); val rt = chip("→", b.keys[3])
            r2.addView(lf, cell(lf)); r2.addView(dn, cell(dn)); r2.addView(rt, cell(rt))
            host.addView(r1); host.addView(r2)
            row().apply { btn("Asignar las 4 teclas", 1) { assignJoy(b) } }
        } else {
            host.addView(TextView(ctx).apply {
                text = keyName(b.key); textSize = 30f; setTextColor(if (b.key == 0) C_SUB else C_TXT); typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12)); background = rounded(C_CARD2, 14)
            }, LinearLayout.LayoutParams(-1, -2))
            row().apply { btn("Asignar tecla", 1) { assign(b) } }
            row().apply {
                btn("Clic izquierdo") { snap(); b.key = -1; refresh() }
                btn("Clic derecho") { snap(); b.key = -2; refresh() }
            }
        }

        if (b.type == BType.JOYSTICK) {
            section("Detección automática")
            tv("Deja el joystick del juego visible y pulsa el botón: se coloca encima y ajusta su radio solo.", 13f, C_SUB)
            row().apply { btn("Detectar joystick", 1) { autoDetect(b) } }
        }

        // ---- acciones
        section("Acciones")
        row().apply {
            btn("Cambiar tipo") {
                snap(); val v = BType.values(); b.type = v[(b.type.ordinal + 1) % v.size]; defaults(b); refresh()
            }
            btn("Duplicar") {
                snap()
                val c = g.fromJson(g.toJson(b), MapButton::class.java)
                c.id = UUID.randomUUID().toString(); c.fx = (c.fx + 0.05f).coerceAtMost(1f); c.key = 0
                profile.buttons.add(c); sel = c; refresh()
            }
        }
        row().apply {
            btn(if (b.locked) "Desbloquear" else "Bloquear") { snap(); b.locked = !b.locked; inspector() }
            btn("Borrar", 2) { snap(); profile.buttons.remove(b); sel = null; refresh() }
        }

        // ---- ajuste fino
        section("Ajuste fino (milimétrico)")
        posTv = tv(posText(b), 15f, ACC, true)
        fun styleChip(c: Button, on: Boolean) {
            c.background = if (on) rounded(ACC, 14) else rounded(C_CARD2, 14, C_LINE, 1)
            c.setTextColor(if (on) Color.BLACK else Color.WHITE)
        }
        val chips = ArrayList<Button>()
        row().apply {
            for (n in intArrayOf(1, 5, 20)) {
                val chip = mk(n.toString() + " px") {}
                chip.tag = n
                styleChip(chip, nudge == n)
                chip.setOnClickListener { nudge = n; chips.forEach { c -> styleChip(c, (c.tag as Int) == n) } }
                chips.add(chip)
                addView(chip, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
            }
        }
        fun pc() = LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
        val pr1 = LinearLayout(ctx); val pr2 = LinearLayout(ctx)
        pr1.addView(View(ctx), pc()); pr1.addView(mk("↑") { move(b, 0, -1) }, pc()); pr1.addView(View(ctx), pc())
        pr2.addView(mk("←") { move(b, -1, 0) }, pc()); pr2.addView(mk("↓") { move(b, 0, 1) }, pc()); pr2.addView(mk("→") { move(b, 1, 0) }, pc())
        host.addView(pr1); host.addView(pr2)
        val rl = if (b.type == BType.JOYSTICK || b.type == BType.LOOK) "Radio" else "Tamaño"
        row().apply { btn(rl + " −") { resize(b, -1) }; btn(rl + " +") { resize(b, 1) } }

        // ---- apariencia
        section("Apariencia")
        seek("Tamaño", 40f, max(min(svc.screen().x, svc.screen().y) * 0.9f, b.size), b.size, { x -> x.toInt().toString() + " px" }) { x -> b.size = x; relayout(b) }
        seek("Opacidad", 0.15f, 1f, b.alpha, { x -> (x * 100).toInt().toString() + " %" }) { x ->
            b.alpha = x; views.filter { it.b === b }.forEach { it.invalidate() }
        }
        if (b.type == BType.JOYSTICK) tv("El tamaño define hasta dónde se mueve el dedo.", 12f, C_SUB)
        if (b.type == BType.LOOK) tv("El tamaño es la zona donde se mueve la cámara.", 12f, C_SUB)

        // ---- comportamiento
        val pms = meta(b.type); val os = opts(b.type)
        if (pms.isNotEmpty() || os.isNotEmpty()) {
            section("Comportamiento")
            pms.forEachIndexed { i, pm ->
                val fmt = { x: Float -> (if (pm.whole) x.toInt().toString() else "%.2f".format(x)) + pm.unit }
                seek(pm.label, pm.lo, pm.hi, if (i == 0) b.param else b.param2, fmt) { x -> if (i == 0) b.param = x else b.param2 = x }
            }
            os.forEachIndexed { i, t ->
                host.addView(CheckBox(ctx).apply {
                    text = t; textSize = 14f; setTextColor(C_TXT)
                    buttonTintList = ColorStateList.valueOf(ACC)
                    isChecked = if (i == 0) b.opt else b.opt2
                    setPadding(dp(6), dp(10), 0, dp(10))
                    setOnCheckedChangeListener { _, c -> snap(); if (i == 0) b.opt = c else b.opt2 = c }
                })
            }
        }

        // ---- macro
        if (b.type == BType.MACRO) {
            section("Pasos de la macro")
            row().apply {
                btn("● Grabar", 1) { record(b) }
                btn("Borrar todo", 2) { snap(); b.steps.clear(); inspector() }
            }
            tv(if (b.steps.isEmpty()) "Aún no hay pasos. Pulsa Grabar y toca la pantalla." else "${b.steps.size} pasos", 13f, C_SUB)
            b.steps.forEachIndexed { i, s ->
                row().apply {
                    gravity = Gravity.CENTER_VERTICAL
                    addView(TextView(ctx).apply { text = "${i + 1}.  " + stepText(s); setTextColor(C_TXT); textSize = 14f }, LinearLayout.LayoutParams(0, -2, 2f))
                    if (s.k == "wait") {
                        btn("−") { snap(); s.ms = max(0L, s.ms - 50); inspector() }
                        btn("+") { snap(); s.ms += 50; inspector() }
                    }
                    btn("×", 2) { snap(); b.steps.removeAt(i); inspector() }
                }
            }
        }

        val sv = ScrollView(ctx).apply {
            isVerticalScrollBarEnabled = false
            background = rounded(C_PANEL, 22, C_LINE, 1)
            addView(col)
        }
        val sc = svc.screen()
        if (sc.x > sc.y) {
            val pw = min(dp(310), (sc.x * 0.45f).toInt())
            val g0 = if (dockLeft) Gravity.START else Gravity.END
            layer.addView(sv, FrameLayout.LayoutParams(pw, -1, g0).apply { setMargins(dp(10), dp(74), dp(10), dp(10)) })
        } else {
            layer.addView(sv, FrameLayout.LayoutParams(-1, (sc.y * 0.5f).toInt(), Gravity.BOTTOM).apply { setMargins(dp(8), 0, dp(8), dp(8)) })
        }
        panel = sv
    }

    private fun showTab(b: MapButton) {
        val tab = mk("⚙ Editar " + b.type.label, 1) { panelHidden = false; inspector() }
        val g0 = (if (dockLeft) Gravity.START else Gravity.END) or Gravity.BOTTOM
        layer.addView(tab, FrameLayout.LayoutParams(-2, -2, g0).apply { setMargins(dp(10), 0, dp(10), dp(10)) })
        panel = tab
    }

    // ------------------------------------------------------------ orientación y tamaño de pantalla
    private fun syncOrientation() {
        val s = svc.screen()
        val now = s.x > s.y
        val cur = profile.land
        if (cur == null) profile.land = now
        else if (cur != now) {
            val t = profile.buttons; profile.buttons = profile.alt; profile.alt = t
            profile.land = now
        }
        val mn = min(s.x, s.y)
        if (profile.refMin == 0) profile.refMin = mn
        else if (profile.refMin != mn) {
            val f = mn / profile.refMin.toFloat()
            (profile.buttons + profile.alt).forEach { it.size *= f }
            profile.refMin = mn
        }
        m.buttons = profile.buttons
    }

    fun checkScreen() {
        if (!::lp.isInitialized) return
        val s = svc.screen()
        if (s.x != lp.width || s.y != lp.height) onScreenChanged()
    }

    fun onScreenChanged() {
        if (!::lp.isInitialized || !::profile.isInitialized) return
        val s = svc.screen()
        if (s.x == lp.width && s.y == lp.height) return
        m.stopAll()
        save()
        lp.width = s.x; lp.height = s.y
        runCatching { wm.updateViewLayout(layer, lp) }
        bp.x = bp.x.coerceIn(0, max(0, s.x - dp(60))); bp.y = bp.y.coerceIn(0, max(0, s.y - dp(60)))
        runCatching { wm.updateViewLayout(bubble, bp) }
        syncOrientation(); sel = null
        refresh()
        hint(if (s.x > s.y) "Pantalla horizontal" else "Pantalla vertical")
    }

    // ------------------------------------------------------------ ajuste fino
    private fun posText(b: MapButton): String {
        val s = svc.screen()
        return "X " + (b.fx * s.x).roundToInt() + "   Y " + (b.fy * s.y).roundToInt() + "   ·   Ø " + b.size.roundToInt() + " px"
    }

    private fun move(b: MapButton, dx: Int, dy: Int) {
        if (b.locked) { hint("Botón bloqueado"); return }
        snap()
        val s = svc.screen()
        b.fx = (b.fx + dx * nudge / s.x.toFloat()).coerceIn(0f, 1f)
        b.fy = (b.fy + dy * nudge / s.y.toFloat()).coerceIn(0f, 1f)
        relayout(b); lines?.invalidate(); posTv?.text = posText(b)
    }

    private fun resize(b: MapButton, dir: Int) {
        if (b.locked) { hint("Botón bloqueado"); return }
        snap()
        b.size = max(40f, b.size + dir * nudge * 2f)
        relayout(b); posTv?.text = posText(b)
    }

    // ------------------------------------------------------------ detección automática del joystick
    private fun autoDetect(b: MapButton) {
        if (Build.VERSION.SDK_INT < 30) { hint("La detección automática necesita Android 11 o superior"); return }
        layer.visibility = View.INVISIBLE
        bubble.visibility = View.INVISIBLE
        layer.postDelayed({ capture(b) }, 300)
    }

    private fun capture(b: MapButton) {
        val restore = { layer.visibility = View.VISIBLE; bubble.visibility = View.VISIBLE }
        svc.takeScreenshot(android.view.Display.DEFAULT_DISPLAY, svc.mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                restore()
                val hb = r.hardwareBuffer
                val soft = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                if (soft == null) { hint("No se pudo leer la captura"); return }
                hint("Analizando…", 0)
                Thread {
                    val res = runCatching { JoyDetector.detect(soft) }.getOrNull()
                    layer.post { applyDetected(b, res) }
                }.start()
            }

            override fun onFailure(code: Int) {
                restore()
                hint(if (code == 3) "Espera un segundo e inténtalo de nuevo" else "No se pudo capturar la pantalla (código $code)")
            }
        })
    }

    private fun applyDetected(b: MapButton, res: JoyDetector.Result?) {
        if (res == null) { hint("No encontré un joystick. Colócalo a mano con el ajuste fino."); return }
        snap()
        b.fx = res.cx.coerceIn(0f, 1f); b.fy = res.cy.coerceIn(0f, 1f)
        b.size = max(80f, res.r * 2f * 0.85f)
        refresh()
        hint("Joystick detectado · afina con las flechas si hace falta")
    }

    // ------------------------------------------------------------ asignar teclas
    private fun conflict(b: MapButton, code: Int) {
        profile.buttons.firstOrNull { it !== b && code in it.allKeys() }?.let { hint("⚠ Esa tecla ya la usa un botón " + it.type.label) }
    }

    private fun assign(b: MapButton) {
        hint("Pulsa la tecla que quieres asignar…", 0)
        svc.captureKey = { code -> snap(); conflict(b, code); b.key = code; val keep = banner?.text?.toString(); refresh(); if (keep != null && keep.startsWith("⚠")) hint(keep) }
    }

    private fun assignJoy(b: MapButton) {
        val names = listOf("ARRIBA", "IZQUIERDA", "ABAJO", "DERECHA")
        snap()
        fun next(i: Int) {
            if (i == 4) { refresh(); return }
            hint("Joystick: pulsa la tecla para " + names[i] + "  (" + (i + 1) + "/4)", 0)
            svc.captureKey = { code -> b.keys[i] = code; next(i + 1) }
        }
        next(0)
    }

    // ------------------------------------------------------------ grabación de macros
    private fun record(b: MapButton) {
        layer.removeAllViews(); panel = null; banner = null
        val rec = ArrayList<Step>()
        var lastEnd = 0L; var t0 = 0L; var x0 = 0f; var y0 = 0f
        val s = svc.screen()
        val v = View(ctx).apply { setBackgroundColor(0x33FF0000) }
        v.setOnTouchListener { _, e ->
            val now = SystemClock.uptimeMillis()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (lastEnd > 0 && now - lastEnd > 30) rec.add(Step("wait", ms = now - lastEnd))
                    t0 = now; x0 = e.rawX; y0 = e.rawY
                }
                MotionEvent.ACTION_UP -> {
                    if (hypot(e.rawX - x0, e.rawY - y0) < 24 * d) rec.add(Step("tap", x0 / s.x, y0 / s.y))
                    else rec.add(Step("swipe", x0 / s.x, y0 / s.y, e.rawX / s.x, e.rawY / s.y, max(80L, now - t0)))
                    lastEnd = now
                }
            }
            true
        }
        layer.addView(v, FrameLayout.LayoutParams(-1, -1))
        layer.addView(mk("■  Detener grabación", 2) { snap(); b.steps = rec; refresh() },
            FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(14) })
        hint("Grabando… toca o desliza la pantalla", 0)
    }
}
