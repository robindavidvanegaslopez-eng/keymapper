package com.keymapperpro.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Point
import android.provider.Settings
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class MapperService : AccessibilityService() {
    companion object { var inst: MapperService? = null }

    lateinit var mapper: Mapper
    var ui: Overlay? = null
    var captureKey: ((Int) -> Unit)? = null
    private var lastPkg = ""

    override fun onServiceConnected() {
        inst = this
        mapper = Mapper(this)
        Store.ensureDefault(this)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        stop(); inst = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == lastPkg) return
        lastPkg = pkg
        val p = Store.forPkg(this, pkg) ?: return
        val u = ui ?: return
        if (!u.editing && u.profile.name != p.name) u.setProfile(p)
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        val u = ui ?: return false
        val down = e.action == KeyEvent.ACTION_DOWN
        val cb = captureKey
        if (cb != null) {
            if (down && e.repeatCount == 0) { captureKey = null; cb(e.keyCode) }
            return true
        }
        if (e.keyCode == KeyEvent.KEYCODE_F8) { if (down && e.repeatCount == 0) u.togglePause(); return true }
        return mapper.onKey(e.keyCode, down, e.repeatCount > 0)
    }

    fun start() {
        if (ui != null) return
        if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "Falta el permiso de superposición", Toast.LENGTH_LONG).show(); return }
        val p = Store.current(this) ?: return
        ui = Overlay(this, mapper).also { it.show(p) }
    }

    fun stop() {
        ui?.hide(); ui = null
        if (::mapper.isInitialized) { mapper.stopAll(); mapper.active = false }
        captureKey = null
    }

    @Suppress("DEPRECATION")
    fun screen(): Point {
        val p = Point()
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealSize(p)
        return p
    }
}
