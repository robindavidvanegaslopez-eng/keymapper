package com.keymapperpro.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.ensureDefault(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) { Home(tick) } } }
    }

    override fun onResume() { super.onResume(); tick++ }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    @Composable
    private fun Home(t: Int) {
        var profiles by remember(t) { mutableStateOf(Store.list(this)) }
        var sel by remember(t) { mutableStateOf(Store.current(this)?.name ?: "") }
        var target by remember { mutableStateOf<Profile?>(null) }
        var dlg by remember { mutableStateOf(false) }
        var nName by remember { mutableStateOf("") }
        var nPkg by remember { mutableStateOf("") }
        val a11y = a11yOn()
        val ovl = Settings.canDrawOverlays(this)

        val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            val p = target
            if (uri != null && p != null) contentResolver.openOutputStream(uri)?.use { it.write(Store.toJson(p).toByteArray()) }
        }
        val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                val s = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                val p = s?.let { Store.fromJson(it) }
                if (p != null && p.name.isNotBlank()) { Store.save(this, p); profiles = Store.list(this) } else toast("Archivo no válido")
            }
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("KeyMapper Pro", style = MaterialTheme.typography.headlineMedium)
            Text("1. Permisos", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text((if (a11y) "✅ " else "❌ ") + "Servicio de accesibilidad", Modifier.weight(1f))
                if (!a11y) Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Activar") }
            }
            Text("Necesario para inyectar toques y leer las teclas del teclado físico. Búscalo en \"Apps instaladas\" → KeyMapper Pro.", style = MaterialTheme.typography.bodySmall)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text((if (ovl) "✅ " else "❌ ") + "Mostrar sobre otras apps", Modifier.weight(1f))
                if (!ovl) Button(onClick = { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }) { Text("Conceder") }
            }
            Text("Necesario para dibujar y editar los botones sobre el juego.", style = MaterialTheme.typography.bodySmall)

            Text("2. Perfiles", style = MaterialTheme.typography.titleMedium)
            profiles.forEach { p ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = p.name == sel, onClick = { sel = p.name; Store.select(this@MainActivity, p.name) })
                    Column(Modifier.weight(1f)) {
                        Text(p.name)
                        Text(if (p.pkg.isBlank()) "Manual" else p.pkg, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = { target = p; exp.launch(p.name + ".json") }) { Text("Exportar") }
                    TextButton(onClick = {
                        if (profiles.size > 1) { Store.delete(this@MainActivity, p); profiles = Store.list(this@MainActivity) } else toast("Debe quedar al menos un perfil")
                    }) { Text("Borrar") }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { dlg = true }) { Text("Nuevo perfil") }
                OutlinedButton(onClick = { imp.launch(arrayOf("*/*")) }) { Text("Importar") }
            }

            Text("3. Usar", style = MaterialTheme.typography.titleMedium)
            Button(enabled = a11y && ovl, onClick = {
                val s = MapperService.inst
                if (s == null) toast("Activa primero el servicio de accesibilidad")
                else { Store.select(this@MainActivity, sel); s.stop(); s.start(); moveTaskToBack(true) }
            }) { Text("Iniciar mapeo") }
            OutlinedButton(onClick = { MapperService.inst?.stop() }) { Text("Detener mapeo") }
            Text(
                "Burbuja flotante: toca para alternar Edición ↔ Juego (arrástrala para moverla). F8 pausa/reanuda el mapeo. " +
                    "La tecla del botón Mira (F1 por defecto) activa el mouse como cámara.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        if (dlg) AlertDialog(
            onDismissRequest = { dlg = false },
            title = { Text("Nuevo perfil") },
            text = {
                Column {
                    OutlinedTextField(nName, { nName = it }, label = { Text("Nombre") }, singleLine = true)
                    OutlinedTextField(nPkg, { nPkg = it }, label = { Text("Paquete de la app (opcional)") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (nName.isNotBlank()) {
                        Store.save(this@MainActivity, Profile(nName.trim(), nPkg.trim()))
                        profiles = Store.list(this@MainActivity); dlg = false; nName = ""; nPkg = ""
                    }
                }) { Text("Crear") }
            },
            dismissButton = { TextButton(onClick = { dlg = false }) { Text("Cancelar") } }
        )
    }
}
