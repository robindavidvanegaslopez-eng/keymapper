package com.keymapperpro.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Orange = Color(0xFFFF5A1F)
private val CardBg = Color(0xFF141416)
private val Sub = Color(0xFF9A9AA0)
private val Red = Color(0xFFE5484D)
private val Green = Color(0xFF3DDC84)

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title.uppercase(), color = Sub, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Surface(shape = RoundedCornerShape(20.dp), color = CardBg, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
        }
    }
}

@Composable
private fun PermRow(ok: Boolean, title: String, desc: String, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(if (ok) Green else Red))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(desc, fontSize = 12.sp, color = Sub)
        }
        if (!ok) Button(
            onClick = onClick,
            colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)
        ) { Text(action, fontWeight = FontWeight.Bold) }
    }
}

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.ensureDefault(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Orange, onPrimary = Color.Black,
                    background = Color.Black, surface = Color.Black,
                    onBackground = Color(0xFFF2F2F2), onSurface = Color(0xFFF2F2F2)
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Color.Black) { Home(tick) }
            }
        }
    }

    override fun onResume() { super.onResume(); tick++ }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    /** Abre el editor del perfil directamente sobre la app/juego que estaba debajo. */
    private fun openEditor(name: String) {
        val s = MapperService.inst
        if (!a11yOn() || s == null) { toast("Activa primero el servicio de accesibilidad"); return }
        if (!Settings.canDrawOverlays(this)) { toast("Falta el permiso de superposición"); return }
        Store.select(this, name)
        s.stop(); s.start(true)
        moveTaskToBack(true)
    }

    @Composable
    private fun Home(t: Int) {
        var profiles by remember(t) { mutableStateOf(Store.list(this)) }
        var sel by remember(t) { mutableStateOf(Store.current(this)?.name ?: "") }
        var target by remember { mutableStateOf<Profile?>(null) }
        var dlg by remember { mutableStateOf(false) }
        var nName by remember { mutableStateOf("") }
        var nPkg by remember { mutableStateOf("") }
        val a11y = a11yOn()
        val ovl = Settings.canDrawOverlays(this)

        val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            val p = target
            if (uri != null && p != null) contentResolver.openOutputStream(uri)?.use { it.write(Store.toJson(p).toByteArray()) }
        }
        val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                val s = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                val p = s?.let { Store.fromJson(it) }
                if (p != null && p.name.isNotBlank()) { Store.save(this, p); profiles = Store.list(this) } else toast("Archivo no válido")
            }
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // ---- cabecera con logo
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(72.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF0A0A0A))
                        .border(1.dp, Color(0xFF2C2C2E), RoundedCornerShape(20.dp))
                ) {
                    Image(painterResource(R.drawable.ic_logo_fg), contentDescription = null, modifier = Modifier.fillMaxSize().scale(1.7f))
                }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("KeyMapper Pro", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Teclado y mouse → toques en pantalla", color = Sub, fontSize = 13.sp)
                }
            }

            Section("Permisos") {
                PermRow(a11y, "Servicio de accesibilidad", "Inyecta los toques y lee tu teclado físico.", "Activar") {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                PermRow(ovl, "Mostrar sobre otras apps", "Dibuja y edita los botones sobre el juego.", "Conceder") {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }

            Section("Perfiles · toca uno para abrir el editor") {
                profiles.forEach { p ->
                    val shape = RoundedCornerShape(16.dp)
                    Surface(
                        shape = shape, color = Color(0xFF1C1C1F),
                        modifier = Modifier.fillMaxWidth()
                            .border(1.dp, if (p.name == sel) Orange else Color(0xFF2C2C2E), shape)
                            .clip(shape)
                            .clickable { openEditor(p.name) }
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                Text(if (p.pkg.isBlank()) "Manual" else p.pkg, color = Sub, fontSize = 12.sp)
                                Text((p.buttons.size + p.alt.size).toString() + " botones", color = Sub, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("✎ Editar", color = Orange, fontWeight = FontWeight.Bold)
                                Row {
                                    TextButton(onClick = { target = p; exp.launch(p.name + ".json") }) { Text("Exportar", color = Color(0xFFCFCFCF), fontSize = 12.sp) }
                                    TextButton(onClick = {
                                        if (profiles.size > 1) { Store.delete(this@MainActivity, p); profiles = Store.list(this@MainActivity) }
                                        else toast("Debe quedar al menos un perfil")
                                    }) { Text("Borrar", color = Red, fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { dlg = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text("Nuevo perfil") }
                    OutlinedButton(onClick = { imp.launch(arrayOf("*/*")) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text("Importar") }
                }
            }

            Section("Cómo usar") {
                Text("•  Toca un perfil: se abre el editor sobre tu juego. Con ＋ Añadir eliges el tipo de botón.", fontSize = 13.sp, color = Sub)
                Text("•  En el editor, toca un botón para ver su panel (puedes ocultarlo) y arrástralo para moverlo.", fontSize = 13.sp, color = Sub)
                Text("•  ▶ Jugar activa el mapeo; la burbuja flotante alterna Edición ↔ Juego. ✕ Salir lo detiene.", fontSize = 13.sp, color = Sub)
                Text("•  F8 pausa o reanuda. La tecla del botón Mira (F1) activa el mouse como cámara.", fontSize = 13.sp, color = Sub)
                Text("•  Si giras el teléfono, cada orientación guarda sus propios botones.", fontSize = 13.sp, color = Sub)
            }
        }

        if (dlg) AlertDialog(
            onDismissRequest = { dlg = false },
            containerColor = CardBg,
            title = { Text("Nuevo perfil") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(nName, { nName = it }, label = { Text("Nombre") }, singleLine = true)
                    OutlinedTextField(nPkg, { nPkg = it }, label = { Text("Paquete de la app (opcional)") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (nName.isNotBlank()) {
                        Store.save(this@MainActivity, Profile(nName.trim(), nPkg.trim()))
                        profiles = Store.list(this@MainActivity); dlg = false; nName = ""; nPkg = ""
                    }
                }) { Text("Crear", color = Orange, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { dlg = false }) { Text("Cancelar", color = Sub) } }
        )
    }
}
