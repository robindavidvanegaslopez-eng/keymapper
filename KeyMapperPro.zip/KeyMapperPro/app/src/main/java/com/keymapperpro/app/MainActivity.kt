package com.keymapperpro.app

import android.content.Context
import android.content.Intent
import android.hardware.input.InputManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Orange = Color(0xFFFF5A1F)
private val CardBg = Color(0xFF141416)
private val Sub = Color(0xFF9A9AA0)
private val Red = Color(0xFFE5484D)
private val Green = Color(0xFF3DDC84)
private val Chip = Color(0xFF1C1C1F)
private val Line = Color(0xFF2C2C2E)

private val PAGES = listOf("Inicio", "Dispositivos", "Perfiles", "Controles", "Mouse", "Teclado", "Avanzado", "Importar/Exportar")

private class DevInfo(val name: String, val kb: Boolean, val mouse: Boolean, val pad: Boolean, val vid: Int, val pid: Int)

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title.uppercase(), color = Sub, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Surface(shape = RoundedCornerShape(20.dp), color = CardBg, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
        }
    }
}

@Composable
private fun PermRow(ok: Boolean, title: String, desc: String, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(if (ok) Green else Red))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(desc, fontSize = 12.sp, color = Sub)
        }
        if (!ok) Button(
            onClick = onClick,
            colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)
        ) { Text(action, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun Note(t: String) { Text(t, fontSize = 13.sp, color = Sub) }

@Composable
private fun Outl(t: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text(t) }
}

@Composable
private fun Prim(t: String, onClick: () -> Unit) {
    Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) {
        Text(t, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SliderRow(label: String, value: Float, lo: Float, hi: Float, shown: String, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, Modifier.weight(1f), fontSize = 14.sp)
            Text(shown, color = Orange, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Slider(
            value = value.coerceIn(lo, hi), onValueChange = onChange, valueRange = lo..hi,
            onValueChangeFinished = onDone,
            colors = SliderDefaults.colors(thumbColor = Orange, activeTrackColor = Orange)
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp)
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = Orange)
        )
    }
}

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    private var lastKey by mutableStateOf("—")
    private var capTarget by mutableStateOf("")

    private val inputListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) { tick++ }
        override fun onInputDeviceRemoved(deviceId: Int) { tick++ }
        override fun onInputDeviceChanged(deviceId: Int) { tick++ }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.ensureDefault(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Orange, onPrimary = Color.Black,
                    background = Color.Black, surface = Color.Black,
                    onBackground = Color(0xFFF2F2F2), onSurface = Color(0xFFF2F2F2)
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Color.Black) { Home(tick) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++
        (getSystemService(Context.INPUT_SERVICE) as InputManager).registerInputDeviceListener(inputListener, null)
    }

    override fun onPause() {
        super.onPause()
        (getSystemService(Context.INPUT_SERVICE) as InputManager).unregisterInputDeviceListener(inputListener)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0 && e.keyCode != KeyEvent.KEYCODE_BACK) {
            val t = capTarget
            if (t.isNotEmpty()) {
                Cfg.setKey(this, t, e.keyCode)
                capTarget = ""
                tick++
                return true
            }
            val mods = ArrayList<String>()
            if (e.isCtrlPressed) mods.add("Ctrl")
            if (e.isShiftPressed) mods.add("Shift")
            if (e.isAltPressed) mods.add("Alt")
            if (e.isMetaPressed) mods.add("Meta")
            val isMod = e.keyCode in intArrayOf(
                KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT, KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT,
                KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT, KeyEvent.KEYCODE_META_LEFT, KeyEvent.KEYCODE_META_RIGHT
            )
            val name = KeyEvent.keyCodeToString(e.keyCode).removePrefix("KEYCODE_")
            lastKey = (if (mods.isEmpty() || isMod) "" else mods.joinToString("+") + "+") + name + "  (código " + e.keyCode + ")"
        }
        return super.dispatchKeyEvent(e)
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    /** Abre el editor del perfil directamente sobre la app/juego que estaba debajo. */
    private fun openEditor(name: String) {
        val s = MapperService.inst
        if (!a11yOn() || s == null) { toast("Activa primero el servicio de accesibilidad"); return }
        if (!Settings.canDrawOverlays(this)) { toast("Falta el permiso de superposición"); return }
        Store.select(this, name)
        s.stop(); s.start(true)
        moveTaskToBack(true)
    }

    /** Guarda un perfil editado desde la app y avisa al overlay si está en marcha. */
    private fun commit(p: Profile) {
        Store.save(this, p)
        MapperService.inst?.ui?.syncSens(p)
    }

    private fun devices(): List<DevInfo> {
        val out = ArrayList<DevInfo>()
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if (d.isVirtual) continue
            val src = d.sources
            val kb = (src and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD && d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC
            val ms = (src and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE ||
                (src and InputDevice.SOURCE_MOUSE_RELATIVE) == InputDevice.SOURCE_MOUSE_RELATIVE
            val pad = (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
            if (kb || ms || pad) out.add(DevInfo(d.name, kb, ms, pad, d.vendorId, d.productId))
        }
        return out
    }

    // =====================================================================  navegación
    @Composable
    private fun Home(t: Int) {
        var page by remember { mutableIntStateOf(0) }
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.padding(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0A0A0A))
                        .border(1.dp, Line, RoundedCornerShape(16.dp))
                ) {
                    Image(painterResource(R.drawable.ic_logo_fg), contentDescription = null, modifier = Modifier.fillMaxSize().scale(1.7f))
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("KeyMapper Pro", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Mapeador universal de teclado y mouse", color = Sub, fontSize = 12.sp)
                }
            }
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PAGES.forEachIndexed { i, title ->
                    val sh = RoundedCornerShape(20.dp)
                    Surface(
                        shape = sh, color = if (page == i) Orange else Chip,
                        modifier = Modifier.clip(sh).clickable { page = i }
                    ) {
                        Text(
                            title, color = if (page == i) Color.Black else Color.White, fontWeight = FontWeight.Bold,
                            fontSize = 14.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                        )
                    }
                }
            }
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                when (page) {
                    0 -> PageInicio(t)
                    1 -> PageDispositivos(t)
                    2 -> PagePerfiles(t)
                    3 -> PageControles(t)
                    4 -> PageMouse(t)
                    5 -> PageTeclado(t)
                    6 -> PageAvanzado(t)
                    else -> PageImportExport(t)
                }
            }
        }
    }

    // =====================================================================  1. Inicio
    @Composable
    private fun PageInicio(t: Int) {
        val act = this@MainActivity
        val a11y = a11yOn()
        val ovl = Settings.canDrawOverlays(act)
        val cur = remember(t) { Store.current(act) }
        Section("Permisos") {
            PermRow(a11y, "Servicio de accesibilidad", "Inyecta los toques y lee tu teclado físico.", "Activar") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            PermRow(ovl, "Mostrar sobre otras apps", "Dibuja y edita los botones sobre el juego.", "Conceder") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        Section("Estado") {
            Text("Perfil activo: " + (cur?.name ?: "—"), fontWeight = FontWeight.Bold)
            Text(
                if (a11y && ovl) "Todo listo. Abre el editor y pulsa ▶ Jugar." else "Concede los permisos de arriba para empezar.",
                color = Sub, fontSize = 13.sp
            )
            Prim("Abrir editor del perfil activo") { cur?.let { act.openEditor(it.name) } }
        }
        Section("Cómo usar") {
            Note("•  Perfiles → toca uno para abrir el editor sobre tu juego. Con ＋ Añadir eliges el tipo de botón.")
            Note("•  En el editor, toca un botón para ver su panel: teclas, combinaciones, disparador, prioridad y más.")
            Note("•  ▶ Jugar activa el mapeo; la burbuja flotante alterna Edición ↔ Juego. ✕ Salir lo detiene.")
            Note("•  Teclas globales (cámbialas en Teclado): " +
                keyName(Cfg.key(act, "pause")) + " pausa · " + keyName(Cfg.key(act, "sens")) + " cambia sensibilidad · " +
                keyName(Cfg.key(act, "prof")) + " cambia de perfil.")
            Note("•  Cada orientación de pantalla guarda sus propios botones.")
        }
    }

    // =====================================================================  2. Dispositivos
    @Composable
    private fun PageDispositivos(t: Int) {
        val devs = remember(t) { devices() }
        Section("Dispositivos conectados") {
            if (devs.isEmpty()) Note("No hay teclado, mouse ni gamepad físicos conectados. Conéctalos por USB (OTG) o Bluetooth y aparecerán aquí al instante.")
            devs.forEach { d ->
                Column {
                    Text(d.name, fontWeight = FontWeight.Bold)
                    val tipos = ArrayList<String>()
                    if (d.kb) tipos.add("Teclado")
                    if (d.mouse) tipos.add("Mouse")
                    if (d.pad) tipos.add("Gamepad")
                    Text(tipos.joinToString(" · ") + "   ·   ID " + d.vid + ":" + d.pid, color = Sub, fontSize = 12.sp)
                }
            }
        }
        Section("Compatibilidad real") {
            Note("•  USB (con adaptador OTG) y Bluetooth se comportan igual: Android los entrega como dispositivos de entrada normales. La app no puede distinguir el tipo de conexión.")
            Note("•  Funciona sin root: usa el servicio de accesibilidad (teclas y toques) y la captura de puntero de Android 8+ (mouse).")
            Note("•  Los botones del mouse y la rueda solo llegan mientras el cursor está capturado (botón Mira activo).")
            Note("•  Algunos teclados Bluetooth baratos no envían ciertas combinaciones (ghosting): es limitación del hardware.")
        }
    }

    // =====================================================================  3. Perfiles
    @Composable
    private fun PagePerfiles(t: Int) {
        val act = this@MainActivity
        var profiles by remember(t) { mutableStateOf(Store.list(act)) }
        val sel = remember(t) { Store.current(act)?.name ?: "" }
        var dlgNew by remember { mutableStateOf(false) }
        var nName by remember { mutableStateOf("") }
        var renaming by remember { mutableStateOf<Profile?>(null) }
        var rName by remember { mutableStateOf("") }
        var pkgFor by remember { mutableStateOf<Profile?>(null) }

        Section("Perfiles · toca uno para abrir el editor") {
            profiles.forEach { p ->
                val shape = RoundedCornerShape(16.dp)
                Surface(
                    shape = shape, color = Chip,
                    modifier = Modifier.fillMaxWidth()
                        .border(1.dp, if (p.name == sel) Orange else Line, shape)
                        .clip(shape)
                        .clickable { act.openEditor(p.name) }
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                Text(if (p.pkg.isBlank()) "Manual (sin juego asignado)" else "Juego: " + p.pkg, color = Sub, fontSize = 12.sp)
                                Text((p.buttons.size + p.alt.size).toString() + " botones · " + p.sens.size + " sensibilidades", color = Sub, fontSize = 12.sp)
                            }
                            Text("✎ Editar", color = Orange, fontWeight = FontWeight.Bold)
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState())) {
                            TextButton(onClick = {
                                Store.select(act, p.name)
                                val ov = MapperService.inst?.ui
                                if (ov != null && !ov.editing) ov.loadProfile(p)
                                tick++
                            }) { Text("Usar", color = Green, fontSize = 12.sp) }
                            TextButton(onClick = { pkgFor = p }) { Text("Juego", color = Color(0xFFCFCFCF), fontSize = 12.sp) }
                            TextButton(onClick = { rName = p.name; renaming = p }) { Text("Renombrar", color = Color(0xFFCFCFCF), fontSize = 12.sp) }
                            TextButton(onClick = { Store.duplicate(act, p); profiles = Store.list(act) }) { Text("Duplicar", color = Color(0xFFCFCFCF), fontSize = 12.sp) }
                            TextButton(onClick = {
                                if (profiles.size > 1) { Store.delete(act, p); profiles = Store.list(act); tick++ }
                                else toast("Debe quedar al menos un perfil")
                            }) { Text("Borrar", color = Red, fontSize = 12.sp) }
                        }
                    }
                }
            }
            Outl("＋ Nuevo perfil") { dlgNew = true }
            Note("Asigna un juego a cada perfil con «Juego»: se cargará solo al abrir esa app. Perfiles ilimitados; con la tecla de cambio de perfil (Teclado) saltas entre ellos jugando.")
        }

        if (dlgNew) AlertDialog(
            onDismissRequest = { dlgNew = false },
            containerColor = CardBg,
            title = { Text("Nuevo perfil") },
            text = { OutlinedTextField(nName, { nName = it }, label = { Text("Nombre") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    if (nName.isNotBlank()) {
                        Store.save(act, Profile(nName.trim()))
                        profiles = Store.list(act); dlgNew = false; nName = ""
                    }
                }) { Text("Crear", color = Orange, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { dlgNew = false }) { Text("Cancelar", color = Sub) } }
        )

        renaming?.let { target ->
            AlertDialog(
                onDismissRequest = { renaming = null },
                containerColor = CardBg,
                title = { Text("Renombrar perfil") },
                text = { OutlinedTextField(rName, { rName = it }, label = { Text("Nombre") }, singleLine = true) },
                confirmButton = {
                    TextButton(onClick = {
                        if (Store.rename(act, target, rName)) { profiles = Store.list(act); renaming = null; tick++ }
                        else toast("Nombre vacío o ya existe")
                    }) { Text("Guardar", color = Orange, fontWeight = FontWeight.Bold) }
                },
                dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancelar", color = Sub) } }
            )
        }

        pkgFor?.let { target ->
            val pm = packageManager
            val apps = remember {
                pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                    .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                    .filter { it.second != packageName }
                    .sortedBy { it.first.lowercase() }
            }
            AlertDialog(
                onDismissRequest = { pkgFor = null },
                containerColor = CardBg,
                title = { Text("Juego de «" + target.name + "»") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Sin juego (manual)", color = Orange, fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth().clickable { target.pkg = ""; Store.save(act, target); profiles = Store.list(act); pkgFor = null }.padding(vertical = 10.dp))
                        apps.forEach { (label, pkg) ->
                            Column(Modifier.fillMaxWidth().clickable { target.pkg = pkg; Store.save(act, target); profiles = Store.list(act); pkgFor = null }.padding(vertical = 8.dp)) {
                                Text(label, fontWeight = FontWeight.Bold)
                                Text(pkg, color = Sub, fontSize = 11.sp)
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { pkgFor = null }) { Text("Cerrar", color = Sub) } }
            )
        }
    }

    // =====================================================================  4. Editor de controles
    @Composable
    private fun PageControles(t: Int) {
        val act = this@MainActivity
        val cur = remember(t) { Store.current(act) }
        Section("Editor visual") {
            Note("Se abre como capa sobre tu juego: arrastra botones, cambia tamaño, forma, opacidad y posición (flechas de 1 px y deslizadores X/Y), crea zonas de mira, duplica, bloquea y borra.")
            Prim("Abrir editor de «" + (cur?.name ?: "—") + "»") { cur?.let { act.openEditor(it.name) } }
        }
        Section("Controles del perfil activo") {
            val all = (cur?.buttons ?: mutableListOf())
            if (all.isEmpty()) Note("Este perfil aún no tiene botones en la orientación actual.")
            all.forEach { b ->
                val trig = arrayOf("al presionar", "mantenida", "doble", "al soltar", "secuencia")[b.trigger.coerceIn(0, 4)]
                Column {
                    Text(b.type.label + " · " + (if (b.trigger == 4) b.seq.joinToString("→") { keyName(it) } else fullKey(b)) +
                        (if (b.extra.isNotEmpty()) "  (+" + b.extra.size + " teclas)" else ""), fontWeight = FontWeight.Bold)
                    Text(trig + " · prioridad " + b.priority + (if (b.exclusive) " · exclusiva" else "") + (if (!b.enabled) " · DESACTIVADA" else ""), color = Sub, fontSize = 12.sp)
                }
            }
        }
        Section("Qué se puede configurar por botón") {
            Note("Tipo de entrada · tecla/botón del mouse (clic, atrás, adelante, rueda) · modificadores Ctrl/Shift/Alt/Meta · teclas adicionales · disparador (presionar, mantenida, doble, soltar, secuencia) · posición y tamaño · duración del toque · retardo · repetición · prioridad y exclusividad · activar/desactivar · condición (con/sin cámara).")
        }
    }

    // =====================================================================  5. Mouse
    @Composable
    private fun PageMouse(t: Int) {
        val act = this@MainActivity
        val p = remember(t) { Store.current(act) }
        var rev by remember { mutableIntStateOf(0) }
        var dlg by remember { mutableStateOf(false) }
        var nName by remember { mutableStateOf("") }
        if (p == null) { Note("No hay perfil."); return }
        val unused = rev
        val s = p.curSens()
        Section("Sensibilidad · perfil «" + p.name + "»") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                p.sens.forEachIndexed { i, ss ->
                    val sh = RoundedCornerShape(16.dp)
                    Surface(
                        shape = sh, color = if (i == p.sensSel) Orange else Chip,
                        modifier = Modifier.clip(sh).clickable { p.sensSel = i; act.commit(p); rev++ }
                    ) {
                        Text(ss.name, color = if (i == p.sensSel) Color.Black else Color.White, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Outl("＋ Nuevo") { nName = ""; dlg = true }
                Outl("Eliminar") {
                    if (p.sens.size > 1) { p.sens.removeAt(p.sensSel); p.sensSel = 0; act.commit(p); rev++ } else act.toast("Debe quedar un conjunto")
                }
            }
            Note("Cambia de conjunto jugando con " + keyName(Cfg.key(act, "sens")) + ".")
        }
        Section("Ajustes del conjunto «" + s.name + "»") {
            SliderRow("Sensibilidad horizontal", s.sx, 0.1f, 5f, "%.2f".format(s.sx), { s.sx = it; rev++ }) { act.commit(p) }
            SliderRow("Sensibilidad vertical", s.sy, 0.1f, 5f, "%.2f".format(s.sy), { s.sy = it; rev++ }) { act.commit(p) }
            SliderRow("Aceleración", s.accel, 0f, 3f, "%.2f".format(s.accel), { s.accel = it; rev++ }) { act.commit(p) }
            SliderRow("Suavizado", s.smooth, 0f, 0.9f, "%.2f".format(s.smooth), { s.smooth = it; rev++ }) { act.commit(p) }
            SliderRow("DPI", s.dpi.toFloat(), 200f, 3200f, s.dpi.toString(), { s.dpi = (it / 100f).toInt() * 100; rev++ }) { act.commit(p) }
            SwitchRow("Invertir eje horizontal", s.invX) { s.invX = it; act.commit(p); rev++ }
            SwitchRow("Invertir eje vertical", s.invY) { s.invY = it; act.commit(p); rev++ }
        }
        Section("Captura del cursor") {
            Note("•  Crea un botón «Mira» en el editor: su tecla (F1 por defecto) captura el cursor y mueve la cámara dentro de su zona; pulsarla otra vez lo libera. Pausar el mapeo también lo libera.")
            Note("•  Cada botón Mira tiene además su propia sensibilidad H/V; se multiplica por la del conjunto.")
            Note("•  El DPI es relativo (800 = sin cambio): Android no deja cambiar el DPI real del mouse, así que se emula escalando el movimiento.")
        }

        if (dlg) AlertDialog(
            onDismissRequest = { dlg = false },
            containerColor = CardBg,
            title = { Text("Nuevo conjunto (copia del actual)") },
            text = { OutlinedTextField(nName, { nName = it }, label = { Text("Nombre") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    if (nName.isNotBlank()) {
                        p.sens.add(s.copy(name = nName.trim()))
                        p.sensSel = p.sens.size - 1
                        act.commit(p); dlg = false; rev++
                    }
                }) { Text("Crear", color = Orange, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { dlg = false }) { Text("Cancelar", color = Sub) } }
        )
    }

    // =====================================================================  6. Teclado
    @Composable
    private fun PageTeclado(t: Int) {
        val act = this@MainActivity
        val cap = capTarget
        Section("Probador de teclas") {
            Note("Pulsa cualquier tecla o combinación con un teclado físico para ver cómo la reconoce Android.")
            Text(lastKey, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Orange)
        }
        Section("Teclas globales") {
            @Composable
            fun GRow(label: String, name: String) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(label, fontSize = 14.sp)
                        Text(if (cap == name) "Pulsa una tecla…" else keyName(Cfg.key(act, name)), color = Orange, fontWeight = FontWeight.Bold)
                    }
                    Outl("Cambiar") { capTarget = name }
                }
            }
            GRow("Pausar / reanudar el mapeo", "pause")
            GRow("Cambiar conjunto de sensibilidad", "sens")
            GRow("Cambiar al siguiente perfil", "prof")
            Note("Estas teclas las atiende la app y no llegan al juego.")
        }
        Section("Cómo funcionan las asignaciones") {
            Note("•  Combinaciones: elige Ctrl/Shift/Alt/Meta en el botón. Si hay «A» y «Ctrl+A», al pulsar Ctrl+A solo responde la más específica.")
            Note("•  Varias teclas → una acción: «Teclas adicionales».")
            Note("•  Varias acciones → una tecla: se ejecutan por orden de prioridad; con «Exclusiva» la de mayor prioridad bloquea a las demás.")
            Note("•  Disparadores: al presionar, mantenida, doble pulsación, al soltar y secuencia de teclas.")
            Note("•  El joystick usa teclas sueltas y no depende de los modificadores.")
        }
    }

    // =====================================================================  7. Ajustes avanzados
    @Composable
    private fun PageAvanzado(t: Int) {
        val act = this@MainActivity
        var tk by remember(t) { mutableIntStateOf(Cfg.tick(act).toInt()) }
        var idle by remember(t) { mutableIntStateOf(Cfg.idleMs(act).toInt()) }
        Section("Motor de toques") {
            SliderRow("Intervalo de envío de gestos", tk.toFloat(), 10f, 60f, "$tk ms", { tk = it.toInt() }) {
                Cfg.setTick(act, tk); MapperService.inst?.mapper?.eng?.tickMs = tk.toLong()
            }
            Note("Menos ms = respuesta más fina pero más carga. 25 ms es un buen punto de partida.")
            SliderRow("Soltar la mira tras inactividad", idle.toFloat(), 100f, 1000f, "$idle ms", { idle = (it / 10f).toInt() * 10 }) {
                Cfg.setIdle(act, idle)
            }
            Outl("Restablecer ajustes") { Cfg.reset(act); tick++ }
        }
        Section("Capacidades reales y limitaciones de Android") {
            Note("✔  Teclado físico: servicio de accesibilidad con filtro de teclas. Sin root.")
            Note("✔  Toques, deslizamientos y joystick: gestos continuos multitouch (hasta 9 dedos) enviados cada pocos ms.")
            Note("✔  Mouse: captura de puntero (Android 8+). Da movimiento relativo, 5 botones y rueda.")
            Note("✘  Con el cursor sin capturar, Android no entrega los botones del mouse a la app.")
            Note("✘  Los gestos tienen algo de latencia y no son idénticos a un dedo real; juegos con protección anti-trampas pueden ignorarlos.")
            Note("✘  Android no permite cambiar el DPI real del mouse ni leer qué tipo de conexión usa (USB/BT).")
            Note("✘  Un teclado puede no enviar ciertas combinaciones simultáneas por límites del hardware.")
            Note("✘  La detección automática del joystick por captura de pantalla requiere Android 11+.")
        }
    }

    // =====================================================================  8. Importar / Exportar
    @Composable
    private fun PageImportExport(t: Int) {
        val act = this@MainActivity
        val cur = remember(t) { Store.current(act) }
        val expOne = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null && cur != null) act.contentResolver.openOutputStream(uri)?.use { it.write(Store.toJson(cur).toByteArray()) }
        }
        val expAll = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) act.contentResolver.openOutputStream(uri)?.use { it.write(Store.toJsonAll(act).toByteArray()) }
        }
        val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                val s = act.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                val n = if (s == null) 0 else Store.importAny(act, s)
                act.toast(if (n > 0) "Importados: $n" else "Archivo no válido")
                act.tick++
            }
        }
        Section("Exportar") {
            Note("Cada archivo contiene botones, teclas, posiciones y sensibilidades.")
            Outl("Exportar perfil activo («" + (cur?.name ?: "—") + "»)") { cur?.let { expOne.launch(it.name + ".json") } }
            Outl("Exportar todos los perfiles") { expAll.launch("KeyMapperPro-copia.json") }
        }
        Section("Importar") {
            Note("Acepta un perfil o una copia completa. Si el nombre ya existe, se añade como «nombre (2)».")
            Outl("Importar archivo .json") { imp.launch(arrayOf("*/*")) }
        }
    }
}
