package com.keymapperpro

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/**
 * Engranaje flotante (esquina superior derecha) que se muestra mientras juegas.
 * Al tocarlo con el dedo se despliega un menú: Editar controles, capturar/liberar mouse, detener.
 */
class MenuView(ctx: Context, private val items: List<Pair<String, () -> Unit>>) : View(ctx) {
    private var open = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density
    private val gear = 40f * d
    private val itemH = 44f * d
    private val menuW = 220f * d
    private val red = 0xFFE53935.toInt()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (open) {
            setMeasuredDimension(menuW.toInt(), (gear + itemH * items.size).toInt())
        } else {
            setMeasuredDimension(gear.toInt(), gear.toInt())
        }
    }

    override fun onDraw(c: Canvas) {
        val gx = width - gear / 2f
        val gy = gear / 2f
        val r = gear / 2f - 2f * d
        paint.style = Paint.Style.FILL
        paint.color = 0xCC000000.toInt()
        c.drawCircle(gx, gy, r, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f * d
        paint.color = red
        c.drawCircle(gx, gy, r, paint)
        paint.color = 0xFFFFFFFF.toInt()
        c.drawCircle(gx, gy, r * 0.38f, paint)
        for (i in 0 until 8) {
            val a = i * Math.PI / 4
            c.drawLine(
                gx + (r * 0.55f * cos(a)).toFloat(), gy + (r * 0.55f * sin(a)).toFloat(),
                gx + (r * 0.8f * cos(a)).toFloat(), gy + (r * 0.8f * sin(a)).toFloat(), paint
            )
        }
        if (open) {
            for ((i, item) in items.withIndex()) {
                val top = gear + i * itemH
                val rect = RectF(2f * d, top + 2f * d, width - 2f * d, top + itemH - 2f * d)
                paint.style = Paint.Style.FILL
                paint.color = 0xE6121212.toInt()
                c.drawRoundRect(rect, 8f * d, 8f * d, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1.5f * d
                paint.color = red
                c.drawRoundRect(rect, 8f * d, 8f * d, paint)
                paint.style = Paint.Style.FILL
                paint.color = 0xFFFFFFFF.toInt()
                paint.textSize = 14f * d
                paint.textAlign = Paint.Align.LEFT
                c.drawText(item.first, 14f * d, top + itemH / 2f + 5f * d, paint)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked != MotionEvent.ACTION_UP) return true
        if (!open) {
            open = true
        } else if (e.y < gear) {
            open = false
        } else {
            val i = ((e.y - gear) / itemH).toInt()
            open = false
            if (i in items.indices) items[i].second()
        }
        requestLayout()
        invalidate()
        return true
    }
}
