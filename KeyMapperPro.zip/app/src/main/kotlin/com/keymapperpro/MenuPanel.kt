package com.keymapperpro

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Menú del juego. No hay icono flotante: se abre con la tecla o combinación que el usuario
 * eligió en la app (por defecto F2) y se cierra tocando fuera o con la misma tecla.
 */
class MenuPanel(
    ctx: Context,
    private val title: String,
    private val items: List<Pair<String, () -> Unit>>,
    private val onClose: () -> Unit
) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val titleH = 46f * d
    private val itemH = 46f * d
    private val panelW = 270f * d

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(panelW.toInt(), (titleH + itemH * items.size + 10f * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val accent = AppSettings.accent
        paint.style = Paint.Style.FILL
        paint.color = 0xF0121212.toInt()
        val bg = RectF(0f, 0f, width.toFloat(), height.toFloat())
        c.drawRoundRect(bg, 16f * d, 16f * d, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f * d
        paint.color = accent
        c.drawRoundRect(bg, 16f * d, 16f * d, paint)

        paint.style = Paint.Style.FILL
        paint.color = 0xFFFFFFFF.toInt()
        paint.textSize = 16f * d
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.LEFT
        c.drawText(title, 16f * d, titleH * 0.65f, paint)
        paint.isFakeBoldText = false

        for ((i, item) in items.withIndex()) {
            val top = titleH + i * itemH
            val r = RectF(8f * d, top + 3f * d, width - 8f * d, top + itemH - 3f * d)
            paint.style = Paint.Style.FILL
            paint.color = 0xFF222222.toInt()
            c.drawRoundRect(r, 10f * d, 10f * d, paint)
            paint.color = 0xFFFFFFFF.toInt()
            paint.textSize = 14.5f * d
            c.drawText(item.first, 18f * d, top + itemH / 2f + 5f * d, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) {
            onClose()
            return true
        }
        if (e.actionMasked != MotionEvent.ACTION_UP) return true
        val i = ((e.y - titleH) / itemH).toInt()
        if (e.y >= titleH && i in items.indices) items[i].second()
        return true
    }
}
