package com.keymapperpro

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject

private val Accent = Color(0xFFE53935)
private val CardBg = Color(0xFF151515)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ShizukuManager.init(this)
        setContent { AppTheme { Root() } }
    }

    override fun onResume() {
        super.onResume()
        ShizukuManager.refresh()
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color.White,
            background = Color.Black,
            onBackground = Color.White,
            surface = Color.Black,
            onSurface = Color.White,
            surfaceVariant = CardBg
        ),
        content = content
    )
}

fun appLabel(ctx: Context, pkg: String): String = try {
    val pm = ctx.packageManager
    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
} catch (e: Exception) {
    pkg
}

/** Devuelve un mensaje de error, o null si todo salió bien. */
fun startGame(ctx: Context, pkg: String, edit: Boolean): String? {
    if (ShizukuManager.service == null) return "Shizuku no está conectado. Abre Configuración."
    if (!Settings.canDrawOverlays(ctx)) return "Falta el permiso de superposición (Configuración)."
    val launch = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return "No se puede abrir el juego."
    val i = Intent(ctx, MapperService::class.java)
        .setAction(if (edit) MapperService.ACTION_EDIT else MapperService.ACTION_PLAY)
        .putExtra(MapperService.EXTRA_PKG, pkg)
    ctx.startForegroundService(i)
    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    ctx.startActivity(launch)
    return null
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf("home") }
    var pkg by remember { mutableStateOf("") }
    var library by remember { mutableStateOf(ProfileStore.library(ctx)) }

    LaunchedEffect(Unit) {
        while (true) {
            ShizukuManager.refresh()
            delay(1500)
        }
    }
    BackHandler(enabled = screen != "home") { screen = "home" }

    Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
        when (screen) {
            "home" -> HomeScreen(
                library = library,
                onOpen = { pkg = it; screen = "game" },
                onAdd = { screen = "add" },
                onSetup = { screen = "setup" }
            )
            "add" -> AddGameScreen(
                onPick = {
                    ProfileStore.addGame(ctx, it)
                    library = ProfileStore.library(ctx)
                    screen = "home"
                },
                onBack = { screen = "home" }
            )
            "game" -> GameScreen(
                pkg = pkg,
                onBack = { screen = "home" },
                onRemoved = {
                    library = ProfileStore.library(ctx)
                    screen = "home"
                }
            )
            "setup" -> SetupScreen(onBack = { screen = "home" })
        }
    }
}

@Composable
fun StatusLine(ok: Boolean, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
        Text("●", color = if (ok) Color(0xFF43A047) else Accent)
        Spacer(Modifier.width(8.dp))
        Text(text)
    }
}

@Composable
fun AppIcon(pkg: String) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }
    if (bmp != null) Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(44.dp))
}

@Composable
fun HomeScreen(
    library: List<String>,
    onOpen: (String) -> Unit,
    onAdd: () -> Unit,
    onSetup: () -> Unit
) {
    val ctx = LocalContext.current
    val overlayOk by produceState(false) {
        while (true) {
            value = Settings.canDrawOverlays(ctx)
            delay(1000)
        }
    }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("KEYMAPPER PRO", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Accent)
        Text("Teclado y mouse para tus juegos", color = Color.Gray)
        Spacer(Modifier.height(12.dp))

        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("Estado", fontWeight = FontWeight.Bold)
                StatusLine(ShizukuManager.binderAlive, "Shizuku en ejecución")
                StatusLine(ShizukuManager.permitted, "Permiso de Shizuku concedido")
                StatusLine(ShizukuManager.connected, "Inyector de toques conectado")
                StatusLine(overlayOk, "Permiso de superposición")
                Spacer(Modifier.height(8.dp))
                Button(onClick = onSetup) { Text("Configuración / Asistente") }
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Biblioteca de juegos", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(onClick = onAdd) { Text("+ Añadir juego") }
        }
        Spacer(Modifier.height(8.dp))
        if (library.isEmpty()) {
            Text("Aún no hay juegos. Pulsa «Añadir juego».", color = Color.Gray)
        }
        library.forEach { p ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable { onOpen(p) }
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(p)
                    Spacer(Modifier.width(12.dp))
                    Text(appLabel(ctx, p), fontSize = 18.sp)
                }
            }
        }
    }
}

@Composable
fun AddGameScreen(onPick: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val apps by produceState<List<Pair<String, String>>>(emptyList()) {
        value = withContext(Dispatchers.Default) {
            val pm = ctx.packageManager
            pm.getInstalledApplications(0)
                .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != ctx.packageName }
                .map { it.packageName to pm.getApplicationLabel(it).toString() }
                .sortedBy { it.second.lowercase() }
        }
    }
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Text("←") }
            Spacer(Modifier.width(12.dp))
            Text("Añadir juego", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            label = { Text("Buscar") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(apps.filter { it.second.contains(q, ignoreCase = true) }) { (pkg, label) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onPick(pkg) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppIcon(pkg)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(label, fontSize = 17.sp)
                        Text(pkg, fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun GameScreen(pkg: String, onBack: () -> Unit, onRemoved: () -> Unit) {
    val ctx = LocalContext.current
    val profile = remember(pkg) { ProfileStore.load(ctx, pkg) }
    var sx by remember(pkg) { mutableFloatStateOf(profile.sensX) }
    var sy by remember(pkg) { mutableFloatStateOf(profile.sensY) }
    var invert by remember(pkg) { mutableStateOf(profile.invertY) }
    var auto by remember(pkg) { mutableStateOf(profile.autoCapture) }
    var direct by remember(pkg) { mutableStateOf(profile.joyDirect) }
    var toggle by remember(pkg) { mutableStateOf(profile.toggleKey) }
    var accel by remember(pkg) { mutableFloatStateOf(profile.accel) }
    var smooth by remember(pkg) { mutableFloatStateOf(profile.smooth) }
    var ads by remember(pkg) { mutableFloatStateOf(profile.adsMult) }

    fun commit() {
        profile.sensX = sx
        profile.sensY = sy
        profile.invertY = invert
        profile.autoCapture = auto
        profile.joyDirect = direct
        profile.toggleKey = toggle
        profile.accel = accel
        profile.smooth = smooth
        profile.adsMult = ads
        ProfileStore.save(ctx, profile)
    }

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_LONG).show()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Text("←") }
            Spacer(Modifier.width(12.dp))
            AppIcon(pkg)
            Spacer(Modifier.width(10.dp))
            Text(appLabel(ctx, pkg), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                commit()
                startGame(ctx, pkg, false)?.let { toast(it) }
            },
            modifier = Modifier.fillMaxWidth().height(64.dp)
        ) { Text("▶  JUGAR", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = {
                commit()
                startGame(ctx, pkg, true)?.let { toast(it) }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("✎  EDITAR CONTROLES (sobre el juego)") }

        Spacer(Modifier.height(20.dp))
        Text("Cámara / mira", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("Sensibilidad X: ${"%.1f".format(sx)}")
        Slider(value = sx, onValueChange = { sx = it }, onValueChangeFinished = { commit() }, valueRange = 0.2f..8f)
        Text("Sensibilidad Y: ${"%.1f".format(sy)}")
        Slider(value = sy, onValueChange = { sy = it }, onValueChangeFinished = { commit() }, valueRange = 0.2f..8f)
        Text("Aceleración del mouse: ${"%.2f".format(accel)}")
        Slider(value = accel, onValueChange = { accel = it }, onValueChangeFinished = { commit() }, valueRange = 0f..1f)
        Text("Suavizado: ${"%.2f".format(smooth)}")
        Slider(value = smooth, onValueChange = { smooth = it }, onValueChangeFinished = { commit() }, valueRange = 0f..0.9f)
        Text("Sensibilidad al apuntar (mantener clic derecho): x${"%.2f".format(ads)}")
        Slider(value = ads, onValueChange = { ads = it }, onValueChangeFinished = { commit() }, valueRange = 0.1f..1.5f)
        SettingSwitch("Invertir eje Y", invert) { invert = it; commit() }
        SettingSwitch("Capturar el mouse al entrar al juego", auto) { auto = it; commit() }
        SettingSwitch("Joystick directo (dedo en la dirección, sin deslizar)", direct) { direct = it; commit() }
        Text(
            "Si el joystick de tu juego es flotante y no responde, apaga «Joystick directo».",
            fontSize = 12.sp, color = Color.Gray
        )

        Spacer(Modifier.height(12.dp))
        Text("Tecla para capturar / liberar el mouse", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("F1" to 131, "F2" to 132, "F4" to 134, "Bloq Mayús" to 115).forEach { (n, code) ->
                if (toggle == code) {
                    Button(onClick = { }) { Text(n) }
                } else {
                    OutlinedButton(onClick = { toggle = code; commit() }) { Text(n) }
                }
            }
        }
        Text("ESC también libera el mouse.", fontSize = 12.sp, color = Color.Gray)

        Spacer(Modifier.height(20.dp))
        Text("Perfil", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                commit()
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("perfil", profile.toJson().toString()))
                toast("Perfil copiado al portapapeles")
            }) { Text("Exportar") }
            OutlinedButton(onClick = {
                try {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val txt = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                    val imp = Profile.fromJson(JSONObject(txt))
                    imp.pkg = pkg
                    ProfileStore.save(ctx, imp)
                    toast("Perfil importado")
                    onBack()
                } catch (e: Exception) {
                    toast("El portapapeles no tiene un perfil válido")
                }
            }) { Text("Importar") }
            OutlinedButton(onClick = {
                ProfileStore.save(ctx, ProfileStore.defaultProfile(pkg))
                toast("Preset restaurado")
                onBack()
            }) { Text("Restaurar preset") }
        }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = {
            ProfileStore.removeGame(ctx, pkg)
            onRemoved()
        }) { Text("Quitar de la biblioteca") }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun SetupScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val overlayOk by produceState(false) {
        while (true) {
            value = Settings.canDrawOverlays(ctx)
            delay(1000)
        }
    }
    fun open(url: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
        }
    }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Text("←") }
            Spacer(Modifier.width(12.dp))
            Text("Configuración", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        StatusLine(ShizukuManager.binderAlive, "1. Shizuku en ejecución")
        StatusLine(ShizukuManager.permitted, "2. Permiso de Shizuku concedido")
        StatusLine(ShizukuManager.connected, "3. Inyector de toques conectado")
        StatusLine(overlayOk, "4. Permiso de superposición (se concede solo al conectar)")

        Spacer(Modifier.height(16.dp))
        Text("Paso 1 · Instalar Shizuku", fontWeight = FontWeight.Bold)
        Text("Android no deja que una app normal toque otras apps. Shizuku da ese permiso sin root.", color = Color.Gray)
        OutlinedButton(onClick = { open("https://shizuku.rikka.app/download/") }) { Text("Descargar Shizuku") }

        Spacer(Modifier.height(12.dp))
        Text("Paso 2 · Iniciar por depuración inalámbrica (sin PC)", fontWeight = FontWeight.Bold)
        Text(
            "Activa Opciones de desarrollador → Depuración inalámbrica. En Shizuku elige " +
                "«Depuración inalámbrica», empareja con el código y pulsa Iniciar.",
            color = Color.Gray
        )
        OutlinedButton(onClick = {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
            }
        }) { Text("Abrir opciones de desarrollador") }

        Spacer(Modifier.height(12.dp))
        Text("Alternativa · por USB con PC", fontWeight = FontWeight.Bold)
        Text(
            "adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh",
            color = Color.Gray, fontSize = 12.sp
        )

        Spacer(Modifier.height(12.dp))
        Text("Paso 3 · Dar permiso a KeyMapper Pro", fontWeight = FontWeight.Bold)
        Button(onClick = { ShizukuManager.requestPermission() }) { Text("Conceder permiso de Shizuku") }

        Spacer(Modifier.height(12.dp))
        Text("Superposición manual (solo si no se concedió sola)", fontWeight = FontWeight.Bold)
        OutlinedButton(onClick = {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
            }
        }) { Text("Permiso de superposición") }
        Spacer(Modifier.height(24.dp))
    }
}
