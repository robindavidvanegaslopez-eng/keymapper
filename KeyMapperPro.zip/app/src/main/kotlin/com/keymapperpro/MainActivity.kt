package com.keymapperpro

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.nativeKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject

object AppState {
    var resumes by mutableIntStateOf(0)
}

fun accentC(): Color = Color(AppSettings.accent)
fun bgC(): Color = Color(AppSettings.background)
fun cardC(): Color = lerp(bgC(), Color.White, 0.08f)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppSettings.load(this)
        Licensing.load(this)
        ShizukuManager.init(this)
        setContent { AppTheme { Root() } }
    }

    override fun onResume() {
        super.onResume()
        AppState.resumes++
        Licensing.load(this)
        ShizukuManager.refresh()
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accentC(),
            onPrimary = Color.White,
            secondary = accentC(),
            background = bgC(),
            onBackground = Color.White,
            surface = bgC(),
            onSurface = Color.White,
            surfaceVariant = cardC()
        ),
        content = content
    )
}

fun appLabel(ctx: Context, pkg: String): String = try {
    val pm = ctx.packageManager
    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
} catch (e: Exception) {
    pkg
}

fun toast(ctx: Context, m: String) = Toast.makeText(ctx, m, Toast.LENGTH_LONG).show()

/** Devuelve un mensaje de error, o null si todo salió bien. */
fun startGame(ctx: Context, pkg: String): String? {
    if (ShizukuManager.service == null) return "Shizuku no está conectado. Abre Ajustes → Asistente."
    if (!Settings.canDrawOverlays(ctx)) return "Falta el permiso de superposición (Asistente de configuración)."
    val launch = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return "No se puede abrir el juego."
    val i = Intent(ctx, MapperService::class.java)
        .setAction(MapperService.ACTION_PLAY)
        .putExtra(MapperService.EXTRA_PKG, pkg)
    ctx.startForegroundService(i)
    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    ctx.startActivity(launch)
    return null
}

/** Jugar: si no hay tiempo de mapeo ni código sin anuncios, primero se muestra el anuncio simulado. */
fun tryPlay(ctx: Context, pkg: String, onNeedAd: () -> Unit) {
    if (AdGate.remainingMs(ctx) <= 0L) {
        onNeedAd()
        return
    }
    startGame(ctx, pkg)?.let { toast(ctx, it) }
}

// ------------------------------------------------------------------ raíz
@Composable
fun Root() {
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(1800)
        splash = false
    }
    Crossfade(targetState = splash, label = "splash") { s ->
        if (s) SplashScreen() else MainShell()
    }
}

@Composable
fun SplashScreen() {
    Box(Modifier.fillMaxSize().background(bgC()), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.ic_logo), contentDescription = null, modifier = Modifier.size(120.dp))
            Spacer(Modifier.height(16.dp))
            Text("KeyMapper Pro", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Made By Elite Corporation", fontSize = 14.sp, color = Color.Gray)
        }
    }
}

@Composable
fun MainShell() {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf("home") }
    var pkg by remember { mutableStateOf("") }
    var adFor by remember { mutableStateOf("") }
    var library by remember { mutableStateOf(ProfileStore.library(ctx)) }
    val tabs = listOf("home", "settings", "code")

    LaunchedEffect(Unit) {
        while (true) {
            ShizukuManager.refresh()
            delay(1500)
        }
    }
    BackHandler(enabled = screen != "home") { screen = "home" }

    val play: (String) -> Unit = { p ->
        tryPlay(ctx, p) {
            adFor = p
            screen = "ad"
        }
    }

    Scaffold(
        containerColor = bgC(),
        bottomBar = { if (screen in tabs) NavBar(screen) { screen = it } }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (screen) {
                "home" -> HomeScreen(
                    library = library,
                    onOpen = { pkg = it; screen = "game" },
                    onPlay = play,
                    onAdd = { screen = "add" },
                    onSetup = { screen = "setup" }
                )
                "add" -> AddGameScreen(
                    onPick = {
                        ProfileStore.addGame(ctx, it)
                        library = ProfileStore.library(ctx)
                        screen = "home"
                    },
                    onBack = { screen = "home" }
                )
                "game" -> GameScreen(
                    pkg = pkg,
                    onBack = { screen = "home" },
                    onPlay = { play(pkg) },
                    onRemoved = {
                        library = ProfileStore.library(ctx)
                        screen = "home"
                    }
                )
                "settings" -> SettingsScreen(onSetup = { screen = "setup" })
                "code" -> CodeScreen()
                "setup" -> SetupScreen(onBack = { screen = "home" })
                "ad" -> AdScreen { ok ->
                    if (ok) {
                        AdGate.grant(ctx)
                        startGame(ctx, adFor)?.let { toast(ctx, it) }
                    }
                    screen = "home"
                }
            }
        }
    }
}

@Composable
fun NavBar(current: String, onGo: (String) -> Unit) {
    NavigationBar(containerColor = cardC()) {
        listOf(
            Triple("home", "🎮", "Inicio"),
            Triple("settings", "⚙", "Ajustes"),
            Triple("code", "🔑", "Código")
        ).forEach { (id, icon, name) ->
            NavigationBarItem(
                selected = current == id,
                onClick = { onGo(id) },
                icon = { Text(icon, fontSize = 20.sp) },
                label = { Text(name) },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = accentC().copy(alpha = 0.30f),
                    selectedTextColor = Color.White,
                    unselectedTextColor = Color.Gray
                )
            )
        }
    }
}

// ------------------------------------------------------------------ piezas comunes
@Composable
fun StatusLine(ok: Boolean, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
        Text("●", color = if (ok) Color(0xFF43A047) else accentC())
        Spacer(Modifier.width(8.dp))
        Text(text)
    }
}

@Composable
fun AppIcon(pkg: String, size: Int = 44) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }
    if (bmp != null) Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(size.dp))
}

@Composable
fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = cardC()),
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
fun SettingSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun <V> Dropdown(label: String, options: List<Pair<V, String>>, selected: V, onSelect: (V) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val name = options.firstOrNull { it.first == selected }?.second ?: ""
    Box {
        OutlinedButton(onClick = { open = true }) { Text("$label: $name  ▾") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (v, n) ->
                DropdownMenuItem(text = { Text(n) }, onClick = {
                    onSelect(v)
                    open = false
                })
            }
        }
    }
}

@Composable
fun SwatchRow(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        colors.forEach { c ->
            val chosen = (c and 0x00FFFFFF) == (selected and 0x00FFFFFF)
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(if (chosen) 3.dp else 1.dp, if (chosen) Color.White else Color.Gray, CircleShape)
                    .clickable { onPick(c) }
            )
        }
    }
}

private val PALETTE = listOf(
    0xFFE53935, 0xFFFF9800, 0xFFFFEB3B, 0xFF4CAF50, 0xFF00BCD4,
    0xFF2196F3, 0xFF9C27B0, 0xFFE91E63, 0xFFFFFFFF, 0xFF9E9E9E
).map { it.toInt() }

@Composable
fun ColorPicker(color: Int, onChange: (Int) -> Unit) {
    SwatchRow(PALETTE, color, onChange)
    listOf(Triple("Rojo", 16, 0), Triple("Verde", 8, 1), Triple("Azul", 0, 2)).forEach { (name, shift, _) ->
        val v = (color shr shift) and 0xFF
        Text("$name: $v", fontSize = 12.sp, color = Color.Gray)
        Slider(
            value = v.toFloat(),
            onValueChange = {
                val iv = it.toInt().coerceIn(0, 255)
                onChange((color and (0xFF shl shift).inv()) or (iv shl shift) or (0xFF shl 24))
            },
            valueRange = 0f..255f
        )
    }
}

@Composable
fun KeyCaptureDialog(title: String, onResult: (Int, Int) -> Unit, onDismiss: () -> Unit) {
    val fr = remember { FocusRequester() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .border(1.dp, accentC(), RoundedCornerShape(12.dp))
                    .focusRequester(fr)
                    .focusable()
                    .onPreviewKeyEvent { ev ->
                        if (ev.type == KeyEventType.KeyDown) {
                            val kc = ev.nativeKeyEvent.keyCode
                            val isMod = kc == 113 || kc == 114 || kc == 59 || kc == 60 || kc == 57 || kc == 58
                            if (kc == 111) {
                                onDismiss()
                            } else if (!isMod) {
                                var m = 0
                                if (ev.nativeKeyEvent.isCtrlPressed) m = m or 1
                                if (ev.nativeKeyEvent.isShiftPressed) m = m or 2
                                if (ev.nativeKeyEvent.isAltPressed) m = m or 4
                                onResult(kc, m)
                            }
                            true
                        } else {
                            false
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Text("Pulsa la tecla o combinación\n(Ctrl / Shift / Alt + tecla). Esc cancela.", textAlign = TextAlign.Center)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
    LaunchedEffect(Unit) { fr.requestFocus() }
}

// ------------------------------------------------------------------ inicio
@Composable
fun HomeScreen(
    library: List<String>,
    onOpen: (String) -> Unit,
    onPlay: (String) -> Unit,
    onAdd: () -> Unit,
    onSetup: () -> Unit
) {
    val ctx = LocalContext.current
    val overlayOk by produceState(false) {
        while (true) {
            value = Settings.canDrawOverlays(ctx)
            delay(1000)
        }
    }
    val remaining by produceState(0L) {
        while (true) {
            value = AdGate.remainingMs(ctx)
            delay(3000)
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.ic_logo), contentDescription = null, modifier = Modifier.size(52.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("KeyMapper Pro", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Made By Elite Corporation", fontSize = 12.sp, color = Color.Gray)
            }
        }
        Spacer(Modifier.height(10.dp))

        SectionCard("Estado") {
            StatusLine(ShizukuManager.binderAlive, "Shizuku en ejecución")
            StatusLine(ShizukuManager.permitted, "Permiso de Shizuku concedido")
            StatusLine(ShizukuManager.connected, "Inyector de toques conectado")
            StatusLine(overlayOk, "Permiso de superposición")
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = onSetup) { Text("Asistente de configuración") }
        }

        SectionCard("Tiempo de mapeo") {
            if (Licensing.has(Licensing.F_NO_ADS)) {
                Text("Sin anuncios: mapeo ilimitado ✔")
            } else if (remaining > 0) {
                Text("Te quedan ${AdGate.format(remaining)}")
            } else {
                Text("Sin tiempo. Al pulsar Jugar verás un anuncio de ${AdGate.AD_SECONDS} s y recibirás 2 horas.", color = Color.Gray)
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Mis juegos", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(onClick = onAdd) { Text("+ Añadir") }
        }
        Spacer(Modifier.height(6.dp))
        if (library.isEmpty()) {
            Text("Aún no hay juegos. Pulsa «+ Añadir».", color = Color.Gray)
        }
        library.forEach { p ->
            Card(
                colors = CardDefaults.cardColors(containerColor = cardC()),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier.weight(1f).clickable { onOpen(p) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(p, 48)
                        Spacer(Modifier.width(12.dp))
                        Text(appLabel(ctx, p), fontSize = 18.sp)
                    }
                    Button(onClick = { onPlay(p) }) { Text("▶ Jugar") }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun AddGameScreen(onPick: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val apps by produceState<List<Pair<String, String>>>(emptyList()) {
        value = withContext(Dispatchers.Default) {
            val pm = ctx.packageManager
            pm.getInstalledApplications(0)
                .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != ctx.packageName }
                .map { it.packageName to pm.getApplicationLabel(it).toString() }
                .sortedBy { it.second.lowercase() }
        }
    }
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Text("←") }
            Spacer(Modifier.width(12.dp))
            Text("Añadir juego", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            label = { Text("Buscar") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(apps.filter { it.second.contains(q, ignoreCase = true) }) { (pkg, label) ->
                Row(
                    Modifier.fillMaxWidth().clickable { onPick(pkg) }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppIcon(pkg)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(label, fontSize = 17.sp)
                        Text(pkg, fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ juego
@Composable
fun GameScreen(pkg: String, onBack: () -> Unit, onPlay: () -> Unit, onRemoved: () -> Unit) {
    val ctx = LocalContext.current
    val profile = remember(pkg, AppState.resumes) { ProfileStore.load(ctx, pkg) }
    var sx by remember(pkg, AppState.resumes) { mutableFloatStateOf(profile.sensX) }
    var sy by remember(pkg, AppState.resumes) { mutableFloatStateOf(profile.sensY) }
    var invert by remember(pkg, AppState.resumes) { mutableStateOf(profile.invertY) }
    var auto by remember(pkg, AppState.resumes) { mutableStateOf(profile.autoCapture) }
    var hud by remember(pkg, AppState.resumes) { mutableStateOf(profile.showHud) }
    var accel by remember(pkg, AppState.resumes) { mutableFloatStateOf(profile.accel) }
    var smooth by remember(pkg, AppState.resumes) { mutableFloatStateOf(profile.smooth) }
    var ads by remember(pkg, AppState.resumes) { mutableFloatStateOf(profile.adsMult) }

    // Importante: se vuelve a leer el perfil del disco para NO pisar los controles que se editaron en el juego.
    fun commit() {
        val p = ProfileStore.load(ctx, pkg)
        p.sensX = sx
        p.sensY = sy
        p.invertY = invert
        p.autoCapture = auto
        p.showHud = hud
        p.accel = accel
        p.smooth = smooth
        p.adsMult = ads
        ProfileStore.save(ctx, p)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Text("←") }
            Spacer(Modifier.width(12.dp))
            AppIcon(pkg)
            Spacer(Modifier.width(10.dp))
            Text(appLabel(ctx, pkg), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                commit()
                onPlay()
            },
            modifier = Modifier.fillMaxWidth().height(64.dp)
        ) { Text("▶  JUGAR", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(8.dp))
        Text(
            "Con el juego abierto, pulsa ${Keys.combo(AppSettings.menuKey, AppSettings.menuMod)} para abrir el menú " +
                "(editar controles, mouse, cursor virtual). Puedes cambiar esa tecla en Ajustes.",
            fontSize = 13.sp, color = Color.Gray
        )

        SectionCard("Cámara / mira") {
            Text("Sensibilidad X: ${"%.1f".format(sx)}")
            Slider(value = sx, onValueChange = { sx = it }, onValueChangeFinished = { commit() }, valueRange = 0.2f..8f)
            Text("Sensibilidad Y: ${"%.1f".format(sy)}")
            Slider(value = sy, onValueChange = { sy = it }, onValueChangeFinished = { commit() }, valueRange = 0.2f..8f)
            Text("Suavizado: ${"%.2f".format(smooth)}")
            Slider(value = smooth, onValueChange = { smooth = it }, onValueChangeFinished = { commit() }, valueRange = 0f..0.95f)
            Text("Aceleración: ${"%.2f".format(accel)}")
            Slider(value = accel, onValueChange = { accel = it }, onValueChangeFinished = { commit() }, valueRange = 0f..1f)
            Text("Sensibilidad al apuntar (clic derecho): x${"%.2f".format(ads)}")
            Slider(value = ads, onValueChange = { ads = it }, onValueChangeFinished = { commit() }, valueRange = 0.1f..1.5f)
            SettingSwitch("Invertir eje Y", invert) { invert = it; commit() }
            Text("También se ajusta desde el engranaje del botón de cámara en el editor.", fontSize = 12.sp, color = Color.Gray)
        }

        SectionCard("Juego") {
            SettingSwitch("Capturar el mouse al entrar", auto) { auto = it; commit() }
            SettingSwitch("Mostrar los controles sobre el juego", hud) { hud = it; commit() }
        }

        SectionCard("Perfil de este juego") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    commit()
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("perfil", ProfileStore.load(ctx, pkg).toJson().toString()))
                    toast(ctx, "Perfil copiado al portapapeles")
                }) { Text("Exportar") }
                OutlinedButton(onClick = {
                    try {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val txt = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                        val imp = Profile.fromJson(JSONObject(txt))
                        imp.pkg = pkg
                        ProfileStore.save(ctx, imp)
                        toast(ctx, "Perfil importado")
                        onBack()
                    } catch (e: Exception) {
                        toast(ctx, "El portapapeles no tiene un perfil válido")
                    }
                }) { Text("Importar") }
                OutlinedButton(onClick = {
                    ProfileStore.save(ctx, ProfileStore.defaultProfile(pkg))
                    toast(ctx, "Controles borrados")
                    onBack()
                }) { Text("Borrar controles") }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {
                ProfileStore.removeGame(ctx, pkg)
                onRemoved()
            }) { Text("Quitar de la biblioteca") }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ------------------------------------------------------------------ ajustes
@Composable
fun KeyRow(title: String, code: Int, mod: Int, onChange: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            Text(Keys.combo(code, mod), color = accentC(), fontWeight = FontWeight.Bold)
        }
        OutlinedButton(onClick = onChange) { Text("Cambiar") }
    }
}

@Composable
fun SettingsScreen(onSetup: () -> Unit) {
    val ctx = LocalContext.current
    var capturing by remember { mutableStateOf("") }
    val save = { AppSettings.save(ctx) }

    if (capturing.isNotEmpty()) {
        KeyCaptureDialog(
            title = "Nuevo atajo",
            onResult = { k, m ->
                when (capturing) {
                    "menu" -> { AppSettings.menuKey = k; AppSettings.menuMod = m }
                    "capture" -> { AppSettings.captureKey = k; AppSettings.captureMod = m }
                    "cursor" -> { AppSettings.cursorKey = k; AppSettings.cursorMod = m }
                }
                save()
                capturing = ""
            },
            onDismiss = { capturing = "" }
        )
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Ajustes", fontSize = 26.sp, fontWeight = FontWeight.Bold)

        SectionCard("Atajos en el juego") {
            Text("No hay icono flotante: todo se abre con estas teclas.", fontSize = 12.sp, color = Color.Gray)
            KeyRow("Abrir el menú", AppSettings.menuKey, AppSettings.menuMod) { capturing = "menu" }
            KeyRow("Capturar / liberar el mouse", AppSettings.captureKey, AppSettings.captureMod) { capturing = "capture" }
            KeyRow("Cursor virtual (activar / desactivar)", AppSettings.cursorKey, AppSettings.cursorMod) { capturing = "cursor" }
        }

        SectionCard("Cursor virtual") {
            Text(
                "Un cursor propio que se mueve con el mouse y actúa como un dedo al hacer clic. " +
                    "Sirve cuando el cursor del sistema deja de funcionar dentro de la partida.",
                fontSize = 12.sp, color = Color.Gray
            )
            Text("Sensibilidad: ${"%.2f".format(AppSettings.cursorSens)}")
            Slider(
                value = AppSettings.cursorSens, onValueChange = { AppSettings.cursorSens = it },
                onValueChangeFinished = { save() }, valueRange = 0.1f..5f
            )
            Text("Tamaño: ${AppSettings.cursorSize.toInt()} dp")
            Slider(
                value = AppSettings.cursorSize, onValueChange = { AppSettings.cursorSize = it },
                onValueChangeFinished = { save() }, valueRange = 12f..72f
            )
            Text("Opacidad: ${(AppSettings.cursorOpacity * 100).toInt()} %")
            Slider(
                value = AppSettings.cursorOpacity, onValueChange = { AppSettings.cursorOpacity = it },
                onValueChangeFinished = { save() }, valueRange = 0.1f..1f
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Dropdown(
                    "Aspecto",
                    listOf(0 to "Windows 11", 1 to "Punto", 2 to "Cruz"),
                    AppSettings.cursorStyle
                ) { AppSettings.cursorStyle = it; save() }
            }
            Spacer(Modifier.height(4.dp))
            Dropdown(
                "Frecuencia (polling)",
                listOf(125 to "125 Hz", 250 to "250 Hz", 500 to "500 Hz", 1000 to "1000 Hz"),
                AppSettings.cursorHz
            ) { AppSettings.cursorHz = it; save() }
            Spacer(Modifier.height(6.dp))
            Text("Color del cursor", fontSize = 13.sp)
            SwatchRow(PALETTE, AppSettings.cursorColor) { AppSettings.cursorColor = it; save() }
        }

        SectionCard("Apariencia de la app") {
            Text("Color de acento")
            ColorPicker(AppSettings.accent) { AppSettings.accent = it; save() }
            Spacer(Modifier.height(8.dp))
            Text("Fondo")
            SwatchRow(
                listOf(0xFF000000, 0xFF121212, 0xFF0B1220, 0xFF150B20, 0xFF0B1A12, 0xFF1E1E1E).map { it.toInt() },
                AppSettings.background
            ) { AppSettings.background = it; save() }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {
                AppSettings.accent = 0xFFE53935.toInt()
                AppSettings.background = 0xFF000000.toInt()
                save()
            }) { Text("Restaurar colores") }
        }

        SectionCard("Conexión") {
            OutlinedButton(onClick = onSetup) { Text("Asistente de Shizuku y permisos") }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ------------------------------------------------------------------ códigos
@Composable
fun CodeScreen() {
    val ctx = LocalContext.current
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Código de promoción", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = code,
            onValueChange = { code = it },
            label = { Text("Escribe tu código") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Button(
            enabled = !busy,
            onClick = {
                busy = true
                val c = code
                val app = ctx.applicationContext
                Thread {
                    val msg = Licensing.redeem(app, c)
                    Handler(Looper.getMainLooper()).post {
                        busy = false
                        code = ""
                        toast(ctx, msg)
                    }
                }.start()
            }
        ) { Text(if (busy) "Comprobando…" else "Canjear") }

        SectionCard("Tus funciones") {
            Text(Licensing.featureNames(Licensing.mask))
            if (Licensing.isAdmin()) Text("Modo administrador activo", color = accentC(), fontWeight = FontWeight.Bold)
            if (!Licensing.has(Licensing.F_NO_ADS)) {
                Text("Sin código «sin anuncios» verás 1 anuncio de ${AdGate.AD_SECONDS} s por cada 2 horas de mapeo.", fontSize = 12.sp, color = Color.Gray)
            }
        }

        if (Licensing.isAdmin()) AdminPanel()
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun AdminPanel() {
    val ctx = LocalContext.current
    var f by remember { mutableIntStateOf(Licensing.F_NO_ADS) }
    val made = remember { mutableStateListOf<String>() }
    SectionCard("Panel de administrador") {
        Text("Crea códigos con funciones limitadas para otros usuarios.", fontSize = 12.sp, color = Color.Gray)
        listOf(
            Licensing.F_NO_ADS to "Sin anuncios",
            Licensing.F_SCRIPT to "Scripts",
            Licensing.F_CURSOR to "Cursor virtual",
            Licensing.F_STYLE to "Estilos y temas"
        ).forEach { (bit, name) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = (f and bit) != 0, onCheckedChange = { f = if (it) f or bit else f and bit.inv() })
                Text(name)
            }
        }
        Button(onClick = {
            val c = Licensing.generate(f)
            if (c != null) made.add(0, c)
        }) { Text("Generar código") }
        made.forEach { c ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(c, modifier = Modifier.weight(1f), fontSize = 13.sp)
                TextButton(onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("codigo", c))
                    toast(ctx, "Código copiado")
                }) { Text("Copiar") }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = {
            Licensing.reset(ctx)
            toast(ctx, "Permisos quitados: ahora ves la app como un usuario normal")
        }) { Text("Probar como usuario normal") }
    }
}

// ------------------------------------------------------------------ anuncio simulado
@Composable
fun AdScreen(onFinish: (Boolean) -> Unit) {
    var left by remember { mutableIntStateOf(AdGate.AD_SECONDS) }
    LaunchedEffect(Unit) {
        while (left > 0) {
            delay(1000)
            left--
        }
    }
    BackHandler(enabled = true) { onFinish(false) }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("ANUNCIO (simulación)", fontSize = 14.sp, color = Color.Gray)
        Spacer(Modifier.height(12.dp))
        Box(
            Modifier.fillMaxWidth().height(200.dp).background(cardC(), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("Aquí irá un anuncio real\ncuando la app esté en Play Store", textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(16.dp))
        LinearProgressIndicator(
            progress = { 1f - left / AdGate.AD_SECONDS.toFloat() },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Text(if (left > 0) "Recompensa en $left s" else "¡Listo!")
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onFinish(true) }, enabled = left == 0) { Text("Reclamar 2 horas de mapeo") }
        TextButton(onClick = { onFinish(false) }) { Text("Cancelar") }
    }
}

// ------------------------------------------------------------------ asistente
@Composable
fun SetupScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val overlayOk by produceState(false) {
        while (true) {
            value = Settings.canDrawOverlays(ctx)
            delay(1000)
        }
    }
    fun open(url: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Text("←") }
            Spacer(Modifier.width(12.dp))
            Text("Asistente de configuración", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        StatusLine(ShizukuManager.binderAlive, "1. Shizuku en ejecución")
        StatusLine(ShizukuManager.permitted, "2. Permiso de Shizuku concedido")
        StatusLine(ShizukuManager.connected, "3. Inyector de toques conectado")
        StatusLine(overlayOk, "4. Permiso de superposición (se concede solo al conectar)")

        SectionCard("Paso 1 · Instalar Shizuku") {
            Text("Android no deja que una app normal toque otras apps. Shizuku da ese permiso sin root.", color = Color.Gray)
            OutlinedButton(onClick = { open("https://shizuku.rikka.app/download/") }) { Text("Descargar Shizuku") }
        }
        SectionCard("Paso 2 · Iniciar por depuración inalámbrica") {
            Text(
                "Activa Opciones de desarrollador → Depuración inalámbrica. En Shizuku elige " +
                    "«Depuración inalámbrica», empareja con el código y pulsa Iniciar.",
                color = Color.Gray
            )
            OutlinedButton(onClick = {
                try {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                }
            }) { Text("Abrir opciones de desarrollador") }
            Spacer(Modifier.height(6.dp))
            Text("Alternativa por USB con PC:", fontWeight = FontWeight.Bold)
            Text(
                "adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh",
                color = Color.Gray, fontSize = 12.sp
            )
        }
        SectionCard("Paso 3 · Dar permiso a KeyMapper Pro") {
            Button(onClick = { ShizukuManager.requestPermission() }) { Text("Conceder permiso de Shizuku") }
        }
        SectionCard("Superposición manual (solo si no se concedió sola)") {
            OutlinedButton(onClick = {
                try {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                }
            }) { Text("Permiso de superposición") }
        }
        Spacer(Modifier.height(24.dp))
    }
}
