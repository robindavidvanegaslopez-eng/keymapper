package com.keymapperpro

import android.content.Context
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Códigos de promoción.
 *  - El código de creador NO está en el programa: solo su hash PBKDF2 (120 000 iteraciones, con sal).
 *  - El permiso concedido se guarda firmado (HMAC) con una clave atada a este dispositivo, así que
 *    editar las preferencias a mano no sirve.
 *  - Los códigos que genera el administrador son portátiles y llevan firma.
 * Aviso: todo lo que viaja dentro del APK puede ser analizado por alguien con tiempo. Antes de
 * publicar en Play Store, valida los códigos y las compras desde un servidor.
 */
object Licensing {
    const val F_NO_ADS = 1
    const val F_SCRIPT = 2
    const val F_CURSOR = 4
    const val F_STYLE = 8
    const val F_ADMIN = 0x100
    const val F_ALL = 0x10F

    private const val ADMIN_SALT = "5d90ec2933b99f9270f672b522cb3865"
    private const val ADMIN_HASH = "cf9993762e799d673319126929ed93780489c2bed4f44b92106094155f9ba03a"
    private const val PEPPER = "7c7d0dc7e2bb89ddde4a6b0f"
    private val SECRET_PARTS = listOf("a96954363a3c", "EliteCorp", "52334b5b2896", "KeyMapperPro", "7563ff1fe45d")
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    var mask by mutableIntStateOf(0)

    fun has(f: Int): Boolean = (mask and f) == f
    fun isAdmin(): Boolean = (mask and F_ADMIN) != 0

    private fun prefs(c: Context) = c.getSharedPreferences("km_lic", Context.MODE_PRIVATE)

    private fun deviceKey(c: Context): ByteArray {
        val id = Settings.Secure.getString(c.contentResolver, Settings.Secure.ANDROID_ID) ?: "x"
        return MessageDigest.getInstance("SHA-256").digest((PEPPER + id + c.packageName).toByteArray())
    }

    private fun hmac(key: ByteArray, msg: String): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        return m.doFinal(msg.toByteArray())
    }

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    private fun unhex(s: String): ByteArray = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    /** Firma un texto con la clave de este dispositivo (para guardar valores sin que se puedan editar). */
    fun sign(c: Context, msg: String): String = hex(hmac(deviceKey(c), msg))

    fun load(c: Context) {
        val p = prefs(c)
        val m = p.getInt("mask", 0)
        val tag = p.getString("tag", "") ?: ""
        mask = if (m != 0 && MessageDigest.isEqual(tag.toByteArray(), sign(c, "lic:$m").toByteArray())) m else 0
    }

    private fun grant(c: Context, add: Int) {
        val m = mask or add
        prefs(c).edit().putInt("mask", m).putString("tag", sign(c, "lic:$m")).apply()
        mask = m
    }

    fun reset(c: Context) {
        prefs(c).edit().clear().apply()
        mask = 0
    }

    private fun pbkdf2(code: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(code.toCharArray(), salt, 120000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun secret(): ByteArray =
        MessageDigest.getInstance("SHA-256").digest(SECRET_PARTS.joinToString("|").toByteArray())

    private fun b32(bytes: ByteArray, n: Int): String {
        val sb = StringBuilder()
        for (i in 0 until n) sb.append(ALPHABET[(bytes[i].toInt() and 0xFF) % 32])
        return sb.toString()
    }

    private fun signature(maskHex: String, nonce: String): String =
        b32(hmac(secret(), "KM" + maskHex + nonce), 8)

    /** Genera un código portátil con las funciones indicadas (solo administrador). */
    fun generate(features: Int): String? {
        if (!isAdmin()) return null
        val f = features and 0xFF
        val r = SecureRandom()
        val nonce = (0 until 6).map { ALPHABET[r.nextInt(32)] }.joinToString("")
        val mh = "%02X".format(f)
        return "KM-" + mh + nonce + "-" + signature(mh, nonce)
    }

    private fun parseSigned(raw: String): Int? {
        val s = raw.uppercase().filter { it.isLetterOrDigit() }
        if (s.length != 18 || !s.startsWith("KM")) return null
        val mh = s.substring(2, 4)
        val nonce = s.substring(4, 10)
        val sig = s.substring(10, 18)
        val ok = MessageDigest.isEqual(sig.toByteArray(), signature(mh, nonce).toByteArray())
        if (!ok) return null
        return mh.toIntOrNull(16)
    }

    /** Canjea un código. Es lento (PBKDF2): llamar desde un hilo secundario. */
    fun redeem(c: Context, raw: String): String {
        val code = raw.trim()
        if (code.isEmpty()) return "Escribe un código."
        val p = prefs(c)
        val now = System.currentTimeMillis()
        val lock = p.getLong("lock", 0L)
        if (now < lock) return "Demasiados intentos. Espera ${(lock - now) / 1000 + 1} s."
        val adminOk = try {
            MessageDigest.isEqual(pbkdf2(code, unhex(ADMIN_SALT)), unhex(ADMIN_HASH))
        } catch (t: Throwable) {
            false
        }
        if (adminOk) {
            p.edit().putInt("fails", 0).apply()
            grant(c, F_ALL)
            return "Código de administrador activado."
        }
        val m = parseSigned(code)
        if (m != null && m != 0) {
            p.edit().putInt("fails", 0).apply()
            grant(c, m)
            return "Código activado."
        }
        val fails = p.getInt("fails", 0) + 1
        val e = p.edit().putInt("fails", fails)
        if (fails >= 5) {
            e.putLong("lock", now + 30000L * (fails - 4))
        }
        e.apply()
        return "Código no válido."
    }

    fun featureNames(m: Int): String {
        val l = ArrayList<String>()
        if (m and F_NO_ADS != 0) l.add("Sin anuncios")
        if (m and F_SCRIPT != 0) l.add("Scripts")
        if (m and F_CURSOR != 0) l.add("Cursor virtual")
        if (m and F_STYLE != 0) l.add("Estilos")
        return if (l.isEmpty()) "Ninguna" else l.joinToString(", ")
    }
}

/** Simulación de anuncio: 20 s de anuncio dan 2 horas de mapeo, salvo con código sin anuncios. */
object AdGate {
    const val AD_SECONDS = 20
    private const val TWO_HOURS = 2L * 60 * 60 * 1000

    private fun prefs(c: Context) = c.getSharedPreferences("km_ads", Context.MODE_PRIVATE)

    fun remainingMs(c: Context): Long {
        if (Licensing.has(Licensing.F_NO_ADS)) return Long.MAX_VALUE
        val p = prefs(c)
        val now = System.currentTimeMillis()
        val last = p.getLong("last", 0L)
        val until = p.getLong("until", 0L)
        val tag = p.getString("tag", "") ?: ""
        var valid = until
        if (!MessageDigest.isEqual(tag.toByteArray(), Licensing.sign(c, "ads:$until").toByteArray())) valid = 0L
        if (now < last - 120000L) valid = 0L // reloj atrasado
        if (now > last) p.edit().putLong("last", now).apply()
        return (valid - now).coerceAtLeast(0L)
    }

    fun grant(c: Context) {
        val now = System.currentTimeMillis()
        val until = now + TWO_HOURS
        prefs(c).edit().putLong("until", until).putLong("last", now)
            .putString("tag", Licensing.sign(c, "ads:$until")).apply()
    }

    fun format(ms: Long): String {
        if (ms == Long.MAX_VALUE) return "Ilimitado"
        val m = ms / 60000
        return if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min"
    }
}
