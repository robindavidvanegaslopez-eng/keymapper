package com.keymapperpro

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.lang.reflect.Method
import kotlin.system.exitProcess

/**
 * Corre en un proceso con privilegios de shell (lo lanza Shizuku).
 * Inyecta toques multitáctiles en el sistema, igual que "adb shell input".
 */
class InputService : IInputService.Stub() {
    private val ids = ArrayList<Int>()
    private val xs = HashMap<Int, Float>()
    private val ys = HashMap<Int, Float>()
    private var downTime = 0L
    private var im: Any? = null
    private var inject: Method? = null
    private var err = "ok"

    init {
        try {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, "input") as IBinder
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            im = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            val iface = Class.forName("android.hardware.input.IInputManager")
            inject = iface.getMethod(
                "injectInputEvent",
                InputEvent::class.java,
                Int::class.javaPrimitiveType!!
            )
        } catch (t: Throwable) {
            err = t.toString()
        }
    }

    private fun send(action: Int, now: Long) {
        val n = ids.size
        if (n == 0) return
        val props = Array(n) { i ->
            MotionEvent.PointerProperties().apply {
                id = ids[i]
                toolType = MotionEvent.TOOL_TYPE_FINGER
            }
        }
        val coords = Array(n) { i ->
            MotionEvent.PointerCoords().apply {
                x = xs[ids[i]] ?: 0f
                y = ys[ids[i]] ?: 0f
                pressure = 1f
                size = 1f
            }
        }
        val ev = MotionEvent.obtain(
            downTime, now, action, n, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        try {
            inject?.invoke(im, ev, 0) // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
        } catch (t: Throwable) {
            err = t.toString()
        }
        ev.recycle()
    }

    @Synchronized
    override fun touch(id: Int, action: Int, x: Float, y: Float) {
        val now = SystemClock.uptimeMillis()
        when (action) {
            0 -> {
                if (ids.contains(id)) {
                    xs[id] = x
                    ys[id] = y
                    send(MotionEvent.ACTION_MOVE, now)
                } else {
                    if (ids.isEmpty()) downTime = now
                    ids.add(id)
                    xs[id] = x
                    ys[id] = y
                    val a = if (ids.size == 1) MotionEvent.ACTION_DOWN
                    else MotionEvent.ACTION_POINTER_DOWN or (ids.indexOf(id) shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
                    send(a, now)
                }
            }
            2 -> {
                if (!ids.contains(id)) return
                xs[id] = x
                ys[id] = y
                send(MotionEvent.ACTION_MOVE, now)
            }
            1 -> {
                if (!ids.contains(id)) return
                xs[id] = x
                ys[id] = y
                val idx = ids.indexOf(id)
                val a = if (ids.size == 1) MotionEvent.ACTION_UP
                else MotionEvent.ACTION_POINTER_UP or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
                send(a, now)
                ids.removeAt(idx)
                xs.remove(id)
                ys.remove(id)
            }
        }
    }

    @Synchronized
    override fun releaseAll() {
        while (ids.isNotEmpty()) {
            val id = ids[ids.size - 1]
            touch(id, 1, xs[id] ?: 0f, ys[id] ?: 0f)
        }
    }

    override fun shell(cmd: String?): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd ?: ""))
            val out = p.inputStream.bufferedReader().readText()
            val e = p.errorStream.bufferedReader().readText()
            p.waitFor()
            out + e
        } catch (t: Throwable) {
            t.toString()
        }
    }

    override fun status(): String = err

    override fun destroy() {
        exitProcess(0)
    }
}
