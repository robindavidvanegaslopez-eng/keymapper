package com.keymapperpro

import android.view.KeyEvent

object Keys {
    const val MOUSE_LEFT = -1
    const val MOUSE_RIGHT = -2
    const val MOUSE_MIDDLE = -3
    const val WHEEL_UP = -4
    const val WHEEL_DOWN = -5

    fun name(code: Int): String = when (code) {
        0 -> "—"
        MOUSE_LEFT -> "Clic izq."
        MOUSE_RIGHT -> "Clic der."
        MOUSE_MIDDLE -> "Clic cent."
        WHEEL_UP -> "Rueda ↑"
        WHEEL_DOWN -> "Rueda ↓"
        else -> KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
    }
}
