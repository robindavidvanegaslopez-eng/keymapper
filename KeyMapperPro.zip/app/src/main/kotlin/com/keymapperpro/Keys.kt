package com.keymapperpro

import android.view.KeyEvent

object Keys {
    const val MOUSE_LEFT = -1
    const val MOUSE_RIGHT = -2
    const val MOUSE_MIDDLE = -3
    const val WHEEL_UP = -4
    const val WHEEL_DOWN = -5

    fun label(b: Binding): String {
        val sb = StringBuilder()
        if ((b.mod and 1) != 0) sb.append("Ctrl+")
        if ((b.mod and 2) != 0) sb.append("Shift+")
        if ((b.mod and 4) != 0) sb.append("Alt+")
        sb.append(name(b.keys[0]))
        if (b.type != T.JOYSTICK && b.keys[1] != 0) sb.append("+").append(name(b.keys[1]))
        return sb.toString()
    }

    /** Texto de un atajo: tecla con Ctrl/Shift/Alt. */
    fun combo(code: Int, mod: Int): String {
        val sb = StringBuilder()
        if ((mod and 1) != 0) sb.append("Ctrl+")
        if ((mod and 2) != 0) sb.append("Shift+")
        if ((mod and 4) != 0) sb.append("Alt+")
        sb.append(name(code))
        return sb.toString()
    }

    fun name(code: Int): String = when (code) {
        0 -> "—"
        MOUSE_LEFT -> "Clic izq."
        MOUSE_RIGHT -> "Clic der."
        MOUSE_MIDDLE -> "Clic cent."
        WHEEL_UP -> "Rueda ↑"
        WHEEL_DOWN -> "Rueda ↓"
        else -> KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
    }
}
