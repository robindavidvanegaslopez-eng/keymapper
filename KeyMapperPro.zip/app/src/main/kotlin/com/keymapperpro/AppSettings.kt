package com.keymapperpro

import android.content.Context
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** Ajustes globales de la app (no dependen del juego). */
object AppSettings {
    var accent by mutableIntStateOf(0xFFE53935.toInt())
    var background by mutableIntStateOf(0xFF000000.toInt())

    // Atajos (tecla + combinación 1 = Ctrl, 2 = Shift, 4 = Alt)
    var menuKey by mutableIntStateOf(KeyEvent.KEYCODE_F2)
    var menuMod by mutableIntStateOf(0)
    var captureKey by mutableIntStateOf(KeyEvent.KEYCODE_F1)
    var captureMod by mutableIntStateOf(0)
    var cursorKey by mutableIntStateOf(KeyEvent.KEYCODE_F3)
    var cursorMod by mutableIntStateOf(0)

    // Cursor virtual
    var cursorSens by mutableFloatStateOf(1f)
    var cursorSize by mutableFloatStateOf(24f)
    var cursorStyle by mutableIntStateOf(0) // 0 = Windows 11, 1 = punto, 2 = cruz
    var cursorColor by mutableIntStateOf(0xFFFFFFFF.toInt())
    var cursorOpacity by mutableFloatStateOf(1f)
    var cursorHz by mutableIntStateOf(125)

    private fun prefs(c: Context) = c.getSharedPreferences("km_settings", Context.MODE_PRIVATE)

    fun load(c: Context) {
        val p = prefs(c)
        accent = p.getInt("accent", accent)
        background = p.getInt("background", background)
        menuKey = p.getInt("menuKey", KeyEvent.KEYCODE_F2)
        menuMod = p.getInt("menuMod", 0)
        captureKey = p.getInt("captureKey", KeyEvent.KEYCODE_F1)
        captureMod = p.getInt("captureMod", 0)
        cursorKey = p.getInt("cursorKey", KeyEvent.KEYCODE_F3)
        cursorMod = p.getInt("cursorMod", 0)
        cursorSens = p.getFloat("cursorSens", 1f)
        cursorSize = p.getFloat("cursorSize", 24f)
        cursorStyle = p.getInt("cursorStyle", 0)
        cursorColor = p.getInt("cursorColor", 0xFFFFFFFF.toInt())
        cursorOpacity = p.getFloat("cursorOpacity", 1f)
        cursorHz = p.getInt("cursorHz", 125)
    }

    fun save(c: Context) {
        prefs(c).edit()
            .putInt("accent", accent).putInt("background", background)
            .putInt("menuKey", menuKey).putInt("menuMod", menuMod)
            .putInt("captureKey", captureKey).putInt("captureMod", captureMod)
            .putInt("cursorKey", cursorKey).putInt("cursorMod", cursorMod)
            .putFloat("cursorSens", cursorSens).putFloat("cursorSize", cursorSize)
            .putInt("cursorStyle", cursorStyle).putInt("cursorColor", cursorColor)
            .putFloat("cursorOpacity", cursorOpacity).putInt("cursorHz", cursorHz)
            .apply()
    }
}
