package com.keymapperpro

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import rikka.shizuku.Shizuku

/** Lado app: conecta con Shizuku y expone el inyector de toques. */
object ShizukuManager {
    var binderAlive by mutableStateOf(false)
    var permitted by mutableStateOf(false)
    var connected by mutableStateOf(false)

    @Volatile
    var service: IInputService? = null
    private var appCtx: Context? = null
    private var inited = false
    private var binding = false

    private val onBinder = Shizuku.OnBinderReceivedListener {
        binderAlive = true
        refresh()
    }
    private val onDead = Shizuku.OnBinderDeadListener {
        binderAlive = false
        permitted = false
        connected = false
        service = null
        binding = false
    }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, result ->
        permitted = result == PackageManager.PERMISSION_GRANTED
        if (permitted) bind()
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            binding = false
            if (binder != null && binder.pingBinder()) {
                service = IInputService.Stub.asInterface(binder)
                connected = true
                grantSelf()
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            connected = false
            binding = false
        }
    }

    fun init(c: Context) {
        if (inited) return
        inited = true
        appCtx = c.applicationContext
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }

    fun refresh() {
        try {
            binderAlive = Shizuku.pingBinder()
            if (!binderAlive) return
            if (Shizuku.isPreV11()) return
            permitted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            if (permitted && service == null && !binding) bind()
        } catch (t: Throwable) {
        }
    }

    fun requestPermission() {
        try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) return
            Shizuku.requestPermission(100)
        } catch (t: Throwable) {
        }
    }

    private fun bind() {
        val c = appCtx ?: return
        try {
            binding = true
            val args = Shizuku.UserServiceArgs(ComponentName(c.packageName, InputService::class.java.name))
                .daemon(false)
                .processNameSuffix("input")
                .version(1)
            Shizuku.bindUserService(args, conn)
        } catch (t: Throwable) {
            binding = false
        }
    }

    /** Con privilegios de shell, nos damos solos los permisos de superposición y de uso de apps. */
    private fun grantSelf() {
        val c = appCtx ?: return
        val p = c.packageName
        Thread {
            try {
                service?.shell(
                    "appops set $p SYSTEM_ALERT_WINDOW allow; " +
                        "appops set $p GET_USAGE_STATS allow; " +
                        "pm grant $p android.permission.POST_NOTIFICATIONS"
                )
            } catch (t: Throwable) {
            }
        }.start()
    }

    fun touch(id: Int, action: Int, x: Float, y: Float) {
        try {
            service?.touch(id, action, x, y)
        } catch (t: Throwable) {
        }
    }

    fun releaseAll() {
        try {
            service?.releaseAll()
        } catch (t: Throwable) {
        }
    }
}
