package com.keymapperpro

import android.os.Handler
import android.os.HandlerThread
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Traduce teclas/mouse a toques. Toda la lógica de estado corre en un hilo dedicado ("km-inject")
 * para no bloquear la interfaz y mantener el orden de los eventos.
 */
object MappingEngine {
    @Volatile
    var profile: Profile? = null
    @Volatile
    private var active = false
    @Volatile
    private var captured = false
    @Volatile
    private var sw = 0
    @Volatile
    private var sh = 0

    private val thread = HandlerThread("km-inject").also { it.start() }
    private val h = Handler(thread.looper)

    // --- estado (solo se toca desde el hilo h) ---
    private val used = BooleanArray(10)
    private val lx = FloatArray(10)
    private val ly = FloatArray(10)
    private val ptr = HashMap<String, Int>()
    private val held = HashMap<String, BooleanArray>()
    private val turbo = HashMap<String, Runnable>()
    private var camId = -1
    private var camX = 0f
    private var camY = 0f
    private var prevDx = 0f
    private var prevDy = 0f
    private var adsHeld = false
    private val seqRun = HashSet<String>()

    private val lock = Any()
    private var accDx = 0f
    private var accDy = 0f
    private val camScheduled = AtomicBoolean(false)

    // ---------- API pública ----------
    fun start(p: Profile) {
        profile = p
        active = true
    }

    fun stop() {
        active = false
        captured = false
        h.post { releaseAll() }
    }

    fun setScreen(w: Int, hh: Int) {
        sw = w
        sh = hh
    }

    fun setCaptured(c: Boolean) {
        captured = c
        if (!c) {
            h.post {
                camRelease()
                mouseRelease()
            }
        }
    }

    fun onKey(code: Int, down: Boolean) {
        if (!active || code == 0) return
        h.post { handleKey(code, down) }
    }

    fun onMouseDelta(dx: Float, dy: Float) {
        if (!active || !captured) return
        synchronized(lock) {
            accDx += dx
            accDy += dy
        }
        if (camScheduled.compareAndSet(false, true)) h.post(camTick)
    }

    // ---------- internos (hilo h) ----------
    private fun send(id: Int, action: Int, x: Float, y: Float) {
        lx[id] = x
        ly[id] = y
        ShizukuManager.touch(id, action, x, y)
    }

    private fun alloc(): Int? {
        for (i in used.indices) {
            if (!used[i]) {
                used[i] = true
                return i
            }
        }
        return null
    }

    private fun press(b: Binding) {
        if (ptr.containsKey(b.id)) return
        val id = alloc() ?: return
        ptr[b.id] = id
        send(id, 0, b.x * sw, b.y * sh)
    }

    private fun release(b: Binding) {
        val id = ptr.remove(b.id) ?: return
        used[id] = false
        send(id, 1, lx[id], ly[id])
    }

    private fun startTurbo(b: Binding) {
        if (turbo.containsKey(b.id)) return
        val r = object : Runnable {
            var on = false
            override fun run() {
                if (!turbo.containsKey(b.id)) return
                if (on) release(b) else press(b)
                on = !on
                h.postDelayed(this, 35)
            }
        }
        turbo[b.id] = r
        h.post(r)
    }

    private fun stopTurbo(b: Binding) {
        val r = turbo.remove(b.id)
        if (r != null) h.removeCallbacks(r)
        release(b)
    }

    private fun doubleTap(b: Binding) {
        press(b)
        h.postDelayed({ release(b) }, 40)
        h.postDelayed({ if (active) press(b) }, 90)
        h.postDelayed({ release(b) }, 130)
    }

    private fun swipe(b: Binding) {
        if (ptr.containsKey(b.id)) return
        val id = alloc() ?: return
        ptr[b.id] = id
        val steps = 8
        val x0 = b.x * sw
        val y0 = b.y * sh
        val x1 = b.x2 * sw
        val y1 = b.y2 * sh
        send(id, 0, x0, y0)
        val gap = maxOf(8, b.ms / steps).toLong()
        for (i in 1..steps) {
            h.postDelayed({
                if (ptr[b.id] == id) send(id, 2, x0 + (x1 - x0) * i / steps, y0 + (y1 - y0) * i / steps)
            }, gap * i)
        }
        h.postDelayed({ if (ptr[b.id] == id) release(b) }, gap * (steps + 1))
    }

    private fun startSeq(b: Binding) {
        if (!seqRun.add(b.id)) return
        var left = b.n.coerceAtLeast(1)
        val r = object : Runnable {
            override fun run() {
                if (!active || left <= 0) {
                    seqRun.remove(b.id)
                    return
                }
                press(b)
                h.postDelayed({ release(b) }, (b.ms / 2).coerceAtLeast(20).toLong())
                left--
                h.postDelayed(this, b.ms.coerceAtLeast(40).toLong())
            }
        }
        h.post(r)
    }

    private fun handleKey(code: Int, down: Boolean) {
        val p = profile ?: return
        if (!active) return
        if (code < 0 && !captured) return
        if (code == p.adsKey) adsHeld = down
        for (b in p.bindings) {
            when (b.type) {
                T.TAP, T.FIRE -> if (b.keys[0] == code) {
                    if (down) press(b) else release(b)
                }
                T.CLICK -> if (b.keys[0] == code && down) {
                    press(b)
                    h.postDelayed({ release(b) }, 45)
                }
                T.TURBO -> if (b.keys[0] == code) {
                    if (down) startTurbo(b) else stopTurbo(b)
                }
                T.DOUBLE -> if (b.keys[0] == code && down) doubleTap(b)
                T.SWIPE -> if (b.keys[0] == code && down) swipe(b)
                T.SEQ -> if (b.keys[0] == code && down) startSeq(b)
                T.JOYSTICK -> {
                    val i = b.keys.indexOf(code)
                    if (i in 0..3) {
                        val k = held.getOrPut(b.id) { BooleanArray(4) }
                        k[i] = down
                        updateJoystick(b, p)
                    }
                }
            }
        }
    }

    private fun updateJoystick(b: Binding, p: Profile) {
        val k = held[b.id] ?: return
        val dx = (if (k[3]) 1f else 0f) - (if (k[1]) 1f else 0f)
        val dy = (if (k[2]) 1f else 0f) - (if (k[0]) 1f else 0f)
        if (dx == 0f && dy == 0f) {
            release(b)
            return
        }
        val len = sqrt(dx * dx + dy * dy)
        val rad = b.r * min(sw, sh)
        val cx = b.x * sw
        val cy = b.y * sh
        val tx = cx + dx / len * rad
        val ty = cy + dy / len * rad
        val id = ptr[b.id]
        if (id == null) {
            val n = alloc() ?: return
            ptr[b.id] = n
            if (p.joyDirect) {
                send(n, 0, tx, ty)
            } else {
                send(n, 0, cx, cy)
                send(n, 2, tx, ty)
            }
        } else {
            send(id, 2, tx, ty)
        }
    }

    private val camTick = object : Runnable {
        override fun run() {
            camScheduled.set(false)
            val p = profile ?: return
            if (!active || !captured) return
            var dx = 0f
            var dy = 0f
            synchronized(lock) {
                dx = accDx
                dy = accDy
                accDx = 0f
                accDy = 0f
            }
            if (dx == 0f && dy == 0f) return
            val cam = p.bindings.firstOrNull { it.type == T.CAMERA } ?: return
            val cx = cam.x * sw
            val cy = cam.y * sh
            val half = cam.r * min(sw, sh)
            if (camId < 0) {
                val n = alloc() ?: return
                camId = n
                camX = cx
                camY = cy
                send(camId, 0, camX, camY)
            }
            val speed = sqrt(dx * dx + dy * dy)
            val acc = 1f + p.accel * min(speed / 15f, 3f)
            val ads = if (adsHeld) p.adsMult else 1f
            val sdx = prevDx * p.smooth + dx * (1f - p.smooth)
            val sdy = prevDy * p.smooth + dy * (1f - p.smooth)
            prevDx = sdx
            prevDy = sdy
            camX += sdx * p.sensX * acc * ads
            camY += sdy * p.sensY * acc * ads * (if (p.invertY) -1f else 1f)
            if (abs(camX - cx) > half || abs(camY - cy) > half) {
                camX = camX.coerceIn(cx - half, cx + half)
                camY = camY.coerceIn(cy - half, cy + half)
                send(camId, 2, camX, camY)
                send(camId, 1, camX, camY)
                send(camId, 0, cx, cy)
                camX = cx
                camY = cy
            } else {
                send(camId, 2, camX, camY)
            }
            h.removeCallbacks(camIdle)
            h.postDelayed(camIdle, 150)
        }
    }

    private val camIdle = Runnable { camRelease() }

    private fun camRelease() {
        h.removeCallbacks(camIdle)
        prevDx = 0f
        prevDy = 0f
        if (camId >= 0) {
            send(camId, 1, lx[camId], ly[camId])
            used[camId] = false
            camId = -1
        }
    }

    private fun mouseRelease() {
        val p = profile ?: return
        for (b in p.bindings) {
            if (b.type != T.JOYSTICK && b.keys[0] < 0) stopTurbo(b)
        }
    }

    private fun releaseAll() {
        h.removeCallbacksAndMessages(null)
        camScheduled.set(false)
        synchronized(lock) {
            accDx = 0f
            accDy = 0f
        }
        seqRun.clear()
        adsHeld = false
        turbo.clear()
        camRelease()
        for ((_, id) in ptr) {
            send(id, 1, lx[id], ly[id])
            used[id] = false
        }
        ptr.clear()
        held.clear()
        ShizukuManager.releaseAll()
    }
}
