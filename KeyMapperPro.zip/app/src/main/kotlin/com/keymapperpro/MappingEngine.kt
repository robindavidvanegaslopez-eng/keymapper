package com.keymapperpro

import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import android.os.SystemClock
import android.view.KeyEvent
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Traduce teclas/mouse a toques. Toda la lógica de estado corre en un hilo dedicado ("km-inject")
 * para no bloquear la interfaz y mantener el orden de los eventos.
 *
 * Cada control usa SIEMPRE el mismo id de dedo (según su posición en el perfil), así el joystick,
 * la cámara y el disparo conviven como dedos independientes y estables.
 */
object MappingEngine {
    @Volatile
    var profile: Profile? = null
    @Volatile
    private var active = false
    @Volatile
    private var captured = false
    @Volatile
    private var sw = 0
    @Volatile
    private var sh = 0

    // Cursor virtual (lo dibuja InputOverlayView)
    @Volatile
    var cursorMode = false
        private set
    @Volatile
    var cursorX = 0f
        private set
    @Volatile
    var cursorY = 0f
        private set

    private val thread = HandlerThread("km-inject", Process.THREAD_PRIORITY_URGENT_DISPLAY).also { it.start() }
    private val h = Handler(thread.looper)

    // --- estado (solo se toca desde el hilo h) ---
    private val used = BooleanArray(10)
    private val lx = FloatArray(10)
    private val ly = FloatArray(10)
    private val ptr = HashMap<String, Int>()
    private val held = HashMap<String, BooleanArray>()
    private val turbo = HashMap<String, Runnable>()
    private val seqRun = HashSet<String>()
    private val pressed = HashSet<Int>()
    private var mods = 0
    private var adsHeld = false

    private var camId = -1
    private var camX = 0f
    private var camY = 0f
    private var lastMove = 0L

    private val joyState = HashMap<String, FloatArray>()
    private val joyDir = HashMap<String, Int>()
    private var joyOn = false

    private var curId = -1

    private val lock = Any()
    private var accDx = 0f
    private var accDy = 0f
    private var curAccX = 0f
    private var curAccY = 0f
    private val camRunning = AtomicBoolean(false)
    private val curRunning = AtomicBoolean(false)

    // ---------- API pública ----------
    fun start(p: Profile) {
        profile = p
        active = true
    }

    fun stop() {
        active = false
        captured = false
        h.post { releaseAll() }
    }

    fun setScreen(w: Int, hh: Int) {
        sw = w
        sh = hh
    }

    fun setCaptured(c: Boolean) {
        captured = c
        if (!c) {
            h.post {
                camRelease()
                mouseRelease()
                cursorClick(false)
            }
        }
    }

    fun setCursorMode(on: Boolean) {
        h.post {
            if (on == cursorMode) return@post
            if (on) {
                camRelease()
                mouseRelease()
                if (cursorX == 0f && cursorY == 0f) {
                    cursorX = sw / 2f
                    cursorY = sh / 2f
                }
                cursorMode = true
            } else {
                cursorClick(false)
                cursorMode = false
            }
        }
    }

    fun onKey(code: Int, down: Boolean) {
        if (!active || code == 0) return
        h.post { handleKey(code, down) }
    }

    fun onMouseDelta(dx: Float, dy: Float) {
        if (!active || !captured) return
        if (cursorMode) {
            synchronized(lock) {
                curAccX += dx
                curAccY += dy
            }
            if (curRunning.compareAndSet(false, true)) h.post(curLoop)
        } else {
            synchronized(lock) {
                accDx += dx
                accDy += dy
            }
            if (camRunning.compareAndSet(false, true)) h.post(camLoop)
        }
    }

    // ---------- internos (hilo h) ----------
    private fun send(id: Int, action: Int, x: Float, y: Float) {
        lx[id] = x
        ly[id] = y
        ShizukuManager.touch(id, action, x, y)
    }

    /** Id estable: el control i del perfil usa el dedo i (si está libre). */
    private fun alloc(b: Binding?): Int? {
        if (b != null) {
            val pref = profile?.bindings?.indexOf(b) ?: -1
            if (pref in 0 until 9 && !used[pref]) {
                used[pref] = true
                return pref
            }
        }
        for (i in 0 until 9) {
            if (!used[i]) {
                used[i] = true
                return i
            }
        }
        return null
    }

    private fun press(b: Binding) {
        if (ptr.containsKey(b.id)) return
        val id = alloc(b) ?: return
        ptr[b.id] = id
        send(id, 0, b.x * sw, b.y * sh)
    }

    private fun release(b: Binding) {
        val id = ptr.remove(b.id) ?: return
        used[id] = false
        send(id, 1, lx[id], ly[id])
    }

    private fun startTurbo(b: Binding) {
        if (turbo.containsKey(b.id)) return
        val r = object : Runnable {
            var on = false
            override fun run() {
                if (!turbo.containsKey(b.id)) return
                if (on) release(b) else press(b)
                on = !on
                h.postDelayed(this, 35)
            }
        }
        turbo[b.id] = r
        h.post(r)
    }

    private fun stopTurbo(b: Binding) {
        val r = turbo.remove(b.id)
        if (r != null) h.removeCallbacks(r)
        release(b)
    }

    private fun doubleTap(b: Binding) {
        press(b)
        h.postDelayed({ release(b) }, 40)
        h.postDelayed({ if (active) press(b) }, 90)
        h.postDelayed({ release(b) }, 130)
    }

    private fun swipe(b: Binding) {
        if (ptr.containsKey(b.id)) return
        val id = alloc(b) ?: return
        ptr[b.id] = id
        val steps = 8
        val x0 = b.x * sw
        val y0 = b.y * sh
        val x1 = b.x2 * sw
        val y1 = b.y2 * sh
        send(id, 0, x0, y0)
        val gap = max(8, b.ms / steps).toLong()
        for (i in 1..steps) {
            h.postDelayed({
                if (ptr[b.id] == id) send(id, 2, x0 + (x1 - x0) * i / steps, y0 + (y1 - y0) * i / steps)
            }, gap * i)
        }
        h.postDelayed({ if (ptr[b.id] == id) release(b) }, gap * (steps + 1))
    }

    private fun startSeq(b: Binding) {
        if (!seqRun.add(b.id)) return
        var left = b.n.coerceAtLeast(1)
        val r = object : Runnable {
            override fun run() {
                if (!active || left <= 0) {
                    seqRun.remove(b.id)
                    return
                }
                press(b)
                h.postDelayed({ release(b) }, (b.ms / 2).coerceAtLeast(20).toLong())
                left--
                h.postDelayed(this, b.ms.coerceAtLeast(40).toLong())
            }
        }
        h.post(r)
    }

    private fun modBit(code: Int): Int = when (code) {
        KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> 1
        KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> 2
        KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT -> 4
        else -> 0
    }

    /** Combinación: Ctrl/Shift/Alt exigidos y, si hay, una tecla extra mantenida. */
    private fun comboOk(b: Binding): Boolean {
        if (b.mod != 0 && (mods and b.mod) != b.mod) return false
        val k2 = b.keys[1]
        if (k2 != 0 && !pressed.contains(k2)) return false
        return true
    }

    private fun handleKey(code: Int, down: Boolean) {
        val p = profile ?: return
        if (!active) return
        val mb = modBit(code)
        if (mb != 0) mods = if (down) (mods or mb) else (mods and mb.inv())
        if (down) pressed.add(code) else pressed.remove(code)
        if (cursorMode && code < 0) {
            if (code == Keys.MOUSE_LEFT) cursorClick(down)
            return
        }
        if (code < 0 && !captured) return
        if (code == p.adsKey) adsHeld = down
        for (b in p.bindings) {
            when (b.type) {
                T.TAP, T.FIRE -> if (b.keys[0] == code) {
                    if (down) {
                        if (comboOk(b)) press(b)
                    } else release(b)
                }
                T.CLICK -> if (b.keys[0] == code && down && comboOk(b)) {
                    press(b)
                    h.postDelayed({ release(b) }, 45)
                }
                T.TURBO -> if (b.keys[0] == code) {
                    if (down) {
                        if (comboOk(b)) startTurbo(b)
                    } else stopTurbo(b)
                }
                T.DOUBLE -> if (b.keys[0] == code && down && comboOk(b)) doubleTap(b)
                T.SWIPE -> if (b.keys[0] == code && down && comboOk(b)) swipe(b)
                T.SEQ -> if (b.keys[0] == code && down && comboOk(b)) startSeq(b)
                T.SCRIPT -> if (b.keys[0] == code && down && comboOk(b)) ScriptHost.run(b)
                T.JOYSTICK -> {
                    val i = b.keys.indexOf(code)
                    if (i in 0..3) {
                        val k = held.getOrPut(b.id) { BooleanArray(4) }
                        k[i] = down
                        updateJoystick(b)
                    }
                }
            }
        }
    }

    // ---------- joystick ----------
    private fun updateJoystick(b: Binding) {
        val k = held[b.id] ?: return
        val sx = (if (k[3]) 1 else 0) - (if (k[1]) 1 else 0)
        val sy = (if (k[2]) 1 else 0) - (if (k[0]) 1 else 0)
        val len = sqrt((sx * sx + sy * sy).toFloat())
        val tx = if (len == 0f) 0f else sx / len
        val ty = if (len == 0f) 0f else sy / len
        if (b.jstyle == JS.ANALOG) {
            val st = joyState.getOrPut(b.id) { FloatArray(4) }
            st[2] = tx
            st[3] = ty
            if (!joyOn) {
                joyOn = true
                h.post(joyLoop)
            }
            return
        }
        if (len == 0f) {
            release(b)
            joyDir.remove(b.id)
            return
        }
        val rad = b.r * min(sw, sh) * (if (b.jstyle == JS.EDGE) 1.3f else 1f)
        val cx = b.x * sw
        val cy = b.y * sh
        val px = cx + tx * rad
        val py = cy + ty * rad
        val dirKey = (sx + 1) * 3 + (sy + 1)
        val id = ptr[b.id]
        if (id == null) {
            val n = alloc(b) ?: return
            ptr[b.id] = n
            if (b.jstyle == JS.DIRECT) {
                send(n, 0, px, py)
            } else {
                send(n, 0, cx, cy)
                send(n, 2, px, py)
            }
            joyDir[b.id] = dirKey
        } else if (b.jstyle == JS.FLOAT && joyDir[b.id] != dirKey) {
            send(id, 1, lx[id], ly[id])
            send(id, 0, cx, cy)
            send(id, 2, px, py)
            joyDir[b.id] = dirKey
        } else {
            send(id, 2, px, py)
            joyDir[b.id] = dirKey
        }
    }

    private fun approach(cur: Float, tgt: Float, step: Float): Float =
        if (cur < tgt) min(cur + step, tgt) else max(cur - step, tgt)

    /** Joystick analógico: el dedo crece/decrece de forma gradual (rampa de ~140 ms). */
    private val joyLoop = object : Runnable {
        override fun run() {
            val p = profile
            if (p == null || !active) {
                joyOn = false
                return
            }
            var any = false
            val minS = min(sw, sh).toFloat()
            val step = 16f / 140f
            for (b in p.bindings) {
                if (b.type != T.JOYSTICK || b.jstyle != JS.ANALOG) continue
                val st = joyState[b.id] ?: continue
                st[0] = approach(st[0], st[2], step)
                st[1] = approach(st[1], st[3], step)
                val mag = sqrt(st[0] * st[0] + st[1] * st[1])
                val id = ptr[b.id]
                if (mag < 0.02f && st[2] == 0f && st[3] == 0f) {
                    if (id != null) release(b)
                    continue
                }
                any = true
                val cx = b.x * sw
                val cy = b.y * sh
                val rad = b.r * minS
                val scale = if (mag > 1f) 1f / mag else 1f
                val px = cx + st[0] * scale * rad
                val py = cy + st[1] * scale * rad
                if (id == null) {
                    val n = alloc(b) ?: continue
                    ptr[b.id] = n
                    send(n, 0, cx, cy)
                    send(n, 2, px, py)
                } else {
                    send(id, 2, px, py)
                }
            }
            if (any) h.postDelayed(this, 16) else joyOn = false
        }
    }

    // ---------- cámara ----------
    /** Bucle de cámara a la frecuencia del perfil: reparte el movimiento acumulado en pasos regulares. */
    private val camLoop = object : Runnable {
        override fun run() {
            val p = profile
            if (p == null || !active || !captured || cursorMode) {
                camRunning.set(false)
                camRelease()
                return
            }
            val iv = (1000 / p.camHz.coerceIn(30, 1000)).coerceAtLeast(1).toLong()
            var rx = 0f
            var ry = 0f
            synchronized(lock) {
                rx = accDx
                ry = accDy
            }
            // Suavizado sin perder movimiento: cada paso aplica una fracción de lo pendiente.
            val k = 1f - p.smooth.coerceIn(0f, 0.95f)
            var ax = rx * k
            var ay = ry * k
            if (abs(rx) < 0.4f) ax = rx
            if (abs(ry) < 0.4f) ay = ry
            if (ax != 0f || ay != 0f) {
                synchronized(lock) {
                    accDx -= ax
                    accDy -= ay
                }
                moveCamera(p, ax, ay)
                lastMove = SystemClock.uptimeMillis()
            }
            val pending = synchronized(lock) { abs(accDx) > 0.001f || abs(accDy) > 0.001f }
            if (!pending && camId >= 0 && SystemClock.uptimeMillis() - lastMove > 300) camRelease()
            if (!pending && camId < 0) {
                camRunning.set(false)
                val again = synchronized(lock) { abs(accDx) > 0.001f || abs(accDy) > 0.001f }
                if (again && camRunning.compareAndSet(false, true)) h.postDelayed(this, iv)
                return
            }
            h.postDelayed(this, iv)
        }
    }

    private fun moveCamera(p: Profile, dx: Float, dy: Float) {
        val cam = p.bindings.firstOrNull { it.type == T.CAMERA } ?: return
        val cx = cam.x * sw
        val cy = cam.y * sh
        val half = cam.r * min(sw, sh)
        if (half <= 0f) return
        if (camId < 0) {
            val n = alloc(cam) ?: return
            camId = n
            camX = cx
            camY = cy
            send(camId, 0, camX, camY)
        }
        val speed = sqrt(dx * dx + dy * dy)
        val acc = 1f + p.accel * min(speed / 8f, 3f)
        val ads = if (adsHeld) p.adsMult else 1f
        camX += dx * p.sensX * acc * ads
        camY += dy * p.sensY * acc * ads * (if (p.invertY) -1f else 1f)
        if (abs(camX - cx) > half || abs(camY - cy) > half) {
            // Al llegar al borde: levantar y volver a apoyar en el centro, conservando el sobrante.
            val tx = camX.coerceIn(cx - half, cx + half)
            val ty = camY.coerceIn(cy - half, cy + half)
            val ox = (camX - tx).coerceIn(-half, half)
            val oy = (camY - ty).coerceIn(-half, half)
            send(camId, 2, tx, ty)
            send(camId, 1, tx, ty)
            send(camId, 0, cx, cy)
            camX = cx + ox
            camY = cy + oy
        }
        send(camId, 2, camX, camY)
    }

    private fun camRelease() {
        if (camId >= 0) {
            send(camId, 1, lx[camId], ly[camId])
            used[camId] = false
            camId = -1
        }
    }

    // ---------- cursor virtual ----------
    private val curLoop = object : Runnable {
        override fun run() {
            if (!active || !captured || !cursorMode) {
                curRunning.set(false)
                return
            }
            val iv = (1000 / AppSettings.cursorHz.coerceIn(30, 1000)).coerceAtLeast(1).toLong()
            var dx = 0f
            var dy = 0f
            synchronized(lock) {
                dx = curAccX
                dy = curAccY
                curAccX = 0f
                curAccY = 0f
            }
            if (dx != 0f || dy != 0f) {
                val s = AppSettings.cursorSens
                cursorX = (cursorX + dx * s).coerceIn(0f, (sw - 1).toFloat())
                cursorY = (cursorY + dy * s).coerceIn(0f, (sh - 1).toFloat())
                if (curId >= 0) send(curId, 2, cursorX, cursorY)
            }
            val pending = synchronized(lock) { curAccX != 0f || curAccY != 0f }
            if (!pending) {
                curRunning.set(false)
                val again = synchronized(lock) { curAccX != 0f || curAccY != 0f }
                if (again && curRunning.compareAndSet(false, true)) h.postDelayed(this, iv)
                return
            }
            h.postDelayed(this, iv)
        }
    }

    /** El clic izquierdo del cursor virtual actúa como un dedo en esa posición. */
    private fun cursorClick(down: Boolean) {
        if (down) {
            if (curId >= 0) return
            if (used[9]) return
            used[9] = true
            curId = 9
            send(9, 0, cursorX, cursorY)
        } else if (curId >= 0) {
            send(curId, 1, lx[curId], ly[curId])
            used[curId] = false
            curId = -1
        }
    }

    private fun mouseRelease() {
        val p = profile ?: return
        for (b in p.bindings) {
            if (b.type != T.JOYSTICK && b.keys[0] < 0) stopTurbo(b)
        }
    }

    private fun releaseAll() {
        h.removeCallbacksAndMessages(null)
        camRunning.set(false)
        curRunning.set(false)
        synchronized(lock) {
            accDx = 0f
            accDy = 0f
            curAccX = 0f
            curAccY = 0f
        }
        seqRun.clear()
        turbo.clear()
        joyState.clear()
        joyDir.clear()
        joyOn = false
        adsHeld = false
        mods = 0
        pressed.clear()
        cursorMode = false
        camRelease()
        cursorClick(false)
        for ((_, id) in ptr) {
            send(id, 1, lx[id], ly[id])
            used[id] = false
        }
        ptr.clear()
        held.clear()
        ShizukuManager.releaseAll()
    }
}
