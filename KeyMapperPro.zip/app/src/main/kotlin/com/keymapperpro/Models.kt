package com.keymapperpro

import android.content.Context
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

object T {
    const val TAP = "TAP"           // mantiene el toque mientras la tecla está pulsada
    const val CLICK = "CLICK"       // toque breve al pulsar
    const val TURBO = "TURBO"       // toques repetidos mientras la tecla está pulsada
    const val JOYSTICK = "JOYSTICK" // 4 teclas: arriba, izquierda, abajo, derecha
    const val CAMERA = "CAMERA"     // movimiento del mouse -> arrastre de cámara
    const val FIRE = "FIRE"         // botón de disparo (clic izquierdo)
    const val DOUBLE = "DOUBLE"     // doble toque al pulsar
    const val SWIPE = "SWIPE"       // deslizamiento de (x,y) a (x2,y2) al pulsar
    const val SEQ = "SEQ"           // macro: n toques repetidos cada ms milisegundos
}

/** Posición x,y en proporción 0..1 de la pantalla. r es proporción del lado menor de la pantalla. */
class Binding(
    var id: String,
    var type: String,
    var x: Float,
    var y: Float,
    var r: Float,
    var keys: MutableList<Int> = mutableListOf(0, 0, 0, 0),
    var x2: Float = 0.6f,
    var y2: Float = 0.5f,
    var n: Int = 3,
    var ms: Int = 120,
    var mod: Int = 0 // combinación: 1 = Ctrl, 2 = Shift, 4 = Alt
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("type", type)
        .put("x", x.toDouble())
        .put("y", y.toDouble())
        .put("r", r.toDouble())
        .put("keys", JSONArray(keys))
        .put("x2", x2.toDouble())
        .put("y2", y2.toDouble())
        .put("n", n)
        .put("ms", ms)
        .put("mod", mod)

    companion object {
        fun fromJson(o: JSONObject): Binding {
            val ka = o.optJSONArray("keys")
            val keys = mutableListOf(0, 0, 0, 0)
            if (ka != null) {
                for (i in 0 until minOf(4, ka.length())) keys[i] = ka.optInt(i, 0)
            }
            return Binding(
                o.optString("id", UUID.randomUUID().toString()),
                o.optString("type", T.TAP),
                o.optDouble("x", 0.5).toFloat(),
                o.optDouble("y", 0.5).toFloat(),
                o.optDouble("r", 0.06).toFloat(),
                keys,
                o.optDouble("x2", 0.6).toFloat(),
                o.optDouble("y2", 0.5).toFloat(),
                o.optInt("n", 3),
                o.optInt("ms", 120),
                o.optInt("mod", 0)
            )
        }
    }
}

class Profile(var pkg: String, var name: String, var bindings: MutableList<Binding>) {
    var sensX = 2.0f
    var sensY = 2.0f
    var invertY = false
    var autoCapture = true
    var joyDirect = true
    var toggleKey = KeyEvent.KEYCODE_F1
    var accel = 0f      // aceleración del mouse 0..1
    var smooth = 0f     // suavizado 0..0.9
    var adsMult = 0.5f  // multiplicador de sensibilidad mientras se mantiene la tecla de mira
    var adsKey = Keys.MOUSE_RIGHT

    fun toJson(): JSONObject {
        val arr = JSONArray()
        bindings.forEach { arr.put(it.toJson()) }
        return JSONObject()
            .put("pkg", pkg)
            .put("name", name)
            .put("sensX", sensX.toDouble())
            .put("sensY", sensY.toDouble())
            .put("invertY", invertY)
            .put("autoCapture", autoCapture)
            .put("joyDirect", joyDirect)
            .put("toggleKey", toggleKey)
            .put("accel", accel.toDouble())
            .put("smooth", smooth.toDouble())
            .put("adsMult", adsMult.toDouble())
            .put("adsKey", adsKey)
            .put("bindings", arr)
    }

    companion object {
        fun fromJson(o: JSONObject): Profile {
            val list = mutableListOf<Binding>()
            val arr = o.optJSONArray("bindings")
            if (arr != null) {
                for (i in 0 until arr.length()) list.add(Binding.fromJson(arr.getJSONObject(i)))
            }
            val p = Profile(o.optString("pkg", ""), o.optString("name", "Perfil"), list)
            p.sensX = o.optDouble("sensX", 2.0).toFloat()
            p.sensY = o.optDouble("sensY", 2.0).toFloat()
            p.invertY = o.optBoolean("invertY", false)
            p.autoCapture = o.optBoolean("autoCapture", true)
            p.joyDirect = o.optBoolean("joyDirect", true)
            p.toggleKey = o.optInt("toggleKey", KeyEvent.KEYCODE_F1)
            p.accel = o.optDouble("accel", 0.0).toFloat()
            p.smooth = o.optDouble("smooth", 0.0).toFloat()
            p.adsMult = o.optDouble("adsMult", 0.5).toFloat()
            p.adsKey = o.optInt("adsKey", Keys.MOUSE_RIGHT)
            return p
        }
    }
}

object ProfileStore {
    private fun dir(c: Context): File = File(c.filesDir, "profiles").apply { mkdirs() }

    fun load(c: Context, pkg: String): Profile {
        val f = File(dir(c), "$pkg.json")
        if (f.exists()) {
            try {
                val p = Profile.fromJson(JSONObject(f.readText()))
                p.pkg = pkg
                return p
            } catch (e: Exception) {
                // perfil dañado: se usa el preset
            }
        }
        return defaultProfile(pkg)
    }

    fun save(c: Context, p: Profile) {
        try {
            File(dir(c), "${p.pkg}.json").writeText(p.toJson().toString())
        } catch (e: Exception) {
        }
    }

    fun library(c: Context): MutableList<String> {
        val s = c.getSharedPreferences("km", Context.MODE_PRIVATE).getString("lib", "[]") ?: "[]"
        val out = mutableListOf<String>()
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) {
        }
        return out
    }

    private fun saveLibrary(c: Context, l: List<String>) {
        c.getSharedPreferences("km", Context.MODE_PRIVATE).edit()
            .putString("lib", JSONArray(l).toString()).apply()
    }

    fun addGame(c: Context, pkg: String) {
        val l = library(c)
        if (!l.contains(pkg)) {
            l.add(pkg)
            saveLibrary(c, l)
        }
    }

    fun removeGame(c: Context, pkg: String) {
        val l = library(c)
        l.remove(pkg)
        saveLibrary(c, l)
        File(dir(c), "$pkg.json").delete()
    }

    /** Perfil nuevo: vacío. Los controles se crean con el editor (engranaje durante el juego o tecla F2). */
    fun defaultProfile(pkg: String): Profile = Profile(pkg, "Perfil", mutableListOf())
}
