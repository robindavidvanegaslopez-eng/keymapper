package com.keymapperpro

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View

/**
 * Ventana transparente que recibe el teclado y el mouse mientras el juego está en primer plano.
 * No es "tocable": los toques pasan al juego. Con captura de puntero activa, el mouse entrega
 * movimiento relativo (cámara) y se oculta el cursor.
 */
class InputOverlayView(ctx: Context, private val onEdit: () -> Unit) : View(ctx) {
    var captured = false
        private set
    private var wantCapture = false
    private var lastButtons = 0
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        setOnCapturedPointerListener { _, e ->
            handleCaptured(e)
            true
        }
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density

    fun setCapture(on: Boolean) {
        wantCapture = on
        if (on) {
            if (hasWindowFocus()) requestPointerCapture()
        } else {
            releasePointerCapture()
            captured = false
            MappingEngine.setCaptured(false)
            invalidate()
        }
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus) {
            requestFocus()
            if (wantCapture) requestPointerCapture()
        }
    }

    override fun onPointerCaptureChange(hasCapture: Boolean) {
        super.onPointerCaptureChange(hasCapture)
        captured = hasCapture
        MappingEngine.setCaptured(hasCapture)
        if (!hasCapture) lastButtons = 0
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        MappingEngine.setScreen(w, h)
    }

    private fun handleCaptured(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_HOVER_MOVE ->
                MappingEngine.onMouseDelta(e.x, e.y)
            MotionEvent.ACTION_SCROLL -> {
                val v = e.getAxisValue(MotionEvent.AXIS_VSCROLL)
                if (v != 0f) {
                    val code = if (v > 0) Keys.WHEEL_UP else Keys.WHEEL_DOWN
                    MappingEngine.onKey(code, true)
                    MappingEngine.onKey(code, false)
                }
            }
        }
        val b = e.buttonState
        val changed = b xor lastButtons
        fun chk(mask: Int, code: Int) {
            if ((changed and mask) != 0) MappingEngine.onKey(code, (b and mask) != 0)
        }
        chk(MotionEvent.BUTTON_PRIMARY, Keys.MOUSE_LEFT)
        chk(MotionEvent.BUTTON_SECONDARY, Keys.MOUSE_RIGHT)
        chk(MotionEvent.BUTTON_TERTIARY, Keys.MOUSE_MIDDLE)
        lastButtons = b
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME) {
            return super.onKeyDown(keyCode, event)
        }
        if (event.repeatCount > 0) return true
        val toggle = MappingEngine.profile?.toggleKey ?: KeyEvent.KEYCODE_F1
        if (keyCode == toggle) {
            setCapture(!captured)
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_ESCAPE && captured) {
            setCapture(false)
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_F2) {
            onEdit()
            return true
        }
        MappingEngine.onKey(keyCode, true)
        return true
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME) {
            return super.onKeyUp(keyCode, event)
        }
        val toggle = MappingEngine.profile?.toggleKey ?: KeyEvent.KEYCODE_F1
        if (keyCode == toggle || keyCode == KeyEvent.KEYCODE_ESCAPE || keyCode == KeyEvent.KEYCODE_F2) return true
        MappingEngine.onKey(keyCode, false)
        return true
    }

    override fun onDraw(canvas: Canvas) {
        paint.color = if (captured) 0xFFE53935.toInt() else 0xFF43A047.toInt()
        canvas.drawCircle(dp(14f), dp(14f), dp(5f), paint)
    }
}
