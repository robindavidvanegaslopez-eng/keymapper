package com.keymapperpro

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View

/**
 * Ventana transparente que recibe el teclado y el mouse mientras el juego está en primer plano.
 * No es "tocable": los toques pasan al juego. Con captura de puntero activa, el mouse entrega
 * movimiento relativo (cámara o cursor virtual) y se oculta el cursor del sistema.
 * No dibuja nada salvo, si está activado, el HUD de controles y el cursor virtual.
 */
class InputOverlayView(ctx: Context, private val onMenu: () -> Unit) : View(ctx) {
    var captured = false
        private set
    private var wantCapture = false
    private var lastButtons = 0
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        setOnCapturedPointerListener { _, e ->
            handleCaptured(e)
            true
        }
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density

    fun setCapture(on: Boolean) {
        wantCapture = on
        if (on) {
            if (hasWindowFocus()) requestPointerCapture()
        } else {
            releasePointerCapture()
            captured = false
            MappingEngine.setCaptured(false)
            invalidate()
        }
    }

    fun toggleCursor() {
        val on = !MappingEngine.cursorMode
        if (on && !captured) setCapture(true)
        MappingEngine.setCursorMode(on)
        invalidate()
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus) {
            requestFocus()
            if (wantCapture) requestPointerCapture()
        }
    }

    override fun onPointerCaptureChange(hasCapture: Boolean) {
        super.onPointerCaptureChange(hasCapture)
        captured = hasCapture
        MappingEngine.setCaptured(hasCapture)
        if (!hasCapture) lastButtons = 0
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        MappingEngine.setScreen(w, h)
    }

    private fun handleCaptured(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_HOVER_MOVE -> {
                // Android agrupa varios movimientos en un evento: hay que sumar también el historial.
                var dx = e.x
                var dy = e.y
                for (i in 0 until e.historySize) {
                    dx += e.getHistoricalX(i)
                    dy += e.getHistoricalY(i)
                }
                MappingEngine.onMouseDelta(dx, dy)
            }
            MotionEvent.ACTION_SCROLL -> {
                val v = e.getAxisValue(MotionEvent.AXIS_VSCROLL)
                if (v != 0f) {
                    val code = if (v > 0) Keys.WHEEL_UP else Keys.WHEEL_DOWN
                    MappingEngine.onKey(code, true)
                    MappingEngine.onKey(code, false)
                }
            }
        }
        val b = e.buttonState
        val changed = b xor lastButtons
        fun chk(mask: Int, code: Int) {
            if ((changed and mask) != 0) MappingEngine.onKey(code, (b and mask) != 0)
        }
        chk(MotionEvent.BUTTON_PRIMARY, Keys.MOUSE_LEFT)
        chk(MotionEvent.BUTTON_SECONDARY, Keys.MOUSE_RIGHT)
        chk(MotionEvent.BUTTON_TERTIARY, Keys.MOUSE_MIDDLE)
        lastButtons = b
    }

    private fun mods(e: KeyEvent): Int {
        var m = 0
        if (e.isCtrlPressed) m = m or 1
        if (e.isShiftPressed) m = m or 2
        if (e.isAltPressed) m = m or 4
        return m
    }

    private fun matches(code: Int, m: Int, key: Int, mod: Int): Boolean =
        code == key && (mod == 0 || (m and mod) == mod)

    private fun isHotKey(code: Int): Boolean =
        code == AppSettings.menuKey || code == AppSettings.captureKey || code == AppSettings.cursorKey

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME) {
            return super.onKeyDown(keyCode, event)
        }
        if (event.repeatCount > 0) return true
        val m = mods(event)
        if (matches(keyCode, m, AppSettings.menuKey, AppSettings.menuMod)) {
            onMenu()
            return true
        }
        if (matches(keyCode, m, AppSettings.captureKey, AppSettings.captureMod)) {
            setCapture(!captured)
            return true
        }
        if (matches(keyCode, m, AppSettings.cursorKey, AppSettings.cursorMod)) {
            toggleCursor()
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_ESCAPE && captured) {
            setCapture(false)
            return true
        }
        MappingEngine.onKey(keyCode, true)
        return true
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME) {
            return super.onKeyUp(keyCode, event)
        }
        if (isHotKey(keyCode) || keyCode == KeyEvent.KEYCODE_ESCAPE) return true
        MappingEngine.onKey(keyCode, false)
        return true
    }

    // ---------------- dibujo ----------------
    override fun onDraw(canvas: Canvas) {
        val p = MappingEngine.profile
        if (p != null && p.showHud) drawHud(canvas, p)
        if (captured && MappingEngine.cursorMode) {
            drawCursor(canvas)
            postInvalidateOnAnimation()
        }
    }

    private fun drawHud(c: Canvas, p: Profile) {
        val minS = minOf(width, height).toFloat()
        for (b in p.bindings) {
            val cx = b.x * width
            val cy = b.y * height
            val rad = b.r * minS
            paint.style = Paint.Style.FILL
            paint.color = Shapes.fill(b)
            if (b.type == T.CAMERA) {
                c.drawRect(cx - rad, cy - rad, cx + rad, cy + rad, paint)
            } else {
                Shapes.draw(c, b.shape, cx, cy, rad, paint)
            }
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(1.5f)
            paint.color = Shapes.stroke(b)
            if (b.type == T.CAMERA) {
                c.drawRect(cx - rad, cy - rad, cx + rad, cy + rad, paint)
            } else {
                Shapes.draw(c, b.shape, cx, cy, rad, paint)
            }
            if (b.type != T.CAMERA && b.type != T.JOYSTICK) {
                paint.style = Paint.Style.FILL
                paint.color = Shapes.stroke(b)
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = dp(12f)
                c.drawText(Keys.label(b), cx, cy + dp(4f), paint)
            }
        }
    }

    private fun drawCursor(c: Canvas) {
        val x = MappingEngine.cursorX
        val y = MappingEngine.cursorY
        val size = AppSettings.cursorSize * resources.displayMetrics.density
        val a = (AppSettings.cursorOpacity.coerceIn(0.1f, 1f) * 255).toInt()
        val fill = (AppSettings.cursorColor and 0x00FFFFFF) or (a shl 24)
        val line = (0x000000) or (a shl 24)
        val s = size / 19f
        paint.textAlign = Paint.Align.LEFT
        when (AppSettings.cursorStyle) {
            1 -> {
                paint.style = Paint.Style.FILL
                paint.color = fill
                c.drawCircle(x, y, size / 3f, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = maxOf(1f, s)
                paint.color = line
                c.drawCircle(x, y, size / 3f, paint)
            }
            2 -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = maxOf(3f, s * 3f)
                paint.color = line
                c.drawLine(x - size / 2f, y, x + size / 2f, y, paint)
                c.drawLine(x, y - size / 2f, x, y + size / 2f, paint)
                paint.strokeWidth = maxOf(1.5f, s * 1.4f)
                paint.color = fill
                c.drawLine(x - size / 2f, y, x + size / 2f, y, paint)
                c.drawLine(x, y - size / 2f, x, y + size / 2f, paint)
            }
            else -> {
                // Flecha estándar de Windows 11 (relleno claro con borde oscuro).
                path.reset()
                path.moveTo(x, y)
                path.lineTo(x, y + 16f * s)
                path.lineTo(x + 3.6f * s, y + 12.6f * s)
                path.lineTo(x + 6.2f * s, y + 18.4f * s)
                path.lineTo(x + 8.6f * s, y + 17.4f * s)
                path.lineTo(x + 6.1f * s, y + 11.8f * s)
                path.lineTo(x + 11f * s, y + 11.8f * s)
                path.close()
                paint.style = Paint.Style.FILL
                paint.color = fill
                c.drawPath(path, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = maxOf(1f, s * 1.1f)
                paint.color = line
                c.drawPath(path, paint)
            }
        }
    }
}
