package com.keymapperpro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast

/**
 * Servicio en primer plano: vigila qué app está al frente.
 * Mientras el juego lanzado esté en primer plano, muestra el overlay y mapea.
 * Al salir del juego, quita el overlay, suelta todos los toques y se detiene solo.
 */
class MapperService : Service() {
    companion object {
        const val ACTION_PLAY = "com.keymapperpro.PLAY"
        const val ACTION_EDIT = "com.keymapperpro.EDIT"
        const val ACTION_STOP = "com.keymapperpro.STOP"
        const val EXTRA_PKG = "pkg"
        private const val CHANNEL = "mapper"
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var pkg = ""
    private var editMode = false
    private var profile: Profile? = null
    private var inputView: InputOverlayView? = null
    private var editorView: EditorView? = null
    private var current: String? = null
    private var lastQuery = 0L
    private var seenGame = false
    private var awayTicks = 0
    private var startedAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Mapeo activo", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent.action) {
            ACTION_STOP -> shutdown()
            ACTION_PLAY, ACTION_EDIT -> {
                startFg()
                val p = intent.getStringExtra(EXTRA_PKG) ?: ""
                if (p.isEmpty()) {
                    shutdown()
                    return START_NOT_STICKY
                }
                teardownViews()
                pkg = p
                editMode = intent.action == ACTION_EDIT
                profile = ProfileStore.load(this, pkg)
                seenGame = false
                awayTicks = 0
                current = null
                lastQuery = 0L
                startedAt = SystemClock.uptimeMillis()
                main.removeCallbacks(tick)
                main.post(tick)
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, MapperService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("KeyMapper Pro")
            .setContentText("Mapeo activo mientras el juego esté abierto")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Detener", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            poll()
            val fg = current
            if (fg == pkg) {
                awayTicks = 0
                seenGame = true
                ensureViews()
            } else {
                if (seenGame && fg != null && fg != "com.android.systemui") {
                    teardownViews()
                    awayTicks++
                    if (awayTicks >= 8) {
                        shutdown()
                        return
                    }
                }
                if (!seenGame && SystemClock.uptimeMillis() - startedAt > 20000) {
                    Toast.makeText(
                        this@MapperService,
                        "No se detectó el juego en primer plano. Revisa los permisos en Configuración.",
                        Toast.LENGTH_LONG
                    ).show()
                    shutdown()
                    return
                }
            }
            main.postDelayed(this, 400)
        }
    }

    /** Lee los eventos de uso para saber qué app está al frente (1 = reanudada, 2 = pausada). */
    private fun poll() {
        try {
            val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val from = if (lastQuery == 0L) now - 60000 else lastQuery - 1000
            val ev = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                when (e.eventType) {
                    1 -> current = e.packageName
                    2 -> if (current == e.packageName) current = null
                }
            }
            lastQuery = now
        } catch (t: Throwable) {
        }
    }

    private fun overlayParams(touchable: Boolean): WindowManager.LayoutParams {
        val flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        // Por debajo de 0.8 los toques atraviesan la ventana sin ser bloqueados (Android 12+).
        lp.alpha = if (touchable) 1f else 0.75f
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun ensureViews() {
        if (!Settings.canDrawOverlays(this)) return
        val p = profile ?: return
        try {
            if (editMode) {
                if (editorView == null) {
                    val v = EditorView(
                        this, p,
                        onSave = {
                            ProfileStore.save(this, p)
                            shutdown()
                        },
                        onCancel = { shutdown() }
                    )
                    wm.addView(v, overlayParams(true))
                    editorView = v
                    v.post { v.requestFocus() }
                }
            } else if (inputView == null) {
                val v = InputOverlayView(this)
                MappingEngine.start(p)
                wm.addView(v, overlayParams(false))
                inputView = v
                v.post {
                    v.requestFocus()
                    if (p.autoCapture) v.setCapture(true)
                }
            }
        } catch (t: Throwable) {
            Toast.makeText(this, "No se pudo mostrar el overlay: ${t.message}", Toast.LENGTH_LONG).show()
            shutdown()
        }
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try {
            wm.removeView(v)
        } catch (t: Throwable) {
        }
    }

    private fun teardownViews() {
        if (inputView != null || editorView != null) {
            removeView(inputView)
            removeView(editorView)
            inputView = null
            editorView = null
        }
        MappingEngine.stop()
    }

    private fun shutdown() {
        main.removeCallbacks(tick)
        teardownViews()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        main.removeCallbacks(tick)
        teardownViews()
        super.onDestroy()
    }
}
