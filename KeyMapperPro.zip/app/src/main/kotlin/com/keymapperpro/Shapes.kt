package com.keymapperpro

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.cos
import kotlin.math.sin

/** Formas disponibles para los controles y utilidades de color. */
object Shapes {
    val names = listOf("Círculo", "Cuadrado", "Redondeado", "Rombo", "Hexágono")
    private val path = Path()

    fun draw(c: Canvas, shape: Int, cx: Float, cy: Float, r: Float, p: Paint) {
        when (shape) {
            1 -> c.drawRect(cx - r, cy - r, cx + r, cy + r, p)
            2 -> c.drawRoundRect(cx - r, cy - r, cx + r, cy + r, r * 0.35f, r * 0.35f, p)
            3 -> {
                path.reset()
                path.moveTo(cx, cy - r)
                path.lineTo(cx + r, cy)
                path.lineTo(cx, cy + r)
                path.lineTo(cx - r, cy)
                path.close()
                c.drawPath(path, p)
            }
            4 -> {
                path.reset()
                for (i in 0 until 6) {
                    val a = Math.PI / 3 * i + Math.PI / 6
                    val x = cx + (r * cos(a)).toFloat()
                    val y = cy + (r * sin(a)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                c.drawPath(path, p)
            }
            else -> c.drawCircle(cx, cy, r, p)
        }
    }

    /** Color del control con su opacidad (0..100). */
    fun fill(b: Binding): Int {
        val a = (b.opacity.coerceIn(0, 100) * 255 / 100) and 0xFF
        return (b.color and 0x00FFFFFF) or (a shl 24)
    }

    fun stroke(b: Binding): Int {
        val a = ((b.opacity.coerceIn(0, 100) * 255 / 100) + 90).coerceAtMost(255)
        return (b.color and 0x00FFFFFF) or (a shl 24)
    }
}

/** Punto de enlace para los scripts de los botones. Aún no hay ningún lenguaje integrado. */
object ScriptHost {
    fun run(b: Binding) {
        // Pendiente: aquí se interpretará b.script cuando se defina el lenguaje.
    }
}
