package com.keymapperpro

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.util.UUID
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Editor de controles que se dibuja encima del juego.
 * Barra superior: Añadir (menú desplegable), HUD, Guardar, Cancelar.
 * Al seleccionar un control aparece un engranaje en su esquina que abre su panel de opciones:
 * tipo (desplegable), teclas y combinaciones, estilo de joystick, forma, color, opacidad,
 * tamaño en píxeles y opciones propias de cada tipo (cámara, deslizar, macro, script).
 */
class EditorView(
    ctx: Context,
    private val profile: Profile,
    private val onSave: () -> Unit,
    private val onCancel: () -> Unit
) : FrameLayout(ctx) {

    private class Btn(val label: () -> String, val action: () -> Unit) {
        val rect = RectF()
    }

    private val typeNames = listOf(
        "Presionar (mantener)", "Tocar (breve)", "Turbo", "Doble toque", "Deslizar",
        "Macro", "Script", "Joystick", "Cámara", "Disparo"
    )
    private val typeIds = listOf(
        T.TAP, T.CLICK, T.TURBO, T.DOUBLE, T.SWIPE, T.SEQ, T.SCRIPT, T.JOYSTICK, T.CAMERA, T.FIRE
    )
    private val hzValues = listOf(60, 90, 125, 250, 500, 1000)

    private val accent get() = AppSettings.accent
    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
    }
    private val tctx = ContextThemeWrapper(ctx, android.R.style.Theme_DeviceDefault)

    private var sel: Binding? = null
    private var dragging = false
    private var dragEnd = false
    private var awaiting = 0
    private var assignIdx = 0
    private var topH = 0f
    private var addOpen = false
    private val gearRect = RectF()
    private var panel: ScrollView? = null
    private val topBtns = ArrayList<Btn>()
    private val addBtns = ArrayList<Btn>()
    private lateinit var btnAdd: Btn

    init {
        setWillNotDraw(false)
        isFocusable = true
        isFocusableInTouchMode = true
        btnAdd = Btn({ "+ Añadir ▾" }) {
            addOpen = !addOpen
            invalidate()
        }
        topBtns.add(btnAdd)
        topBtns.add(Btn({ if (profile.showHud) "HUD en juego: Sí" else "HUD en juego: No" }) {
            profile.showHud = !profile.showHud
            invalidate()
        })
        topBtns.add(Btn({ "Guardar" }) { onSave() })
        topBtns.add(Btn({ "Cancelar" }) { onCancel() })
        for (i in typeIds.indices) {
            addBtns.add(Btn({ typeNames[i] }) { addBinding(typeIds[i]) })
        }
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
    private fun dpi(v: Float) = dp(v).toInt()

    // ---------------- lógica ----------------
    private fun addBinding(type: String) {
        closePanel()
        addOpen = false
        val r = when (type) {
            T.JOYSTICK -> 0.10f
            T.CAMERA -> 0.30f
            T.FIRE -> 0.07f
            else -> 0.05f
        }
        val b = Binding(UUID.randomUUID().toString(), type, 0.5f, 0.5f, r, mutableListOf(0, 0, 0, 0))
        if (type == T.FIRE) {
            b.keys[0] = Keys.MOUSE_LEFT
            b.color = 0xFFE53935.toInt()
            b.opacity = 55
        }
        if (type == T.JOYSTICK) b.opacity = 25
        profile.bindings.add(b)
        sel = b
        startAssign(b, 0, if (type == T.JOYSTICK) 4 else if (type == T.CAMERA || type == T.FIRE) 0 else 1)
        if (awaiting == 0) openPanel()
        invalidate()
    }

    private fun startAssign(b: Binding, from: Int, count: Int) {
        closePanel()
        assignIdx = from
        awaiting = count
        invalidate()
    }

    private fun assign(code: Int) {
        val b = sel ?: return
        if (awaiting <= 0) return
        b.keys[assignIdx] = code
        assignIdx++
        awaiting--
        if (awaiting == 0) openPanel()
        invalidate()
    }

    private fun applyType(b: Binding, idx: Int) {
        val nt = typeIds[idx]
        if (b.type == T.JOYSTICK && nt != T.JOYSTICK) {
            b.keys[1] = 0
            b.keys[2] = 0
            b.keys[3] = 0
        }
        b.type = nt
        if (nt == T.FIRE && b.keys[0] == 0) b.keys[0] = Keys.MOUSE_LEFT
        if (nt == T.JOYSTICK && b.r < 0.08f) b.r = 0.10f
        if (nt == T.CAMERA && b.r < 0.15f) b.r = 0.30f
        refreshPanel()
        invalidate()
    }

    private fun deleteSel() {
        val b = sel ?: return
        profile.bindings.remove(b)
        sel = null
        awaiting = 0
        closePanel()
        invalidate()
    }

    private fun bindingAt(x: Float, y: Float): Binding? {
        val minS = min(width, height).toFloat()
        for (i in profile.bindings.indices.reversed()) {
            val b = profile.bindings[i]
            val cx = b.x * width
            val cy = b.y * height
            val rad = b.r * minS
            val hit = if (b.type == T.CAMERA) {
                kotlin.math.abs(x - cx) <= rad && kotlin.math.abs(y - cy) <= rad
            } else {
                hypot(x - cx, y - cy) <= maxOf(rad, dp(24f))
            }
            if (hit) return b
        }
        return null
    }

    // ---------------- widgets del panel ----------------
    private fun label(t: String): TextView = TextView(tctx).apply {
        text = t
        setTextColor(Color.WHITE)
        textSize = 13f
        setPadding(0, dpi(8f), 0, dpi(2f))
    }

    private fun note(t: String): TextView = TextView(tctx).apply {
        text = t
        setTextColor(0xFFAAAAAA.toInt())
        textSize = 11.5f
        setPadding(0, dpi(2f), 0, dpi(2f))
    }

    private fun btn(t: String, on: Boolean, click: () -> Unit): Button = Button(tctx).apply {
        text = t
        setAllCaps(false)
        textSize = 12f
        setTextColor(Color.WHITE)
        minHeight = 0
        minimumHeight = 0
        minWidth = 0
        minimumWidth = 0
        setPadding(dpi(8f), dpi(6f), dpi(8f), dpi(6f))
        background = GradientDrawable().apply {
            setColor(if (on) accent else 0xFF2A2A2A.toInt())
            cornerRadius = dp(8f)
        }
        isFocusable = false
        setOnClickListener { click() }
    }

    private fun row(vararg v: View): LinearLayout = LinearLayout(tctx).apply {
        orientation = LinearLayout.HORIZONTAL
        for (x in v) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dpi(2f), dpi(2f), dpi(2f), dpi(2f))
            addView(x, lp)
        }
    }

    /** Menú desplegable en línea (no usa ventanas emergentes, así funciona sobre cualquier juego). */
    private fun dropdown(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit): View {
        val box = LinearLayout(tctx)
        box.orientation = LinearLayout.VERTICAL
        val list = LinearLayout(tctx)
        list.orientation = LinearLayout.VERTICAL
        list.visibility = View.GONE
        val name = options.getOrElse(selected) { "" }
        val head = btn("$title: $name  ▾", false) {
            list.visibility = if (list.visibility == View.GONE) View.VISIBLE else View.GONE
        }
        box.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        options.forEachIndexed { i, n ->
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dpi(2f)
            list.addView(btn(n, i == selected) { onSelect(i) }, lp)
        }
        box.addView(list)
        return box
    }

    private fun slider(
        title: String, lo: Float, hi: Float, value: Float,
        fmt: (Float) -> String, onChange: (Float) -> Unit
    ): View {
        val box = LinearLayout(tctx)
        box.orientation = LinearLayout.VERTICAL
        val tv = label("$title: ${fmt(value)}")
        val sb = SeekBar(tctx)
        sb.max = 1000
        sb.progress = (((value - lo) / (hi - lo)) * 1000f).toInt().coerceIn(0, 1000)
        sb.isFocusable = false
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val v = lo + (hi - lo) * p / 1000f
                onChange(v)
                tv.text = "$title: ${fmt(v)}"
                invalidate()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
        return box
    }

    /** Tamaño en píxeles: deslizador + ajuste fino (−10, −1, +1, +10). */
    private fun sizeControl(b: Binding): View {
        val minS = min(width, height).toFloat()
        val hiPx = (minS * 0.95f).toInt()
        val box = LinearLayout(tctx)
        box.orientation = LinearLayout.VERTICAL
        fun cur() = (b.r * minS * 2f).roundToInt()
        val tv = label("Tamaño: ${cur()} px")
        val sb = SeekBar(tctx)
        sb.max = hiPx - 20
        sb.progress = (cur() - 20).coerceIn(0, hiPx - 20)
        sb.isFocusable = false
        fun setPx(v: Int) {
            val c = v.coerceIn(20, hiPx)
            b.r = c / 2f / minS
            tv.text = "Tamaño: $c px"
            sb.progress = c - 20
            invalidate()
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) setPx(p + 20)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
        box.addView(
            row(
                btn("−10", false) { setPx(cur() - 10) },
                btn("−1", false) { setPx(cur() - 1) },
                btn("+1", false) { setPx(cur() + 1) },
                btn("+10", false) { setPx(cur() + 10) }
            )
        )
        return box
    }

    private fun colorPicker(b: Binding): View {
        val box = LinearLayout(tctx)
        box.orientation = LinearLayout.VERTICAL
        box.addView(label("Color"))
        val presets = listOf(
            0xFFFFFFFF, 0xFFE53935, 0xFFFF9800, 0xFFFFEB3B, 0xFF4CAF50,
            0xFF00BCD4, 0xFF2196F3, 0xFF9C27B0, 0xFFE91E63, 0xFF000000
        ).map { it.toInt() }
        for (part in listOf(presets.subList(0, 5), presets.subList(5, 10))) {
            val line = LinearLayout(tctx)
            line.orientation = LinearLayout.HORIZONTAL
            for (col in part) {
                val v = View(tctx)
                val chosen = (col and 0x00FFFFFF) == (b.color and 0x00FFFFFF)
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(col)
                    setStroke(dpi(if (chosen) 3f else 1f), if (chosen) Color.WHITE else 0xFF666666.toInt())
                }
                v.setOnClickListener {
                    b.color = col
                    refreshPanel()
                    invalidate()
                }
                val lp = LinearLayout.LayoutParams(dpi(34f), dpi(34f))
                lp.setMargins(dpi(4f), dpi(4f), dpi(4f), dpi(4f))
                line.addView(v, lp)
            }
            box.addView(line)
        }
        fun comp(name: String, shift: Int): View =
            slider(name, 0f, 255f, ((b.color shr shift) and 0xFF).toFloat(), { "${it.roundToInt()}" }) { v ->
                val iv = v.roundToInt().coerceIn(0, 255)
                b.color = (b.color and (0xFF shl shift).inv()) or (iv shl shift)
            }
        box.addView(comp("Rojo", 16))
        box.addView(comp("Verde", 8))
        box.addView(comp("Azul", 0))
        return box
    }

    private fun scriptBox(b: Binding): View {
        val et = EditText(tctx)
        et.setText(b.script)
        et.setTextColor(Color.WHITE)
        et.setHintTextColor(0xFF777777.toInt())
        et.hint = "// Escribe aquí tu script.\n// Todavía no hay un lenguaje integrado: el texto se guarda para cuando exista."
        et.textSize = 12f
        et.typeface = Typeface.MONOSPACE
        et.minLines = 7
        et.gravity = Gravity.TOP or Gravity.START
        et.setPadding(dpi(8f), dpi(8f), dpi(8f), dpi(8f))
        et.background = GradientDrawable().apply {
            setColor(0xFF1A1A1A.toInt())
            cornerRadius = dp(8f)
            setStroke(dpi(1f), 0xFF444444.toInt())
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                b.script = s?.toString() ?: ""
            }

            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b4: Int, c: Int) {}
        })
        return et
    }

    private fun build(col: LinearLayout, b: Binding) {
        val head = LinearLayout(tctx)
        head.orientation = LinearLayout.HORIZONTAL
        val t = TextView(tctx)
        t.text = "Opciones del control"
        t.setTextColor(Color.WHITE)
        t.textSize = 16f
        t.setTypeface(null, Typeface.BOLD)
        head.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(btn("✕", false) { closePanel() })
        col.addView(head)

        val ti = typeIds.indexOf(b.type).coerceAtLeast(0)
        col.addView(dropdown("Tipo", typeNames, ti) { applyType(b, it) })

        if (b.type != T.CAMERA) {
            val keyText = if (b.type == T.JOYSTICK) {
                "Teclas: " + b.keys.take(4).joinToString(" ") { Keys.name(it) }
            } else {
                "Tecla: " + Keys.label(b)
            }
            col.addView(label(keyText))
            col.addView(
                btn("Reasignar tecla", false) {
                    startAssign(b, 0, if (b.type == T.JOYSTICK) 4 else 1)
                }
            )
        }

        if (b.type != T.JOYSTICK && b.type != T.CAMERA) {
            col.addView(label("Combinación"))
            col.addView(
                row(
                    btn("Ctrl", (b.mod and 1) != 0) { b.mod = b.mod xor 1; refreshPanel(); invalidate() },
                    btn("Shift", (b.mod and 2) != 0) { b.mod = b.mod xor 2; refreshPanel(); invalidate() },
                    btn("Alt", (b.mod and 4) != 0) { b.mod = b.mod xor 4; refreshPanel(); invalidate() }
                )
            )
            col.addView(
                row(
                    btn(if (b.keys[1] == 0) "+ Tecla extra" else "Extra: " + Keys.name(b.keys[1]), b.keys[1] != 0) {
                        startAssign(b, 1, 1)
                    },
                    btn("Quitar extra", false) {
                        b.keys[1] = 0
                        refreshPanel()
                        invalidate()
                    }
                )
            )
            col.addView(note("La acción se activa al pulsar la tecla mientras mantienes las demás."))
        }

        if (b.type == T.JOYSTICK) {
            col.addView(dropdown("Estilo", JS.names, b.jstyle) { b.jstyle = it; refreshPanel() })
            col.addView(
                note(
                    when (b.jstyle) {
                        JS.DIRECT -> "Dedo directo en la dirección pulsada."
                        JS.CENTER -> "Apoya en el centro y desliza al borde (joystick fijo)."
                        JS.ANALOG -> "Crece de forma gradual hasta el borde (de caminar a correr)."
                        JS.EDGE -> "Como desde el centro, pero se pasa del borde para forzar correr."
                        else -> "Flotante: vuelve a apoyar en el centro al cambiar de dirección."
                    }
                )
            )
        }

        if (b.type != T.CAMERA) {
            col.addView(dropdown("Forma", Shapes.names, b.shape) { b.shape = it; refreshPanel(); invalidate() })
            col.addView(colorPicker(b))
            col.addView(slider("Opacidad", 0f, 100f, b.opacity.toFloat(), { "${it.roundToInt()} %" }) { b.opacity = it.roundToInt() })
        }

        col.addView(sizeControl(b))

        if (b.type == T.SWIPE) {
            col.addView(slider("Duración", 40f, 1500f, b.ms.toFloat(), { "${it.roundToInt()} ms" }) { b.ms = it.roundToInt() })
            col.addView(note("Arrastra el punto azul para fijar el destino."))
        }
        if (b.type == T.SEQ) {
            col.addView(slider("Repeticiones", 1f, 50f, b.n.toFloat(), { "${it.roundToInt()}" }) { b.n = it.roundToInt() })
            col.addView(slider("Retardo", 40f, 1000f, b.ms.toFloat(), { "${it.roundToInt()} ms" }) { b.ms = it.roundToInt() })
        }
        if (b.type == T.SCRIPT) {
            col.addView(label("Script"))
            col.addView(scriptBox(b))
        }
        if (b.type == T.CAMERA) {
            col.addView(slider("Sensibilidad X", 0.2f, 8f, profile.sensX, { "%.1f".format(it) }) { profile.sensX = it })
            col.addView(slider("Sensibilidad Y", 0.2f, 8f, profile.sensY, { "%.1f".format(it) }) { profile.sensY = it })
            col.addView(slider("Suavizado", 0f, 0.95f, profile.smooth, { "%.2f".format(it) }) { profile.smooth = it })
            col.addView(slider("Aceleración", 0f, 1f, profile.accel, { "%.2f".format(it) }) { profile.accel = it })
            col.addView(slider("Sens. al apuntar (clic der.)", 0.1f, 1.5f, profile.adsMult, { "x%.2f".format(it) }) { profile.adsMult = it })
            val hi = hzValues.indexOf(profile.camHz).let { if (it < 0) 2 else it }
            col.addView(dropdown("Frecuencia", hzValues.map { "$it Hz" }, hi) { profile.camHz = hzValues[it]; refreshPanel() })
            col.addView(
                btn(if (profile.invertY) "Invertir eje Y: Sí" else "Invertir eje Y: No", profile.invertY) {
                    profile.invertY = !profile.invertY
                    refreshPanel()
                }
            )
        }

        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dpi(14f)
        col.addView(btn("Eliminar control", true) { deleteSel() }, lp)
    }

    private fun openPanel() {
        closePanel()
        val b = sel ?: return
        if (height <= 0) return
        val sv = ScrollView(tctx)
        sv.isFocusable = false
        sv.background = GradientDrawable().apply {
            setColor(0xF0111111.toInt())
            cornerRadius = dp(14f)
            setStroke(dpi(1.5f), accent)
        }
        val col = LinearLayout(tctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dpi(12f), dpi(8f), dpi(12f), dpi(12f))
        sv.addView(col)
        build(col, b)
        val h = (height - topH - dpi(12f)).toInt().coerceAtLeast(dpi(120f))
        val side = if (b.x > 0.5f) Gravity.START else Gravity.END
        val lp = FrameLayout.LayoutParams(dpi(310f), h, side or Gravity.BOTTOM)
        lp.setMargins(dpi(6f), 0, dpi(6f), dpi(6f))
        addView(sv, lp)
        panel = sv
    }

    private fun refreshPanel() {
        val y = panel?.scrollY ?: 0
        openPanel()
        panel?.post { panel?.scrollY = y }
    }

    private fun closePanel() {
        panel?.let { removeView(it) }
        panel = null
        try {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(windowToken, 0)
        } catch (t: Throwable) {
        }
        requestFocus()
    }

    // ---------------- dibujo ----------------
    private fun layoutButtons() {
        val bh = dp(44f)
        val gap = dp(6f)
        val bw = dp(130f)
        var x = gap
        var y = gap
        for (b in topBtns) {
            if (x + bw > width - gap) {
                x = gap
                y += bh + gap
            }
            b.rect.set(x, y, x + bw, y + bh)
            x += bw + gap
        }
        topH = y + bh + gap
        if (addOpen) {
            val ax = btnAdd.rect.left
            var ay = btnAdd.rect.bottom + gap
            val iw = dp(210f)
            val ih = dp(38f)
            for (b in addBtns) {
                b.rect.set(ax, ay, ax + iw, ay + ih)
                ay += ih + dp(3f)
            }
        }
    }

    private fun drawBtn(c: Canvas, b: Btn) {
        pFill.color = 0xEE1A1A1A.toInt()
        c.drawRoundRect(b.rect, dp(8f), dp(8f), pFill)
        pStroke.color = accent
        pStroke.strokeWidth = dp(1.5f)
        c.drawRoundRect(b.rect, dp(8f), dp(8f), pStroke)
        pText.textSize = dp(13f)
        pText.color = Color.WHITE
        c.drawText(b.label(), b.rect.centerX(), b.rect.centerY() + pText.textSize / 3f, pText)
    }

    private fun drawGear(c: Canvas, gx: Float, gy: Float) {
        val r = dp(15f)
        gearRect.set(gx - r, gy - r, gx + r, gy + r)
        pFill.color = 0xEE1A1A1A.toInt()
        c.drawCircle(gx, gy, r, pFill)
        pStroke.color = accent
        pStroke.strokeWidth = dp(2f)
        c.drawCircle(gx, gy, r, pStroke)
        pStroke.color = Color.WHITE
        pStroke.strokeWidth = dp(2.2f)
        c.drawCircle(gx, gy, r * 0.42f, pStroke)
        for (i in 0 until 8) {
            val a = i * Math.PI / 4
            c.drawLine(
                gx + (r * 0.55f * cos(a)).toFloat(), gy + (r * 0.55f * sin(a)).toFloat(),
                gx + (r * 0.8f * cos(a)).toFloat(), gy + (r * 0.8f * sin(a)).toFloat(), pStroke
            )
        }
    }

    override fun onDraw(c: Canvas) {
        layoutButtons()
        pFill.color = 0x66000000
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), pFill)
        val minS = min(width, height).toFloat()

        for (b in profile.bindings) {
            val cx = b.x * width
            val cy = b.y * height
            val rad = b.r * minS
            pStroke.strokeWidth = dp(2f)
            pText.color = Color.WHITE
            when (b.type) {
                T.CAMERA -> {
                    pFill.color = 0x33FFFFFF
                    c.drawRect(cx - rad, cy - rad, cx + rad, cy + rad, pFill)
                    pStroke.color = 0xFFFFFFFF.toInt()
                    c.drawRect(cx - rad, cy - rad, cx + rad, cy + rad, pStroke)
                    pText.textSize = dp(16f)
                    c.drawText("CÁMARA (mouse)", cx, cy, pText)
                }
                T.JOYSTICK -> {
                    pFill.color = Shapes.fill(b)
                    Shapes.draw(c, b.shape, cx, cy, rad, pFill)
                    pStroke.color = Shapes.stroke(b)
                    Shapes.draw(c, b.shape, cx, cy, rad, pStroke)
                    pText.textSize = dp(15f)
                    c.drawText(Keys.name(b.keys[0]), cx, cy - rad * 0.55f, pText)
                    c.drawText(Keys.name(b.keys[2]), cx, cy + rad * 0.55f + pText.textSize, pText)
                    c.drawText(Keys.name(b.keys[1]), cx - rad * 0.6f, cy + pText.textSize / 3f, pText)
                    c.drawText(Keys.name(b.keys[3]), cx + rad * 0.6f, cy + pText.textSize / 3f, pText)
                    pText.textSize = dp(11f)
                    c.drawText(JS.names.getOrElse(b.jstyle) { "" }, cx, cy + rad + dp(14f), pText)
                }
                T.SWIPE -> {
                    val ex = b.x2 * width
                    val ey = b.y2 * height
                    pStroke.color = 0xFF4FC3F7.toInt()
                    c.drawLine(cx, cy, ex, ey, pStroke)
                    pFill.color = 0xFF4FC3F7.toInt()
                    c.drawCircle(ex, ey, dp(10f), pFill)
                    pFill.color = Shapes.fill(b)
                    Shapes.draw(c, b.shape, cx, cy, rad, pFill)
                    pStroke.color = Shapes.stroke(b)
                    Shapes.draw(c, b.shape, cx, cy, rad, pStroke)
                    pText.textSize = dp(13f)
                    c.drawText(Keys.label(b), cx, cy + pText.textSize / 3f, pText)
                    c.drawText("${b.ms} ms", cx, cy + rad + dp(14f), pText)
                }
                else -> {
                    pFill.color = Shapes.fill(b)
                    Shapes.draw(c, b.shape, cx, cy, rad, pFill)
                    pStroke.color = Shapes.stroke(b)
                    Shapes.draw(c, b.shape, cx, cy, rad, pStroke)
                    pText.textSize = dp(13f)
                    c.drawText(Keys.label(b), cx, cy + pText.textSize / 3f, pText)
                    val sub = when (b.type) {
                        T.TURBO -> "TURBO"
                        T.DOUBLE -> "×2"
                        T.SEQ -> "×${b.n} cada ${b.ms} ms"
                        T.CLICK -> "toque"
                        T.SCRIPT -> "script"
                        T.FIRE -> "disparo"
                        else -> ""
                    }
                    if (sub.isNotEmpty()) c.drawText(sub, cx, cy + rad + dp(14f), pText)
                }
            }
            if (b === sel) {
                pStroke.color = 0xFFFFEB3B.toInt()
                pStroke.strokeWidth = dp(3f)
                if (b.type == T.CAMERA) {
                    c.drawRect(cx - rad - dp(4f), cy - rad - dp(4f), cx + rad + dp(4f), cy + rad + dp(4f), pStroke)
                } else {
                    Shapes.draw(c, b.shape, cx, cy, rad + dp(4f), pStroke)
                }
            }
        }

        val s = sel
        if (s != null) {
            val cx = s.x * width
            val cy = s.y * height
            val rad = s.r * minS
            val off = if (s.type == T.CAMERA) rad else rad * 0.75f
            val g = dp(15f)
            val gx = (cx + off).coerceIn(g, width - g)
            val gy = (cy - off).coerceIn(topH + g, height - g)
            drawGear(c, gx, gy)
        } else {
            gearRect.setEmpty()
        }

        pText.color = Color.WHITE
        pText.textSize = dp(13f)
        c.drawText(
            "Arrastra para mover · toca un control y luego su engranaje para editarlo",
            width / 2f, topH + dp(16f), pText
        )
        for (b in topBtns) drawBtn(c, b)
        if (addOpen) for (b in addBtns) drawBtn(c, b)

        if (awaiting > 0) {
            val names = listOf("ARRIBA", "IZQUIERDA", "ABAJO", "DERECHA")
            val msg = when {
                sel?.type == T.JOYSTICK -> "Joystick: pulsa la tecla para ${names[assignIdx.coerceIn(0, 3)]}"
                assignIdx == 1 -> "Pulsa la tecla extra de la combinación"
                else -> "Pulsa una tecla o un botón del mouse"
            }
            pFill.color = 0xEE000000.toInt()
            val r = RectF(width / 2f - dp(230f), height / 2f - dp(30f), width / 2f + dp(230f), height / 2f + dp(30f))
            c.drawRoundRect(r, dp(12f), dp(12f), pFill)
            pStroke.color = accent
            pStroke.strokeWidth = dp(2f)
            c.drawRoundRect(r, dp(12f), dp(12f), pStroke)
            pText.textSize = dp(16f)
            c.drawText(msg, width / 2f, height / 2f + dp(6f), pText)
        }
    }

    // ---------------- entrada ----------------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (awaiting > 0 && e.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE) {
                    val bs = e.buttonState
                    val code = when {
                        (bs and MotionEvent.BUTTON_SECONDARY) != 0 -> Keys.MOUSE_RIGHT
                        (bs and MotionEvent.BUTTON_TERTIARY) != 0 -> Keys.MOUSE_MIDDLE
                        else -> Keys.MOUSE_LEFT
                    }
                    assign(code)
                    return true
                }
                if (addOpen) {
                    val hitAdd = addBtns.firstOrNull { it.rect.contains(x, y) }
                    if (hitAdd != null) {
                        hitAdd.action()
                        return true
                    }
                    if (!btnAdd.rect.contains(x, y)) {
                        addOpen = false
                        invalidate()
                        return true
                    }
                }
                val hitBtn = topBtns.firstOrNull { it.rect.contains(x, y) }
                if (hitBtn != null) {
                    hitBtn.action()
                    return true
                }
                val cur = sel
                if (cur != null && !gearRect.isEmpty) {
                    val big = RectF(gearRect)
                    big.inset(-dp(8f), -dp(8f))
                    if (big.contains(x, y)) {
                        if (panel != null) closePanel() else if (awaiting == 0) openPanel()
                        return true
                    }
                }
                if (cur != null && cur.type == T.SWIPE &&
                    hypot(x - cur.x2 * width, y - cur.y2 * height) <= dp(30f)
                ) {
                    dragEnd = true
                    return true
                }
                val hit = bindingAt(x, y)
                if (hit !== sel) closePanel()
                sel = hit
                dragging = hit != null
                if (hit == null) {
                    awaiting = 0
                    closePanel()
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragEnd) {
                    sel?.let {
                        it.x2 = (x / width).coerceIn(0.02f, 0.98f)
                        it.y2 = (y / height).coerceIn(0.02f, 0.98f)
                    }
                    invalidate()
                } else if (dragging) {
                    sel?.let {
                        it.x = (x / width).coerceIn(0.02f, 0.98f)
                        it.y = (y / height).coerceIn(0.02f, 0.98f)
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                dragEnd = false
            }
        }
        return true
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (awaiting > 0 && keyCode != KeyEvent.KEYCODE_BACK) {
            if (event.repeatCount == 0) assign(keyCode)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
