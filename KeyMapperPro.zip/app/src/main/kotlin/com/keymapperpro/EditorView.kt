package com.keymapperpro

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.util.UUID
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Editor de controles que se dibuja encima del juego.
 * Barra superior: añadir controles, Guardar, Cancelar.
 * Al seleccionar un control aparece un engranaje en su esquina: abre el panel con tecla,
 * modo (presionar / tocar), combinaciones, tamaño en píxeles y opciones propias del control.
 */
class EditorView(
    ctx: Context,
    private val profile: Profile,
    private val onSave: () -> Unit,
    private val onCancel: () -> Unit
) : FrameLayout(ctx) {

    private class Btn(val label: String, val action: () -> Unit) {
        val rect = RectF()
    }

    private val red = 0xFFE53935.toInt()
    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
    }
    private val tctx = ContextThemeWrapper(ctx, android.R.style.Theme_DeviceDefault)

    private var sel: Binding? = null
    private var dragging = false
    private var dragEnd = false
    private var awaiting = 0
    private var assignIdx = 0
    private var topH = 0f
    private val gearRect = RectF()
    private var panel: ScrollView? = null
    private val topBtns = ArrayList<Btn>()

    init {
        setWillNotDraw(false)
        isFocusable = true
        isFocusableInTouchMode = true
        descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        topBtns.add(Btn("+ Botón") { addBinding(T.TAP) })
        topBtns.add(Btn("+ Joystick") { addBinding(T.JOYSTICK) })
        topBtns.add(Btn("+ Cámara") { addBinding(T.CAMERA) })
        topBtns.add(Btn("+ Disparo") { addBinding(T.FIRE) })
        topBtns.add(Btn("+ Deslizar") { addBinding(T.SWIPE) })
        topBtns.add(Btn("+ Macro") { addBinding(T.SEQ) })
        topBtns.add(Btn("Guardar") { onSave() })
        topBtns.add(Btn("Cancelar") { onCancel() })
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
    private fun dpi(v: Float) = dp(v).toInt()

    // ---------------- lógica ----------------
    private fun addBinding(type: String) {
        closePanel()
        val r = when (type) {
            T.JOYSTICK -> 0.10f
            T.CAMERA -> 0.20f
            T.FIRE -> 0.07f
            else -> 0.05f
        }
        val b = Binding(UUID.randomUUID().toString(), type, 0.5f, 0.5f, r, mutableListOf(0, 0, 0, 0))
        if (type == T.FIRE) b.keys[0] = Keys.MOUSE_LEFT
        profile.bindings.add(b)
        sel = b
        startAssign(b)
        if (awaiting == 0) openPanel()
        invalidate()
    }

    private fun startAssign(b: Binding) {
        closePanel()
        assignIdx = 0
        awaiting = when (b.type) {
            T.JOYSTICK -> 4
            T.CAMERA -> 0
            T.FIRE -> 0
            else -> 1
        }
        invalidate()
    }

    private fun assign(code: Int) {
        val b = sel ?: return
        if (awaiting <= 0) return
        b.keys[assignIdx] = code
        assignIdx++
        awaiting--
        if (awaiting == 0) openPanel()
        invalidate()
    }

    private fun deleteSel() {
        val b = sel ?: return
        profile.bindings.remove(b)
        sel = null
        awaiting = 0
        closePanel()
        invalidate()
    }

    private fun bindingAt(x: Float, y: Float): Binding? {
        val minS = min(width, height).toFloat()
        for (i in profile.bindings.indices.reversed()) {
            val b = profile.bindings[i]
            val cx = b.x * width
            val cy = b.y * height
            val rad = b.r * minS
            val hit = if (b.type == T.CAMERA) {
                kotlin.math.abs(x - cx) <= rad && kotlin.math.abs(y - cy) <= rad
            } else {
                hypot(x - cx, y - cy) <= maxOf(rad, dp(24f))
            }
            if (hit) return b
        }
        return null
    }

    // ---------------- panel del engranaje ----------------
    private fun label(t: String): TextView = TextView(tctx).apply {
        text = t
        setTextColor(Color.WHITE)
        textSize = 13f
        setPadding(0, dpi(8f), 0, dpi(2f))
    }

    private fun btn(t: String, on: Boolean, click: () -> Unit): Button = Button(tctx).apply {
        text = t
        setAllCaps(false)
        textSize = 12f
        setTextColor(Color.WHITE)
        minHeight = 0
        minimumHeight = 0
        minWidth = 0
        minimumWidth = 0
        setPadding(dpi(8f), dpi(6f), dpi(8f), dpi(6f))
        background = GradientDrawable().apply {
            setColor(if (on) red else 0xFF2A2A2A.toInt())
            cornerRadius = dp(8f)
        }
        isFocusable = false
        setOnClickListener { click() }
    }

    private fun row(vararg v: View): LinearLayout = LinearLayout(tctx).apply {
        orientation = LinearLayout.HORIZONTAL
        for (x in v) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dpi(2f), dpi(2f), dpi(2f), dpi(2f))
            addView(x, lp)
        }
    }

    private fun slider(
        title: String, lo: Float, hi: Float, value: Float,
        fmt: (Float) -> String, onChange: (Float) -> Unit
    ): View {
        val box = LinearLayout(tctx)
        box.orientation = LinearLayout.VERTICAL
        val tv = label("$title: ${fmt(value)}")
        val sb = SeekBar(tctx)
        sb.max = 1000
        sb.progress = (((value - lo) / (hi - lo)) * 1000f).toInt().coerceIn(0, 1000)
        sb.isFocusable = false
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val v = lo + (hi - lo) * p / 1000f
                onChange(v)
                tv.text = "$title: ${fmt(v)}"
                invalidate()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
        return box
    }

    /** Tamaño en píxeles: deslizador + botones de ajuste fino (−10, −1, +1, +10). */
    private fun sizeControl(b: Binding): View {
        val minS = min(width, height).toFloat()
        val hiPx = (minS * 0.95f).toInt()
        val box = LinearLayout(tctx)
        box.orientation = LinearLayout.VERTICAL
        fun cur() = (b.r * minS * 2f).roundToInt()
        val tv = label("Tamaño: ${cur()} px")
        val sb = SeekBar(tctx)
        sb.max = hiPx - 20
        sb.progress = (cur() - 20).coerceIn(0, hiPx - 20)
        sb.isFocusable = false
        fun setPx(v: Int) {
            val c = v.coerceIn(20, hiPx)
            b.r = c / 2f / minS
            tv.text = "Tamaño: $c px"
            sb.progress = c - 20
            invalidate()
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) setPx(p + 20)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
        box.addView(
            row(
                btn("−10", false) { setPx(cur() - 10) },
                btn("−1", false) { setPx(cur() - 1) },
                btn("+1", false) { setPx(cur() + 1) },
                btn("+10", false) { setPx(cur() + 10) }
            )
        )
        return box
    }

    private fun build(col: LinearLayout, b: Binding) {
        val title = when (b.type) {
            T.JOYSTICK -> "Joystick"
            T.CAMERA -> "Cámara / mira"
            T.FIRE -> "Disparo"
            T.SWIPE -> "Deslizar"
            T.SEQ -> "Macro"
            else -> "Botón"
        }
        val head = LinearLayout(tctx)
        head.orientation = LinearLayout.HORIZONTAL
        val t = TextView(tctx)
        t.text = title
        t.setTextColor(Color.WHITE)
        t.textSize = 16f
        t.setTypeface(null, Typeface.BOLD)
        head.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(btn("✕", false) { closePanel() })
        col.addView(head)

        if (b.type != T.CAMERA) {
            val keyText = if (b.type == T.JOYSTICK) {
                "Teclas: " + b.keys.take(4).joinToString(" ") { Keys.name(it) }
            } else {
                "Tecla: " + Keys.label(b)
            }
            col.addView(label(keyText))
            col.addView(btn("Reasignar tecla", false) { startAssign(b) })
        }

        if (b.type == T.TAP || b.type == T.CLICK || b.type == T.TURBO || b.type == T.DOUBLE) {
            col.addView(label("Modo"))
            col.addView(
                row(
                    btn("Presionar", b.type == T.TAP) { b.type = T.TAP; refreshPanel(); invalidate() },
                    btn("Tocar", b.type == T.CLICK) { b.type = T.CLICK; refreshPanel(); invalidate() }
                )
            )
            col.addView(
                row(
                    btn("Turbo", b.type == T.TURBO) { b.type = T.TURBO; refreshPanel(); invalidate() },
                    btn("Doble toque", b.type == T.DOUBLE) { b.type = T.DOUBLE; refreshPanel(); invalidate() }
                )
            )
        }

        if (b.type != T.JOYSTICK && b.type != T.CAMERA) {
            col.addView(label("Combinación (con la tecla)"))
            col.addView(
                row(
                    btn("Ctrl", (b.mod and 1) != 0) { b.mod = b.mod xor 1; refreshPanel(); invalidate() },
                    btn("Shift", (b.mod and 2) != 0) { b.mod = b.mod xor 2; refreshPanel(); invalidate() },
                    btn("Alt", (b.mod and 4) != 0) { b.mod = b.mod xor 4; refreshPanel(); invalidate() }
                )
            )
        }

        col.addView(sizeControl(b))

        if (b.type == T.SWIPE) {
            col.addView(slider("Duración", 40f, 1500f, b.ms.toFloat(), { "${it.roundToInt()} ms" }) { b.ms = it.roundToInt() })
        }
        if (b.type == T.SEQ) {
            col.addView(slider("Repeticiones", 1f, 50f, b.n.toFloat(), { "${it.roundToInt()}" }) { b.n = it.roundToInt() })
            col.addView(slider("Retardo", 40f, 1000f, b.ms.toFloat(), { "${it.roundToInt()} ms" }) { b.ms = it.roundToInt() })
        }
        if (b.type == T.CAMERA) {
            col.addView(slider("Sensibilidad X", 0.2f, 8f, profile.sensX, { "%.1f".format(it) }) { profile.sensX = it })
            col.addView(slider("Sensibilidad Y", 0.2f, 8f, profile.sensY, { "%.1f".format(it) }) { profile.sensY = it })
            col.addView(slider("Aceleración", 0f, 1f, profile.accel, { "%.2f".format(it) }) { profile.accel = it })
            col.addView(slider("Suavizado", 0f, 0.9f, profile.smooth, { "%.2f".format(it) }) { profile.smooth = it })
            col.addView(slider("Sens. al apuntar (clic der.)", 0.1f, 1.5f, profile.adsMult, { "x%.2f".format(it) }) { profile.adsMult = it })
            col.addView(
                btn(if (profile.invertY) "Invertir Y: Sí" else "Invertir Y: No", profile.invertY) {
                    profile.invertY = !profile.invertY
                    refreshPanel()
                }
            )
        }

        val del = btn("Eliminar control", true) { deleteSel() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dpi(12f)
        col.addView(del, lp)
    }

    private fun openPanel() {
        closePanel()
        val b = sel ?: return
        if (height <= 0) return
        val sv = ScrollView(tctx)
        sv.isFocusable = false
        sv.background = GradientDrawable().apply {
            setColor(0xEE111111.toInt())
            cornerRadius = dp(14f)
            setStroke(dpi(1.5f), red)
        }
        val col = LinearLayout(tctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dpi(12f), dpi(8f), dpi(12f), dpi(12f))
        sv.addView(col)
        build(col, b)
        val h = (height - topH - dpi(12f)).toInt().coerceAtLeast(dpi(120f))
        val side = if (b.x > 0.5f) Gravity.START else Gravity.END
        val lp = FrameLayout.LayoutParams(dpi(300f), h, side or Gravity.BOTTOM)
        lp.setMargins(dpi(6f), 0, dpi(6f), dpi(6f))
        addView(sv, lp)
        panel = sv
    }

    private fun refreshPanel() {
        val y = panel?.scrollY ?: 0
        openPanel()
        panel?.post { panel?.scrollY = y }
    }

    private fun closePanel() {
        panel?.let { removeView(it) }
        panel = null
    }

    // ---------------- dibujo ----------------
    private fun layoutButtons() {
        val bh = dp(44f)
        val gap = dp(6f)
        val bw = dp(112f)
        var x = gap
        var y = gap
        for (b in topBtns) {
            if (x + bw > width - gap) {
                x = gap
                y += bh + gap
            }
            b.rect.set(x, y, x + bw, y + bh)
            x += bw + gap
        }
        topH = y + bh + gap
    }

    private fun drawBtn(c: Canvas, b: Btn) {
        pFill.color = 0xDD1A1A1A.toInt()
        c.drawRoundRect(b.rect, dp(8f), dp(8f), pFill)
        pStroke.color = red
        pStroke.strokeWidth = dp(1.5f)
        c.drawRoundRect(b.rect, dp(8f), dp(8f), pStroke)
        pText.textSize = dp(13f)
        pText.color = Color.WHITE
        c.drawText(b.label, b.rect.centerX(), b.rect.centerY() + pText.textSize / 3f, pText)
    }

    private fun drawGear(c: Canvas, gx: Float, gy: Float) {
        val r = dp(15f)
        gearRect.set(gx - r, gy - r, gx + r, gy + r)
        pFill.color = 0xEE1A1A1A.toInt()
        c.drawCircle(gx, gy, r, pFill)
        pStroke.color = red
        pStroke.strokeWidth = dp(2f)
        c.drawCircle(gx, gy, r, pStroke)
        pStroke.color = Color.WHITE
        pStroke.strokeWidth = dp(2.2f)
        c.drawCircle(gx, gy, r * 0.42f, pStroke)
        for (i in 0 until 8) {
            val a = i * Math.PI / 4
            c.drawLine(
                gx + (r * 0.55f * cos(a)).toFloat(), gy + (r * 0.55f * sin(a)).toFloat(),
                gx + (r * 0.8f * cos(a)).toFloat(), gy + (r * 0.8f * sin(a)).toFloat(), pStroke
            )
        }
    }

    override fun onDraw(c: Canvas) {
        layoutButtons()
        pFill.color = 0x66000000
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), pFill)
        val minS = min(width, height).toFloat()

        for (b in profile.bindings) {
            val cx = b.x * width
            val cy = b.y * height
            val rad = b.r * minS
            pStroke.strokeWidth = dp(2f)
            pText.color = Color.WHITE
            when (b.type) {
                T.CAMERA -> {
                    pFill.color = 0x33FFFFFF
                    c.drawRect(cx - rad, cy - rad, cx + rad, cy + rad, pFill)
                    pStroke.color = 0xFFFFFFFF.toInt()
                    c.drawRect(cx - rad, cy - rad, cx + rad, cy + rad, pStroke)
                    pText.textSize = dp(16f)
                    c.drawText("CÁMARA (mouse)", cx, cy, pText)
                }
                T.JOYSTICK -> {
                    pFill.color = 0x33FFFFFF
                    c.drawCircle(cx, cy, rad, pFill)
                    pStroke.color = 0xFFFFFFFF.toInt()
                    c.drawCircle(cx, cy, rad, pStroke)
                    pText.textSize = dp(15f)
                    c.drawText(Keys.name(b.keys[0]), cx, cy - rad * 0.55f, pText)
                    c.drawText(Keys.name(b.keys[2]), cx, cy + rad * 0.55f + pText.textSize, pText)
                    c.drawText(Keys.name(b.keys[1]), cx - rad * 0.6f, cy + pText.textSize / 3f, pText)
                    c.drawText(Keys.name(b.keys[3]), cx + rad * 0.6f, cy + pText.textSize / 3f, pText)
                }
                T.SWIPE -> {
                    val ex = b.x2 * width
                    val ey = b.y2 * height
                    pStroke.color = 0xFF4FC3F7.toInt()
                    c.drawLine(cx, cy, ex, ey, pStroke)
                    pFill.color = 0xFF4FC3F7.toInt()
                    c.drawCircle(ex, ey, dp(10f), pFill)
                    pFill.color = 0x55FFFFFF
                    c.drawCircle(cx, cy, rad, pFill)
                    pStroke.color = 0xFFFFFFFF.toInt()
                    c.drawCircle(cx, cy, rad, pStroke)
                    pText.textSize = dp(13f)
                    c.drawText(Keys.label(b), cx, cy + pText.textSize / 3f, pText)
                    c.drawText("${b.ms} ms", cx, cy + rad + dp(14f), pText)
                }
                else -> {
                    pFill.color = if (b.type == T.FIRE) 0x88E53935.toInt() else 0x55FFFFFF
                    c.drawCircle(cx, cy, rad, pFill)
                    pStroke.color = if (b.type == T.FIRE) red else 0xFFFFFFFF.toInt()
                    c.drawCircle(cx, cy, rad, pStroke)
                    pText.textSize = dp(13f)
                    c.drawText(Keys.label(b), cx, cy + pText.textSize / 3f, pText)
                    val sub = when (b.type) {
                        T.TURBO -> "TURBO"
                        T.DOUBLE -> "×2"
                        T.SEQ -> "×${b.n} cada ${b.ms} ms"
                        T.CLICK -> "toque"
                        else -> ""
                    }
                    if (sub.isNotEmpty()) c.drawText(sub, cx, cy + rad + dp(14f), pText)
                }
            }
            if (b === sel) {
                pStroke.color = 0xFFFFEB3B.toInt()
                pStroke.strokeWidth = dp(3f)
                if (b.type == T.CAMERA) {
                    c.drawRect(cx - rad - dp(4f), cy - rad - dp(4f), cx + rad + dp(4f), cy + rad + dp(4f), pStroke)
                } else {
                    c.drawCircle(cx, cy, rad + dp(4f), pStroke)
                }
            }
        }

        val s = sel
        if (s != null) {
            val cx = s.x * width
            val cy = s.y * height
            val rad = s.r * minS
            val off = if (s.type == T.CAMERA) rad else rad * 0.75f
            val g = dp(15f)
            val gx = (cx + off).coerceIn(g, width - g)
            val gy = (cy - off).coerceIn(topH + g, height - g)
            drawGear(c, gx, gy)
        } else {
            gearRect.setEmpty()
        }

        pText.color = Color.WHITE
        pText.textSize = dp(13f)
        c.drawText(
            "Arrastra para mover · toca un control y luego su engranaje para editarlo",
            width / 2f, topH + dp(16f), pText
        )
        for (b in topBtns) drawBtn(c, b)

        if (awaiting > 0) {
            val names = listOf("ARRIBA", "IZQUIERDA", "ABAJO", "DERECHA")
            val msg = if (sel?.type == T.JOYSTICK) {
                "Joystick: pulsa la tecla para ${names[assignIdx.coerceIn(0, 3)]}"
            } else {
                "Pulsa una tecla o un botón del mouse"
            }
            pFill.color = 0xEE000000.toInt()
            val r = RectF(width / 2f - dp(220f), height / 2f - dp(30f), width / 2f + dp(220f), height / 2f + dp(30f))
            c.drawRoundRect(r, dp(12f), dp(12f), pFill)
            pStroke.color = red
            pStroke.strokeWidth = dp(2f)
            c.drawRoundRect(r, dp(12f), dp(12f), pStroke)
            pText.textSize = dp(16f)
            c.drawText(msg, width / 2f, height / 2f + dp(6f), pText)
        }
    }

    // ---------------- entrada ----------------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (awaiting > 0 && e.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE) {
                    val bs = e.buttonState
                    val code = when {
                        (bs and MotionEvent.BUTTON_SECONDARY) != 0 -> Keys.MOUSE_RIGHT
                        (bs and MotionEvent.BUTTON_TERTIARY) != 0 -> Keys.MOUSE_MIDDLE
                        else -> Keys.MOUSE_LEFT
                    }
                    assign(code)
                    return true
                }
                val hitBtn = topBtns.firstOrNull { it.rect.contains(x, y) }
                if (hitBtn != null) {
                    hitBtn.action()
                    return true
                }
                val cur = sel
                if (cur != null && !gearRect.isEmpty) {
                    val big = RectF(gearRect)
                    big.inset(-dp(8f), -dp(8f))
                    if (big.contains(x, y)) {
                        if (panel != null) closePanel() else if (awaiting == 0) openPanel()
                        return true
                    }
                }
                if (cur != null && cur.type == T.SWIPE &&
                    hypot(x - cur.x2 * width, y - cur.y2 * height) <= dp(30f)
                ) {
                    dragEnd = true
                    return true
                }
                val hit = bindingAt(x, y)
                if (hit !== sel) closePanel()
                sel = hit
                dragging = hit != null
                if (hit == null) {
                    awaiting = 0
                    closePanel()
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragEnd) {
                    sel?.let {
                        it.x2 = (x / width).coerceIn(0.02f, 0.98f)
                        it.y2 = (y / height).coerceIn(0.02f, 0.98f)
                    }
                    invalidate()
                } else if (dragging) {
                    sel?.let {
                        it.x = (x / width).coerceIn(0.02f, 0.98f)
                        it.y = (y / height).coerceIn(0.02f, 0.98f)
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                dragEnd = false
            }
        }
        return true
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (awaiting > 0 && keyCode != KeyEvent.KEYCODE_BACK) {
            if (event.repeatCount == 0) assign(keyCode)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
