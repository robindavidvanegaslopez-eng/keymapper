package com.keymapperpro

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import java.util.UUID
import kotlin.math.hypot
import kotlin.math.min

/** Editor de controles que se dibuja encima del juego (estilo BlueStacks). */
class EditorView(
    ctx: Context,
    private val profile: Profile,
    private val onSave: () -> Unit,
    private val onCancel: () -> Unit
) : View(ctx) {

    private class Btn(val label: String, val action: () -> Unit) {
        val rect = RectF()
    }

    private val red = 0xFFE53935.toInt()
    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
    }

    private var sel: Binding? = null
    private var dragging = false
    private var dragEnd = false
    private var topH = 0f
    private var awaiting = 0
    private var assignIdx = 0

    private val top = ArrayList<Btn>()
    private val bottom = ArrayList<Btn>()

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        top.add(Btn("+ Toque") { addBinding(T.TAP) })
        top.add(Btn("+ Clic") { addBinding(T.CLICK) })
        top.add(Btn("+ Turbo") { addBinding(T.TURBO) })
        top.add(Btn("+ Joystick") { addBinding(T.JOYSTICK) })
        top.add(Btn("+ Cámara") { addBinding(T.CAMERA) })
        top.add(Btn("+ Disparo") { addBinding(T.FIRE) })
        top.add(Btn("+ Doble") { addBinding(T.DOUBLE) })
        top.add(Btn("+ Deslizar") { addBinding(T.SWIPE) })
        top.add(Btn("+ Macro") { addBinding(T.SEQ) })
        top.add(Btn("Guardar") { onSave() })
        top.add(Btn("Cancelar") { onCancel() })

        bottom.add(Btn("Reasignar tecla") { sel?.let { startAssign(it) } })
        bottom.add(Btn("Tamaño −") { resize(0.9f) })
        bottom.add(Btn("Tamaño +") { resize(1.1f) })
        bottom.add(Btn("Eliminar") { deleteSel() })
        bottom.add(Btn("Veces −") { sel?.let { it.n = (it.n - 1).coerceIn(1, 50) }; invalidate() })
        bottom.add(Btn("Veces +") { sel?.let { it.n = (it.n + 1).coerceIn(1, 50) }; invalidate() })
        bottom.add(Btn("Retardo −") { sel?.let { it.ms = (it.ms - 20).coerceIn(40, 2000) }; invalidate() })
        bottom.add(Btn("Retardo +") { sel?.let { it.ms = (it.ms + 20).coerceIn(40, 2000) }; invalidate() })
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density

    private fun addBinding(type: String) {
        val r = when (type) {
            T.JOYSTICK -> 0.10f
            T.CAMERA -> 0.20f
            T.FIRE -> 0.07f
            else -> 0.05f
        }
        val b = Binding(UUID.randomUUID().toString(), type, 0.5f, 0.5f, r, mutableListOf(0, 0, 0, 0))
        if (type == T.FIRE) b.keys[0] = Keys.MOUSE_LEFT
        profile.bindings.add(b)
        sel = b
        startAssign(b)
        invalidate()
    }

    private fun startAssign(b: Binding) {
        assignIdx = 0
        awaiting = when (b.type) {
            T.JOYSTICK -> 4
            T.CAMERA, T.FIRE -> 0
            else -> 1
        }
        invalidate()
    }

    private fun assign(code: Int) {
        val b = sel ?: return
        if (awaiting <= 0) return
        b.keys[assignIdx] = code
        assignIdx++
        awaiting--
        invalidate()
    }

    private fun resize(f: Float) {
        val b = sel ?: return
        b.r = (b.r * f).coerceIn(0.02f, 0.45f)
        invalidate()
    }

    private fun deleteSel() {
        val b = sel ?: return
        profile.bindings.remove(b)
        sel = null
        awaiting = 0
        invalidate()
    }

    private fun bindingAt(x: Float, y: Float): Binding? {
        val minS = min(width, height).toFloat()
        for (i in profile.bindings.indices.reversed()) {
            val b = profile.bindings[i]
            val cx = b.x * width
            val cy = b.y * height
            val rad = b.r * minS
            val hit = if (b.type == T.CAMERA) {
                kotlin.math.abs(x - cx) <= rad && kotlin.math.abs(y - cy) <= rad
            } else {
                hypot(x - cx, y - cy) <= maxOf(rad, dp(24f))
            }
            if (hit) return b
        }
        return null
    }

    private fun bottomVisible(): List<Btn> {
        val b = sel ?: return emptyList()
        val base = bottom.subList(0, 4)
        return when (b.type) {
            T.SEQ -> bottom
            T.SWIPE -> base + bottom.subList(6, 8)
            else -> base
        }
    }

    private fun layoutButtons() {
        val bh = dp(44f)
        val gap = dp(6f)
        val bw = dp(112f)
        var x = gap
        var y = gap
        for (b in top) {
            if (x + bw > width - gap) {
                x = gap
                y += bh + gap
            }
            b.rect.set(x, y, x + bw, y + bh)
            x += bw + gap
        }
        topH = y + bh + gap
        val bw2 = dp(130f)
        x = gap
        y = height - bh - gap
        for (b in bottomVisible()) {
            if (x + bw2 > width - gap) {
                x = gap
                y -= bh + gap
            }
            b.rect.set(x, y, x + bw2, y + bh)
            x += bw2 + gap
        }
    }

    private fun drawBtn(c: Canvas, b: Btn) {
        pFill.color = 0xDD1A1A1A.toInt()
        c.drawRoundRect(b.rect, dp(8f), dp(8f), pFill)
        pStroke.color = red
        pStroke.strokeWidth = dp(1.5f)
        c.drawRoundRect(b.rect, dp(8f), dp(8f), pStroke)
        pText.textSize = dp(13f)
        pText.color = Color.WHITE
        c.drawText(b.label, b.rect.centerX(), b.rect.centerY() + pText.textSize / 3f, pText)
    }

    override fun onDraw(c: Canvas) {
        layoutButtons()
        pFill.color = 0x66000000
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), pFill)
        val minS = min(width, height).toFloat()

        for (b in profile.bindings) {
            val cx = b.x * width
            val cy = b.y * height
            val rad = b.r * minS
            pStroke.strokeWidth = dp(2f)
            pText.color = Color.WHITE
            when (b.type) {
                T.CAMERA -> {
                    pFill.color = 0x33FFFFFF
                    c.drawRect(cx - rad, cy - rad, cx + rad, cy + rad, pFill)
                    pStroke.color = 0xFFFFFFFF.toInt()
                    c.drawRect(cx - rad, cy - rad, cx + rad, cy + rad, pStroke)
                    pText.textSize = dp(16f)
                    c.drawText("CÁMARA (mouse)", cx, cy, pText)
                }
                T.JOYSTICK -> {
                    pFill.color = 0x33FFFFFF
                    c.drawCircle(cx, cy, rad, pFill)
                    pStroke.color = 0xFFFFFFFF.toInt()
                    c.drawCircle(cx, cy, rad, pStroke)
                    pText.textSize = dp(15f)
                    c.drawText(Keys.name(b.keys[0]), cx, cy - rad * 0.55f, pText)
                    c.drawText(Keys.name(b.keys[2]), cx, cy + rad * 0.55f + pText.textSize, pText)
                    c.drawText(Keys.name(b.keys[1]), cx - rad * 0.6f, cy + pText.textSize / 3f, pText)
                    c.drawText(Keys.name(b.keys[3]), cx + rad * 0.6f, cy + pText.textSize / 3f, pText)
                }
                T.SWIPE -> {
                    val ex = b.x2 * width
                    val ey = b.y2 * height
                    pStroke.color = 0xFF4FC3F7.toInt()
                    c.drawLine(cx, cy, ex, ey, pStroke)
                    pFill.color = 0xFF4FC3F7.toInt()
                    c.drawCircle(ex, ey, dp(10f), pFill)
                    pFill.color = 0x55FFFFFF
                    c.drawCircle(cx, cy, rad, pFill)
                    pStroke.color = 0xFFFFFFFF.toInt()
                    c.drawCircle(cx, cy, rad, pStroke)
                    pText.textSize = dp(13f)
                    c.drawText(Keys.name(b.keys[0]), cx, cy + pText.textSize / 3f, pText)
                    c.drawText("${b.ms} ms", cx, cy + rad + dp(14f), pText)
                }
                else -> {
                    pFill.color = if (b.type == T.FIRE) 0x88E53935.toInt() else 0x55FFFFFF
                    c.drawCircle(cx, cy, rad, pFill)
                    pStroke.color = if (b.type == T.FIRE) red else 0xFFFFFFFF.toInt()
                    c.drawCircle(cx, cy, rad, pStroke)
                    pText.textSize = dp(13f)
                    c.drawText(Keys.name(b.keys[0]), cx, cy + pText.textSize / 3f, pText)
                    if (b.type == T.TURBO) c.drawText("TURBO", cx, cy + rad + dp(14f), pText)
                    if (b.type == T.DOUBLE) c.drawText("×2", cx, cy + rad + dp(14f), pText)
                    if (b.type == T.SEQ) c.drawText("×${b.n} cada ${b.ms} ms", cx, cy + rad + dp(14f), pText)
                }
            }
            if (b === sel) {
                pStroke.color = 0xFFFFEB3B.toInt()
                pStroke.strokeWidth = dp(3f)
                if (b.type == T.CAMERA) {
                    c.drawRect(cx - rad - dp(4f), cy - rad - dp(4f), cx + rad + dp(4f), cy + rad + dp(4f), pStroke)
                } else {
                    c.drawCircle(cx, cy, rad + dp(4f), pStroke)
                }
            }
        }

        pText.color = Color.WHITE
        pText.textSize = dp(13f)
        c.drawText(
            "Arrastra para mover · toca un control para editarlo",
            width / 2f, topH + dp(16f), pText
        )

        for (b in top) drawBtn(c, b)
        for (b in bottomVisible()) drawBtn(c, b)

        if (awaiting > 0) {
            val names = listOf("ARRIBA", "IZQUIERDA", "ABAJO", "DERECHA")
            val msg = if (sel?.type == T.JOYSTICK) {
                "Joystick: pulsa la tecla para ${names[assignIdx.coerceIn(0, 3)]}"
            } else {
                "Pulsa una tecla o un botón del mouse"
            }
            pFill.color = 0xEE000000.toInt()
            val r = RectF(width / 2f - dp(220f), height / 2f - dp(30f), width / 2f + dp(220f), height / 2f + dp(30f))
            c.drawRoundRect(r, dp(12f), dp(12f), pFill)
            pStroke.color = red
            pStroke.strokeWidth = dp(2f)
            c.drawRoundRect(r, dp(12f), dp(12f), pStroke)
            pText.textSize = dp(16f)
            c.drawText(msg, width / 2f, height / 2f + dp(6f), pText)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (awaiting > 0 && e.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE) {
                    val bs = e.buttonState
                    val code = when {
                        (bs and MotionEvent.BUTTON_SECONDARY) != 0 -> Keys.MOUSE_RIGHT
                        (bs and MotionEvent.BUTTON_TERTIARY) != 0 -> Keys.MOUSE_MIDDLE
                        else -> Keys.MOUSE_LEFT
                    }
                    assign(code)
                    return true
                }
                val all = top + bottomVisible()
                val hitBtn = all.firstOrNull { it.rect.contains(x, y) }
                if (hitBtn != null) {
                    hitBtn.action()
                    return true
                }
                val cur = sel
                if (cur != null && cur.type == T.SWIPE &&
                    hypot(x - cur.x2 * width, y - cur.y2 * height) <= dp(30f)
                ) {
                    dragEnd = true
                    return true
                }
                val hit = bindingAt(x, y)
                sel = hit
                dragging = hit != null
                if (hit == null) awaiting = 0
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragEnd) {
                    sel?.let {
                        it.x2 = (x / width).coerceIn(0.02f, 0.98f)
                        it.y2 = (y / height).coerceIn(0.02f, 0.98f)
                    }
                    invalidate()
                } else if (dragging) {
                    sel?.let {
                        it.x = (x / width).coerceIn(0.02f, 0.98f)
                        it.y = (y / height).coerceIn(0.02f, 0.98f)
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                dragEnd = false
            }
        }
        return true
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (awaiting > 0 && keyCode != KeyEvent.KEYCODE_BACK) {
            if (event.repeatCount == 0) assign(keyCode)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
