package com.keymapperpro;

interface IInputService {
    void destroy() = 16777114;
    void touch(int id, int action, float x, float y) = 1;
    void releaseAll() = 2;
    String shell(String cmd) = 3;
    String status() = 4;
}
