# KeyMapper Pro — Made By Elite Corporation

Mapeador de teclado y mouse para Android (estilo BlueStacks), sin root, con lanzador propio.

## Cómo funciona
Android no permite que una app normal inyecte toques en otras apps. KeyMapper Pro usa **Shizuku**
(iniciado por depuración inalámbrica o por USB) para ejecutar un servicio con permisos de `shell`
que inyecta toques multitáctiles con `InputManager.injectInputEvent()`.

## Uso
1. Instala Shizuku, inícialo y en la app ve a **Ajustes → Asistente** → «Conceder permiso».
2. En **Inicio** añade el juego y pulsa **▶ Jugar**. El perfil se guarda por juego dentro de la app.
3. Con el juego abierto no hay iconos flotantes: el **menú** se abre con la tecla/combinación que elijas en
   Ajustes (por defecto **F2**): editar controles, capturar/liberar mouse, cursor virtual, detener.
4. **Editor**: «+ Añadir ▾» (menú desplegable de tipos), arrastra los controles y toca el engranaje de cada uno:
   tipo, teclas y combinaciones (Ctrl/Shift/Alt + tecla extra), estilo de joystick, forma, color, opacidad,
   tamaño en píxeles y opciones propias (cámara, deslizar, macro, script). **Guardar** aplica al instante.
5. **Joysticks**: Directo, Desde el centro, Analógico (gradual), Hasta el borde y Flotante.
6. **Cursor virtual** (F3 por defecto): un cursor propio que se mueve con el mouse y actúa como un dedo al hacer clic.
   Aspecto (Windows 11, punto, cruz), tamaño, opacidad, color, sensibilidad y frecuencia (125–1000 Hz) en Ajustes.
7. **Script**: el botón guarda el texto del script; todavía no hay un lenguaje integrado que lo ejecute.

## Códigos y anuncios
- Sin código «sin anuncios»: 1 anuncio simulado de 20 s = 2 horas de mapeo.
- El código de administrador activa todo. Desde la pestaña **Código** el administrador puede generar códigos
  con funciones limitadas (sin anuncios, scripts, cursor virtual, estilos).
- El código de creador no está en el programa: solo se guarda su hash (PBKDF2) y el permiso se guarda firmado.
  Importante: todo lo que va dentro de un APK puede analizarse. Antes de publicar en Play Store, valida los
  códigos y las compras desde un servidor.

## Compilar en GitHub
1. Sube TODO el contenido de esta carpeta (o el zip, si usas el workflow que lo descomprime).
2. Pestaña **Actions** → «Build APK» → **Run workflow**.
3. Descarga el APK desde **Releases** (o el artefacto).

## Play Protect
Una app instalada desde un archivo APK aparece como «no reconocida» en Play Protect, sobre todo si usa
permisos sensibles (superposición, uso de apps). Para reducirlo: firma siempre con la MISMA clave
(variables KEYSTORE_FILE, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD y `gradle assembleRelease`) y,
para quitar la advertencia de verdad, publica la app en Play Console (prueba interna/cerrada).

## Limitaciones
- Android 11+ para iniciar Shizuku sin PC; la depuración inalámbrica se apaga al cambiar de red Wi‑Fi.
- La captura del mouse sobre otro juego depende de que Android dé el foco al overlay; puede variar según el celular.
- Algunos juegos con anticheat pueden detectar toques inyectados; úsalo bajo tu responsabilidad.
