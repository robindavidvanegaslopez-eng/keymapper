# KeyMapper Pro

Mapeador de teclado y mouse para Android (estilo BlueStacks), sin root, con lanzador propio.

## Cómo funciona de verdad
Android no permite que una app normal inyecte toques en otras apps. KeyMapper Pro usa **Shizuku**
(iniciado por depuración inalámbrica o por USB) para ejecutar un servicio con permisos de `shell`
que inyecta toques multitáctiles con `InputManager.injectInputEvent()`, igual que `adb shell input`.

- Overlay transparente con captura de puntero: recibe teclado y mouse (movimiento relativo) mientras el juego está al frente.
- Cámara: el movimiento del mouse arrastra un dedo virtual dentro de una zona; al llegar al borde se recoloca.
- Disparo: botón ligado al clic izquierdo, independiente de la cámara (multitoque).
- Joystick WASD con diagonales. El mapeo se activa al abrir el juego desde la app y se apaga al salir de él.

## Controles disponibles en el editor
Toque (mantener), Clic (breve), Turbo, Joystick, Cámara, Disparo, **Doble toque**, **Deslizar** (arrastra el punto azul para fijar el destino) y **Macro** (n toques cada X ms).
Ajustes de mouse: sensibilidad X/Y, aceleración, suavizado y sensibilidad al apuntar (mientras mantienes clic derecho).

## Compilar en GitHub
1. Sube TODO el contenido de esta carpeta a un repositorio de GitHub.
2. Pestaña **Actions** → «Build APK» → **Run workflow** (o se ejecuta solo con cada push).
3. Al terminar, descarga el artefacto **KeyMapperPro-debug-apk** y descomprímelo: ahí está el .apk.
   (El workflow instala Gradle 8.9; no hace falta `gradlew`.)

## Primer uso
1. Instala Shizuku, inícialo por Depuración inalámbrica y abre KeyMapper Pro → Configuración → «Conceder permiso».
2. Añade tu juego a la biblioteca, pulsa **EDITAR CONTROLES** para ajustar botones y **JUGAR** para jugar.
3. Con F1 capturas/liberas el mouse; ESC también lo libera.

## Limitaciones reales
- Necesita Android 11+ para iniciar Shizuku sin PC; la depuración inalámbrica se apaga al cambiar de red Wi‑Fi (hay que reiniciar Shizuku).
- Los presets de HUD son aproximados: se ajustan en el editor.
- Algunos juegos con anticheat pueden detectar toques inyectados; úsalo bajo tu responsabilidad.
