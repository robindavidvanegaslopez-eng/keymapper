# KeyMapper Pro

Mapeador de teclado y mouse para Android (estilo BlueStacks), sin root, con lanzador propio.

## Cómo funciona
Android no permite que una app normal inyecte toques en otras apps. KeyMapper Pro usa **Shizuku**
(iniciado por depuración inalámbrica o por USB) para ejecutar un servicio con permisos de `shell`
que inyecta toques multitáctiles con `InputManager.injectInputEvent()`.

## Uso
1. Instala Shizuku, inícialo (Depuración inalámbrica) y en la app ve a **Configuración → Conceder permiso**.
2. Añade el juego a la biblioteca y pulsa **JUGAR**. El perfil (controles y ajustes) se guarda por juego dentro de la app.
3. Con el juego abierto aparece un **engranaje** arriba a la derecha (tócalo con el dedo): **Editar controles**, capturar/liberar mouse y detener. También puedes pulsar **F2** para editar.
4. En el editor: añade controles con la barra superior, arrástralos, y al seleccionar uno toca **su engranaje**:
   - Reasignar tecla, modo **Presionar / Tocar / Turbo / Doble toque**, combinación **Ctrl / Shift / Alt**.
   - **Tamaño en píxeles** con deslizador y ajuste fino (−10, −1, +1, +10).
   - Cámara: sensibilidad X/Y, aceleración, suavizado, sensibilidad al apuntar e invertir Y.
   - Deslizar: duración y destino (arrastra el punto azul). Macro: repeticiones y retardo.
5. **Guardar** aplica los cambios al instante y vuelve al mapeo; **Cancelar** descarta lo editado.
6. **F1** captura/libera el mouse; **Esc** también lo libera. Al salir del juego el mapeo se apaga solo.

Los perfiles empiezan vacíos (sin presets): los controles los armas tú en el editor.

## Compilar en GitHub
1. Sube TODO el contenido de esta carpeta a un repositorio de GitHub.
2. Pestaña **Actions** → «Build APK» → **Run workflow** (o se ejecuta solo con cada push).
3. Descarga el artefacto **KeyMapperPro-debug-apk** y descomprímelo: ahí está el .apk.

## Limitaciones
- Necesita Android 11+ para iniciar Shizuku sin PC; la depuración inalámbrica se apaga al cambiar de red Wi‑Fi (hay que reiniciar Shizuku).
- La captura del mouse sobre otro juego depende de que Android dé el foco al overlay; puede variar según el celular.
- Algunos juegos con anticheat pueden detectar toques inyectados; úsalo bajo tu responsabilidad.
